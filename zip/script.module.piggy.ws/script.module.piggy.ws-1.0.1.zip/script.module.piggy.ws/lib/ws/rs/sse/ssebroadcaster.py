from piggy.base import UnsupportedOperationException
from piggy.base.util.concurrent.completionstage import CompletionStage
from ws.rs.sse.outboundsseevent import OutboundSseEvent
from ws.rs.sse.sseeventsink import SseEventSink


class SseBroadcaster:
    def broadcast(self, event: OutboundSseEvent) -> CompletionStage:
        raise UnsupportedOperationException("Called on interface.")

    def close(self):
        raise UnsupportedOperationException("Called on interface.")

    def onClose(self, onClose: 'Consumer[SseEventSink]'):
        raise UnsupportedOperationException("Called on interface.")

    def onError(self, onError: 'BiConsumer[SseEventSink, Raisable]'):
        raise UnsupportedOperationException("Called on interface.")

    def register(self, sseEventSink: SseEventSink):
        raise UnsupportedOperationException("Called on interface.")
