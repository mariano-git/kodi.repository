from piggy.base import UnsupportedOperationException


class SseEvent:
    RECONNECT_NOT_SET: int = -1

    def getComment(self) -> str:
        raise UnsupportedOperationException("Called on interface.")

    def getId(self) -> str:
        raise UnsupportedOperationException("Called on interface.")

    def getName(self) -> str:
        raise UnsupportedOperationException("Called on interface.")

    def getReconnectDelay(self) -> int:
        raise UnsupportedOperationException("Called on interface.")

    def isReconnectDelaySet(self) -> bool:
        raise UnsupportedOperationException("Called on interface.")
