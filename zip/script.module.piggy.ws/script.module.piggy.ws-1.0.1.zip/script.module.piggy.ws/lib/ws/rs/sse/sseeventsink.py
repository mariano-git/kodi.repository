from piggy.base import UnsupportedOperationException
from piggy.base.util.concurrent.completionstage import CompletionStage
from ws.rs.sse.outboundsseevent import OutboundSseEvent


class SseEventSink:
    def close(self):
        raise UnsupportedOperationException("Called on interface.")

    def isClosed(self) -> bool:
        raise UnsupportedOperationException("Called on interface.")

    def send(self, event: OutboundSseEvent) -> CompletionStage:
        raise UnsupportedOperationException("Called on interface.")
