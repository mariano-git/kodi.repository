from typing import Type, TypeVar

from piggy.base import UnsupportedOperationException, Overload
from ws.rs.core.generictype import GenericType
from ws.rs.core.mediatype import MediaType
from ws.rs.sse.sseevent import SseEvent

T = TypeVar('T')


class InboundSseEvent(SseEvent):
    def isEmpty(self) -> bool:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def readData(self, messageType: Type[T], mediaType: MediaType) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def readData(self, genericType: GenericType[T], mediaType: MediaType) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def readData(self, type_: Type[T]) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def readData(self) -> str:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def readData(self, genericType: GenericType[T]) -> T:
        raise UnsupportedOperationException("Called on interface.")
