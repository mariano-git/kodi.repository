from __future__ import annotations

from piggy.base import UnsupportedOperationException, Overload
from piggy.base.util.concurrent.timeunit import TimeUnit
from piggy.restful.container.process.requestscope import Runnable
from ws.rs.client.webtarget import WebTarget


class SseEventSource:
    # abstract
    class Builder:
        @classmethod
        def newBuilder(cls) -> 'Builder':
            raise UnsupportedOperationException("Not supported yet.")

        def reconnectingEvery(self, delay: int, unit: TimeUnit) -> SseEventSource.Builder:
            raise UnsupportedOperationException("Called on interface.")

        def target(self, endpoint: WebTarget) -> SseEventSource.Builder:
            raise UnsupportedOperationException("Called on interface.")

        def build(self) -> SseEventSource:
            raise UnsupportedOperationException("Called on interface.")

    @Overload
    def close(self):
        self.close(5, TimeUnit.SECONDS)

    @Overload
    def close(self, timeout: int, unit: TimeUnit) -> bool:
        raise UnsupportedOperationException("Called on interface.")

    def isOpen(self) -> bool:
        raise UnsupportedOperationException("Called on interface.")

    def open(self):
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def register(self, onEvent: 'Consumer[InboundSseEvent]'):
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def register(self, onEvent: 'Consumer[InboundSseEvent]', onError: 'Consumer[Raisable]'):
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def register(self, onEvent: 'Consumer[InboundSseEvent]', onError: 'Consumer[Raisable]', onComplete: Runnable):
        raise UnsupportedOperationException("Called on interface.")

    @classmethod
    def target(cls, endpoint: WebTarget) -> SseEventSource.Builder:
        raise UnsupportedOperationException("Called on interface.")
