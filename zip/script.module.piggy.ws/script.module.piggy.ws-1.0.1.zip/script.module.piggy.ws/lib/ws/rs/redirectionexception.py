from piggy.base import Overload
from piggy.base.net.uri import URI
from ws.rs.core.response import Response
from ws.rs.webapplicationexception import WebApplicationException


class RedirectionException(WebApplicationException):

    @Overload
    def __init__(self, status: Response.Status, location: URI):
        super().__init__(None, self._validate(Response.status(status).location(location).build(),
                                              Response.Status.Family.REDIRECTION))

    @Overload
    def __init__(self, message: str, status: Response.Status, location: URI):
        super().__init__(message, None, self._validate(Response.status(status).location(location).build(),
                                                       Response.Status.Family.REDIRECTION))

    @Overload
    def __init__(self, status: int, location: URI):
        super().__init__(None, self._validate(Response.status(status).location(location).build(),
                                              Response.Status.Family.REDIRECTION))

    @Overload
    def __init__(self, message: str, status: int, location: URI):
        super().__init__(message, None, self._validate(Response.status(status).location(location).build(),
                                                       Response.Status.Family.REDIRECTION))

    @Overload
    def __init__(self, response: Response):
        super().__init__(None, self._validate(response, Response.Status.Family.REDIRECTION))

    @Overload
    def __init__(self, message: str, response: Response):
        super().__init__(message, None, self._validate(response, Response.Status.Family.REDIRECTION))

    def getLocation(self) -> URI:
        return self.getResponse().getLocation()
