# abstract
from __future__ import annotations

from typing import Type

from piggy.base import UnsupportedOperationException
from piggy.base.net.uri import URI


class Link:
    # interface
    class Builder:
        # abstract
        def link(self, link: Link) -> Link.Builder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        # abstract
        def link(self, link: str) -> Link.Builder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        # abstract
        def baseUri(self, uri: str) -> Link.Builder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        # abstract
        def baseUri(self, uri: URI) -> Link.Builder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        # abstract
        def rel(self, _string: str) -> Link.Builder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        # abstract
        def uriBuilder(self, uribuilder: 'UriBuilder') -> Link.Builder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        # abstract
        def title(self, _string: str) -> Link.Builder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        # abstract
        def buildRelativized(self, uri: URI, *values: object) -> Link:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        # abstract
        def type(self, _string: str) -> Link.Builder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        # abstract
        def uri(self, uri: str) -> Link.Builder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        # abstract
        def uri(self, uri: URI) -> Link.Builder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        # abstract
        def param(self, name: str, value: str) -> Link.Builder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        # abstract
        def build(self, *values: object) -> Link:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

    TITLE: str = 'title'
    REL: str = 'rel'
    TYPE: str = 'type'

    def __init__(self):
        pass

    @classmethod
    def fromLink(cls, _link: Link) -> Link.Builder:
        raise UnsupportedOperationException("Not supported yet.")

    @classmethod
    def fromMethod(cls, _class: Type, _string: str) -> Link.Builder:
        raise UnsupportedOperationException("Not supported yet.")

    @classmethod
    def fromPath(cls, _string: str) -> Link.Builder:
        raise UnsupportedOperationException("Not supported yet.")

    @classmethod
    def fromResource(cls, _class: Type) -> Link.Builder:
        raise UnsupportedOperationException("Not supported yet.")

    @classmethod
    def fromUri(cls, _uri: URI) -> Link.Builder:
        raise UnsupportedOperationException("Not supported yet.")

    @classmethod
    def fromUri(cls, _string: str) -> Link.Builder:
        raise UnsupportedOperationException("Not supported yet.")

    @classmethod
    def fromUriBuilder(cls, _uribuilder: UriBuilder) -> Link.Builder:
        raise UnsupportedOperationException("Not supported yet.")

    # abstract
    def getParams(self) -> Map:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    # abstract
    def getRel(self) -> str:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    # abstract
    def getRels(self) -> List:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    # abstract
    def getTitle(self) -> str:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    # abstract
    def getType(self) -> str:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    # abstract
    def getUri(self) -> URI:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    # abstract
    def getUriBuilder(self) -> UriBuilder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    # abstract
    def toString(self) -> str:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    @classmethod
    def valueOf(cls, _string: str) -> Link:
        raise UnsupportedOperationException("Not supported yet.")
