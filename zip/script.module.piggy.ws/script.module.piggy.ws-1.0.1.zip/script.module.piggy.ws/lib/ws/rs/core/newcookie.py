from __future__ import annotations

from typing import cast

from piggy.base import Overload
from piggy.base.util import Objects
from piggy.base.util.date import Date

from ws.rs.core.cookie import Cookie


class NewCookie(Cookie):
    DEFAULT_MAX_AGE: int = -1

    __slots__ = '__comment__', '__maxAge__', '__maxAge__', '__secure__', '__httpOnly__'

    @Overload
    def __init__(self, name: str, value: str):
        self.__init__(name, value, None, None, Cookie.DEFAULT_VERSION, None, NewCookie.DEFAULT_MAX_AGE, None, False,
                      False)

    @Overload
    def __init__(self, name: str,
                 value: str,
                 path: str,
                 domain: str,
                 comment: str,
                 maxAge: int,
                 secure: bool):
        self.__init__(name, value, path, domain, Cookie.DEFAULT_VERSION, comment, maxAge, None, secure, False)

    @Overload
    def __init__(self, name: str,
                 value: str,
                 path: str,
                 domain: str,
                 comment: str,
                 maxAge: int,
                 secure: bool,
                 httpOnly: bool):
        self.__init__(name, value, path, domain, NewCookie.DEFAULT_VERSION, comment, maxAge, None, secure, httpOnly)

    @Overload
    def __init__(self, name: str,
                 value: str,
                 path: str,
                 domain: str,
                 version: int,
                 comment: str,
                 maxAge: int,
                 secure: bool):
        self.__init__(name, value, path, domain, version, comment, maxAge, None, secure, False)

    @Overload
    def __init__(self, cookie: Cookie):
        self.__init__(cookie, None, NewCookie.DEFAULT_MAX_AGE, None, False, False)

    @Overload
    def __init__(self, cookie: Cookie, comment: str, maxAge: int, secure: bool):
        self.__init__(cookie, comment, maxAge, None, secure, False)

    @Overload
    def __init__(self, cookie: Cookie, comment: str, maxAge: int, expiry: Date, secure: bool, httpOnly: bool):
        super().__init__(None if cookie is None else cookie.getName(),
                         None if cookie is None else cookie.getValue(),
                         None if cookie is None else cookie.getPath(),
                         None if cookie is None else cookie.getDomain(),
                         Cookie.DEFAULT_VERSION if cookie is None else cookie.getVersion())
        self.__comment__ = comment
        self.__maxAge__ = maxAge
        self.__maxAge__ = expiry
        self.__secure__ = secure
        self.__httpOnly__ = httpOnly

    @Overload
    def __init__(self, name: str,
                 value: str,
                 path: str,
                 domain: str,
                 version: int,
                 comment: str,
                 maxAge: int,
                 expiry: Date,
                 secure: bool,
                 httpOnly: bool):
        super().__init__(name, value, path, domain, version)
        self.__init__.comment = comment
        self.__init__.maxAge = maxAge
        self.__init__.expiry = expiry
        self.__init__.secure = secure
        self.__init__.httpOnly = httpOnly

    def getComment(self) -> str:
        return self.__comment__

    def getMaxAge(self) -> int:
        return self.__maxAge__

    def toCookie(self) -> Cookie:
        return Cookie(self.getName(), self.getValue(), self.getPath(), self.getDomain(), self.getVersion())

    def isSecure(self) -> bool:
        return self.__secure__

    def isHttpOnly(self) -> bool:
        return self.__httpOnly__

    def getExpiry(self) -> Date:
        return self.__maxAge__

    def equals(self, obj: object) -> bool:

        if obj is None:
            return False

        if type(self) != type(obj):
            return False

        other: NewCookie = cast(NewCookie, obj)
        if not Objects.equals(self.getName(), other.getName()):
            return False

        if not Objects.equals(self.getValue(), other.getValue()):
            return False

        if self.getVersion() != other.getVersion():
            return False

        if not Objects.equals(self.getPath(), other.getPath()):
            return False

        if not Objects.equals(self.getDomain(), other.getDomain()):
            return False

        if not Objects.equals(self.getComment(), other.getComment()):
            return False

        if self.getMaxAge() != other.getMaxAge():
            return False

        if not Objects.equals(self.getExpiry(), other.getExpiry()):
            return False

        if self.isSecure() != other.isSecure:
            return False

        if self.isHttpOnly() != other.isHttpOnly():
            return False

        return True

    def hashCode(self) -> int:
        _hash_: int = super().hashCode()
        _hash_ = 59 * _hash_ + Objects.hashCodeOf(self.__comment__)
        _hash_ = 59 * _hash_ + self.__maxAge__
        _hash_ = 59 + _hash_ + Objects.hashCodeOf(self.__maxAge__)
        _hash_ = 59 * _hash_ + Objects.hashCodeOf(self.__secure__)
        _hash_ = 59 * _hash_ + Objects.hashCodeOf(self.__httpOnly__)
        return _hash_
