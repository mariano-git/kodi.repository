from typing import List, Set, Collection

from piggy.base import NullPointerException, Overload
from piggy.base.util.map import K, Map
from ws.rs.core.multivaluedmap import MultivaluedMap, V


class AbstractMultivaluedMap(MultivaluedMap[K, V]):

    def __init__(self, store: Map[K, List[V]]):
        if store is None:
            raise NullPointerException("Underlying store must not be 'null'.")
        self.store = store

    def add(self, key: K, value: V):
        values: List[V] = self.getValues(key)
        if value:
            values.append(value)
        else:
            self.addNull(values)

    @Overload
    def addAll(self, key: K, valuesList: List[V]):
        if valuesList is None:
            raise NullPointerException("Supplied list of values must not be null.")
        if len(valuesList) == 0:
            return
        values: List[V] = self.getValues(key)

        for value in valuesList:
            if value:
                values.append(value)
            else:
                self.addNull(values)

    @Overload
    def addAll(self, key: K, *newValues: V):
        if newValues is None:
            raise NullPointerException("Supplied array of values must not be null.")
        if len(newValues) == 0:
            return
        values: List[V] = self.getValues(key)
        for value in newValues:
            if value:
                values.append(value)
            else:
                self.addNull(values)

    def addFirst(self, key: K, value: V):
        values: List[V] = self.getValues(key)
        if value:
            values.insert(0, value)
        else:
            self.addFirstNull(values)

    def addFirstNull(self, values: List[V]):
        # do nothing in the default implementation ignore the null value
        pass

    def addNull(self, values: List[V]):
        # do nothing in the default implementation ignore the null value
        pass

    def clear(self):
        self.store.clear()

    def containsKey(self, key: K) -> bool:
        return self.store.containsKey(key)

    def containsValue(self, value: List[V]) -> bool:
        return self.store.containsValue(value)

    def entrySet(self) -> Set[Map.Entry[K, List[V]]]:
        return self.store.entrySet()

    def equals(self, o: object) -> bool:
        return self.store.equals(o)

    def equalsIgnoreValueOrder(self, omap: MultivaluedMap[K, V]) -> bool:
        if self == omap:
            return True
        for e in self.entrySet():
            olist: List[V] = omap.get(e.getKey())
            if len(e.getValue()) != len(olist):
                return False
            for v in e.getValue():
                if olist.index(v) == -1:
                    return False
        return True

    def get(self, key: K) -> List[V]:
        return self.store.get(key)

    def getFirst(self, key: K) -> List[V]:
        values: List[V] = self.store.get(key)
        if values and len(values) > 0:
            return values[0]
        else:
            return None

    def getValues(self, key: K) -> List[V]:
        lst: List[V] = self.store.get(key)
        if lst is None:
            lst = list()
            self.store.put(key, lst)
        return lst

    def hashCode(self) -> int:
        return self.store.hashCode()

    def isEmpty(self) -> bool:
        return self.store.isEmpty()

    def keySet(self) -> Set[K]:
        return self.store.keySet()

    def put(self, key: K, value: List[V]) -> List[V]:
        return self.store.put(key, value)

    def putAll(self, m: Map[K, List[V]]):
        self.store.putAll(m)

    def putSingle(self, key: K, value: V):
        values: List[V] = self.getValues(key)
        values.clear()
        if value:
            values.append(value)
        else:
            self.addNull(values)

    def remove(self, key: K) -> List:
        return self.store.remove(key)

    def size(self) -> int:
        return self.store.size()

    def toString(self) -> str:
        return self.store.toString()

    def values(self) -> Collection[List[V]]:
        return self.store.values()
