from piggy.base import RuntimeException, Raisable, Overload


class UriBuilderException(RuntimeException):
    @Overload
    def __init__(self, cause: Raisable):
        pass

    @Overload
    def __init__(self, message: str, cause: Raisable):
        pass

    @Overload
    def __init__(self, message: str):
        pass

    @Overload
    def __init__(self):
        pass
