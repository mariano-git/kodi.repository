from typing import List

from piggy.base import UnsupportedOperationException, Overload
from piggy.base.util.date import Date
from ws.rs.core.entitytag import EntityTag
from ws.rs.core.response import Response
from ws.rs.core.variant import Variant


# interface
class Request:
    @Overload
    def evaluatePreconditions(self, lastModified: Date, eTag: EntityTag) -> Response.ResponseBuilder:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def evaluatePreconditions(self) -> Response.ResponseBuilder:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def evaluatePreconditions(self, eTag: EntityTag) -> Response.ResponseBuilder:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def evaluatePreconditions(self, lastModified: Date) -> Response.ResponseBuilder:
        raise UnsupportedOperationException("Called on interface.")

    def getMethod(self) -> str:
        raise UnsupportedOperationException("Called on interface.")

    def selectVariant(self, variants: List) -> Variant:
        raise UnsupportedOperationException("Called on interface.")
