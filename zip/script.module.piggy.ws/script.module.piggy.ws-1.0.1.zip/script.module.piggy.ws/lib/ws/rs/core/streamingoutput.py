from piggy.base import UnsupportedOperationException


# interface
from piggy.base.io.outputstream import OutputStream


class StreamingOutput:
    def write(self, output: OutputStream):
        raise UnsupportedOperationException("Called on interface.")
