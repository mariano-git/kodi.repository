from typing import List

from piggy.base import UnsupportedOperationException, Overload
from piggy.base.net.uri import URI
from ws.rs.core.multivaluedmap import MultivaluedMap
from ws.rs.core.pathsegment import PathSegment
from ws.rs.core.uribuilder import UriBuilder


# interface
class UriInfo:
    def getAbsolutePath(self) -> URI:
        raise UnsupportedOperationException("Called on interface.")

    def getAbsolutePathBuilder(self) -> UriBuilder:
        raise UnsupportedOperationException("Called on interface.")

    def getBaseUri(self) -> URI:
        raise UnsupportedOperationException("Called on interface.")

    def getBaseUriBuilder(self) -> UriBuilder:
        raise UnsupportedOperationException("Called on interface.")

    def getMatchedResources(self) -> List[object]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def getMatchedURIs(self, decode: bool) -> List[str]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def getMatchedURIs(self) -> List[str]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def getPath(self) -> str:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def getPath(self, decode: bool) -> str:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def getPathParameters(self, decode: bool) -> MultivaluedMap[str, str]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def getPathParameters(self) -> MultivaluedMap[str, str]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def getPathSegments(self, decode: bool) -> List[PathSegment]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def getPathSegments(self) -> List[PathSegment]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def getQueryParameters(self) -> MultivaluedMap[str, str]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def getQueryParameters(self, decode: bool) -> MultivaluedMap[str, str]:
        raise UnsupportedOperationException("Called on interface.")

    def getRequestUri(self) -> URI:
        raise UnsupportedOperationException("Called on interface.")

    def getRequestUriBuilder(self) -> UriBuilder:
        raise UnsupportedOperationException("Called on interface.")

    def relativize(self, uri: URI) -> URI:
        raise UnsupportedOperationException("Called on interface.")

    def resolve(self, uri: URI) -> URI:
        raise UnsupportedOperationException("Called on interface.")
