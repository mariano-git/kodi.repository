from typing import Final

from piggy.base import UnsupportedOperationException


# interface
class SecurityContext:
    BASIC_AUTH: Final[str] = 'BASIC'
    CLIENT_CERT_AUTH: Final[str] = 'CLIENT_CERT'
    DIGEST_AUTH: Final[str] = 'DIGEST'
    FORM_AUTH: Final[str] = 'FORM'

    def getAuthenticationScheme(self) -> str:
        raise UnsupportedOperationException("Called on interface.")

    def getUserPrincipal(self) -> 'Principal':
        raise UnsupportedOperationException("Called on interface.")

    def isSecure(self) -> bool:
        raise UnsupportedOperationException("Called on interface.")

    def isUserInRole(self, role: str) -> bool:
        raise UnsupportedOperationException("Called on interface.")
