from __future__ import annotations

from typing import Final

from piggy.base import Overload
from piggy.base.util import Objects
from piggy.base.util.collections import Collections
from piggy.base.util.map import Map
from piggy.base.util.simplemap import SimpleMap
from ws.rs.ext.runtimedelegate import RuntimeDelegate


class MediaType:
    __slots__ = '_type_', '_subtype_', '_parameters_', '_hash_'

    WILDCARD_TYPE: MediaType
    APPLICATION_XML_TYPE: MediaType
    APPLICATION_ATOM_XML_TYPE: MediaType
    APPLICATION_XHTML_XML_TYPE: MediaType
    APPLICATION_SVG_XML_TYPE: MediaType
    APPLICATION_JSON_TYPE: MediaType
    APPLICATION_FORM_URLENCODED_TYPE: MediaType
    MULTIPART_FORM_DATA_TYPE: MediaType
    APPLICATION_OCTET_STREAM_TYPE: MediaType
    TEXT_PLAIN_TYPE: MediaType
    TEXT_XML_TYPE: MediaType
    TEXT_HTML_TYPE: MediaType
    SERVER_SENT_EVENTS_TYPE: MediaType
    APPLICATION_JSON_PATCH_JSON_TYPE: MediaType

    CHARSET_PARAMETER: Final[str] = 'charset'
    MEDIA_TYPE_WILDCARD: Final[str] = '*'
    WILDCARD: Final[str] = '*/*'
    APPLICATION_XML: Final[str] = 'application/xml'
    APPLICATION_ATOM_XML: Final[str] = 'application/atom+xml'
    APPLICATION_XHTML_XML: Final[str] = 'application/xhtml+xml'
    APPLICATION_SVG_XML: Final[str] = 'application/svg+xml'
    APPLICATION_JSON: Final[str] = 'application/json'
    APPLICATION_FORM_URLENCODED: Final[str] = 'application/x-www-form-urlencoded'
    MULTIPART_FORM_DATA: Final[str] = 'multipart/form-data'
    APPLICATION_OCTET_STREAM: Final[str] = 'application/octet-stream'
    TEXT_PLAIN: Final[str] = 'text/plain'
    TEXT_XML: Final[str] = 'text/xml'
    TEXT_HTML: Final[str] = 'text/html'
    SERVER_SENT_EVENTS: Final[str] = 'text/event-stream'
    APPLICATION_JSON_PATCH_JSON: Final[str] = 'application/json-patch+json'

    @Overload
    def __init__(self):
        self.__setup__(MediaType.MEDIA_TYPE_WILDCARD, MediaType.MEDIA_TYPE_WILDCARD, None, None)

    @Overload
    def __init__(self, type_: str, subtype: str):
        self.__setup__(type_, subtype, None, None)

    @Overload
    def __init__(self, type_: str, subtype: str, charset: str):
        self.__setup__(type_, subtype, charset, None)

    @Overload
    def __init__(self, type_: str, subtype: str, parameters: Map[str, str]):
        self.__setup__(type_, subtype, None, parameters)

    def __setup__(self, type: str, subtype: str, charset: str, parameterMap: Map[str, str]):

        self._type_ = MediaType.MEDIA_TYPE_WILDCARD if type is None else type
        self._subtype_ = MediaType.MEDIA_TYPE_WILDCARD if subtype is None else subtype

        if parameterMap is None:
            parameterMap = SimpleMap()

        if not Objects.isEmpty(charset):
            parameterMap.put(MediaType.CHARSET_PARAMETER, charset)

        self._parameters_ = Collections.unmodifiableMap(parameterMap)
        #self._hash_ = Objects.hashCodeOf(self._type_.lower(), self._subtype_.lower(), self._parameters_)

    def getSubtype(self) -> str:
        return self._subtype_

    def isWildcardType(self) -> bool:
        return self.getType() == MediaType.MEDIA_TYPE_WILDCARD

    def isWildcardSubtype(self) -> bool:
        return self.getSubtype() == MediaType.MEDIA_TYPE_WILDCARD

    def withCharset(self, charset: str) -> MediaType:
        return MediaType(self._type_, self._subtype_, charset, self._parameters_)

    def isCompatible(self, other: MediaType) -> bool:
        if other is None:
            return False

        return (self._type_.lower() == other._type_.lower() or self.isWildcardType() or other.isWildcardType()) and (
                self._subtype_.lower() == other._subtype_.lower()) or self.isWildcardSubtype() or other.isWildcardSubtype()

    def getType(self) -> str:
        return self._type_

    def getParameters(self) -> Map[str, str]:
        return self._parameters_

    @classmethod
    def valueOf(cls, value: str):
        return RuntimeDelegate.getInstance().createHeaderDelegate(MediaType).fromString(value)


MediaType.WILDCARD_TYPE = MediaType('*', '*')
MediaType.APPLICATION_XML_TYPE = MediaType("application", "xml")
MediaType.APPLICATION_ATOM_XML_TYPE = MediaType("application", "atom+xml")
MediaType.APPLICATION_XHTML_XML_TYPE = MediaType("application", "xhtml+xml")
MediaType.APPLICATION_SVG_XML_TYPE = MediaType("application", "svg+xml")
MediaType.APPLICATION_JSON_TYPE = MediaType("application", "json")
MediaType.APPLICATION_FORM_URLENCODED_TYPE = MediaType("application", "x-www-form-urlencoded")
MediaType.MULTIPART_FORM_DATA_TYPE = MediaType("multipart", "form-data")
MediaType.APPLICATION_OCTET_STREAM_TYPE = MediaType("application", "octet-stream")
MediaType.TEXT_PLAIN_TYPE = MediaType("text", "plain")
MediaType.TEXT_XML_TYPE = MediaType("text", "xml")
MediaType.TEXT_HTML_TYPE = MediaType("text", "html")
MediaType.SERVER_SENT_EVENTS_TYPE = MediaType("text", "event-stream")
MediaType.APPLICATION_JSON_PATCH_JSON_TYPE = MediaType("application", "json-patch+json")
