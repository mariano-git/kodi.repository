# interface
from typing import Final, List

from piggy.base import UnsupportedOperationException
from piggy.base.util.date import Date
from piggy.base.util.locale import Locale
from piggy.base.util.map import Map
from ws.rs.core.cookie import Cookie
from ws.rs.core.mediatype import MediaType
from ws.rs.core.multivaluedmap import MultivaluedMap


class HttpHeaders:
    ACCEPT: Final[str] = 'Accept'
    ACCEPT_CHARSET: Final[str] = 'Accept-Charset'
    ACCEPT_ENCODING: Final[str] = 'Accept-Encoding'
    ACCEPT_LANGUAGE: Final[str] = 'Accept-Language'
    ALLOW: Final[str] = 'Allow'
    AUTHORIZATION: Final[str] = 'Authorization'
    CACHE_CONTROL: Final[str] = 'Cache-Control'
    CONTENT_DISPOSITION: Final[str] = 'Content-Disposition'
    CONTENT_ENCODING: Final[str] = 'Content-Encoding'
    CONTENT_ID: Final[str] = 'Content-ID'
    CONTENT_LANGUAGE: Final[str] = 'Content-Language'
    CONTENT_LENGTH: Final[str] = 'Content-Length'
    CONTENT_LOCATION: Final[str] = 'Content-Location'
    CONTENT_TYPE: Final[str] = 'Content-Type'
    DATE: Final[str] = 'Date'
    ETAG: Final[str] = 'ETag'
    EXPIRES: Final[str] = 'Expires'
    HOST: Final[str] = 'Host'
    IF_MATCH: Final[str] = 'If-Match'
    IF_MODIFIED_SINCE: Final[str] = 'If-Modified-Since'
    IF_NONE_MATCH: Final[str] = 'If-None-Match'
    IF_UNMODIFIED_SINCE: Final[str] = 'If-Unmodified-Since'
    LAST_MODIFIED: Final[str] = 'Last-Modified'
    LOCATION: Final[str] = 'Location'
    LINK: Final[str] = 'Link'
    RETRY_AFTER: Final[str] = 'Retry-After'
    USER_AGENT: Final[str] = 'User-Agent'
    VARY: Final[str] = 'Vary'
    WWW_AUTHENTICATE: Final[str] = 'WWW-Authenticate'
    COOKIE: Final[str] = 'Cookie'
    SET_COOKIE: Final[str] = 'Set-Cookie'
    LAST_EVENT_ID_HEADER: Final[str] = 'Last-Event-ID'

    def getLength(self) -> int:
        raise UnsupportedOperationException("Called on Interface")

    def getLanguage(self) -> Locale:
        raise UnsupportedOperationException("Called on Interface")

    def getHeaderString(self, name: str) -> str:
        raise UnsupportedOperationException("Called on Interface")

    def getDate(self) -> Date:
        raise UnsupportedOperationException("Called on Interface")

    def getMediaType(self) -> MediaType:
        raise UnsupportedOperationException("Called on Interface")

    def getAcceptableMediaTypes(self) -> List[MediaType]:
        raise UnsupportedOperationException("Called on Interface")

    def getAcceptableLanguages(self) -> List[Locale]:
        raise UnsupportedOperationException("Called on Interface")

    def getCookies(self) -> Map[str, Cookie]:
        raise UnsupportedOperationException("Called on Interface")

    def getRequestHeader(self, name: str) -> List[str]:
        raise UnsupportedOperationException("Called on Interface")

    def getRequestHeaders(self) -> MultivaluedMap[str, str]:
        raise UnsupportedOperationException("Called on Interface")
