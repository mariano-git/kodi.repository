from __future__ import annotations

from typing import List, Any, Type, Callable

from piggy.base import UnsupportedOperationException, Overload, IllegalArgumentException
from piggy.base.net.uri import URI
from piggy.base.util.map import Map
from ws.rs.core.link import Link
from ws.rs.ext.runtimedelegate import RuntimeDelegate


# abstract
class UriBuilder:

    @Overload
    def build(self, values: List[object], encodeSlashInPath: bool) -> URI:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    @Overload
    def build(self, *values: object) -> URI:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def buildFromEncoded(self, *values: object) -> URI:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def buildFromEncodedMap(self, values: Map[str, Any]) -> URI:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    @Overload
    def buildFromMap(self, values: Map[str, Any], encodeSlashInPath: bool) -> URI:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    @Overload
    def buildFromMap(self, values: Map[str, Any]) -> URI:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def clone(self) -> UriBuilder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def fragment(self, fragment: str) -> UriBuilder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    @staticmethod
    def fromLink(link: Link) -> UriBuilder:
        if link is None:
            raise IllegalArgumentException("The provider 'link' parameter value is 'null'.")
        return UriBuilder.fromUri(link.getUri())

    @classmethod
    def fromMethod(cls, resource: Type, method: str) -> UriBuilder:
        return cls.newInstance().path(resource, method)

    @classmethod
    def fromPath(cls, path: str) -> UriBuilder:
        return cls.newInstance().path(path)

    @classmethod
    def fromResource(cls, resource: Type) -> UriBuilder:
        return cls.newInstance().path(resource)

    @Overload
    @classmethod
    def fromUri(cls, uri: URI) -> UriBuilder:
        return cls.newInstance().uri(uri)

    @Overload
    @classmethod
    def fromUri(cls, uriTemplate: str) -> UriBuilder:
        return cls.newInstance().uri(uriTemplate)

    def host(self, host: str) -> UriBuilder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def matrixParam(self, name: str, *values: object) -> UriBuilder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    @staticmethod
    def newInstance() -> UriBuilder:
        return RuntimeDelegate.getInstance().createUriBuilder()

    @Overload
    def path(self, resource: Type) -> UriBuilder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    @Overload
    def path(self, path: str) -> UriBuilder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    @Overload
    def path(self, resource: Type, method: str) -> UriBuilder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    @Overload
    def path(self, method: Callable) -> UriBuilder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def port(self, port: int) -> UriBuilder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def queryParam(self, name: str, *values: object) -> UriBuilder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def replaceMatrix(self, matrix: str) -> UriBuilder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def replaceMatrixParam(self, name: str, *values: object) -> UriBuilder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def replacePath(self, path: str) -> UriBuilder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def replaceQuery(self, query: str) -> UriBuilder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def replaceQueryParam(self, name: str, *values: object) -> UriBuilder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    @Overload
    def resolveTemplate(self, _string: str, _object: object) -> UriBuilder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    @Overload
    def resolveTemplate(self, name: str, value: object, encodeSlashInPath: bool) -> UriBuilder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def resolveTemplateFromEncoded(self, name: str, value: object) -> UriBuilder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    @Overload
    def resolveTemplates(self, templateValues: Map[str, object], encodeSlashInPath: bool) -> UriBuilder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    @Overload
    def resolveTemplates(self, templateValues: Map[str, object]) -> UriBuilder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def resolveTemplatesFromEncoded(self, templateValues: Map[str, object]) -> UriBuilder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def scheme(self, scheme: str) -> UriBuilder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def schemeSpecificPart(self, ssp: str) -> UriBuilder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def segment(self, *segments: str) -> UriBuilder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def toTemplate(self) -> str:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    @Overload
    def uri(self, uri: URI) -> UriBuilder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    @Overload
    def uri(self, uriTemplate: str) -> UriBuilder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def userInfo(self, ui: str) -> UriBuilder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")
