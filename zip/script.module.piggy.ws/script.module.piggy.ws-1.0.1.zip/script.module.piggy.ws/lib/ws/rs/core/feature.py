from piggy.base import UnsupportedOperationException
from ws.rs.core.featurecontext import FeatureContext


# interface
class Feature:
    def configure(self, context: FeatureContext) -> bool:
        raise UnsupportedOperationException("Called on interface.")
