from typing import Union

from piggy.base.util.map import Map
from piggy.base.util.simplemap import SimpleMap
from ws.rs.core.abstractmultivaluedmap import AbstractMultivaluedMap
from ws.rs.core.multivaluedmap import K, V, MultivaluedMap


class MultivaluedSimpleMap(AbstractMultivaluedMap[K, V]):

    def __init__(self, map: Union[MultivaluedMap[K, V], Map[K, V], None] = None):
        super().__init__(SimpleMap())
        if map is not None:
            if isinstance(map, MultivaluedMap):
                self.__putAll(map)
            else:
                if isinstance(map, Map):
                    for e in map.entrySet():
                        self.putSingle(e.getKey(), e.getValue())

    def __putAll(self, map: MultivaluedMap[K, V]):
        for e in map.entrySet():
            v = e.getValue()
            v = v if isinstance(v, list) else list(v)
            self.store.put(e.getKey(), v)
