from __future__ import annotations

from ws.rs.core.configurable import Configurable


class FeatureContext(Configurable['FeatureContext']):
    pass
