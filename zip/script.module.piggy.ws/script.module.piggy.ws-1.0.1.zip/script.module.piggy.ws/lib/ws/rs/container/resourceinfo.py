# interface
from typing import Type, Callable

from piggy.base import UnsupportedOperationException


class ResourceInfo:
    def getResourceClass(self) -> Type:
        raise UnsupportedOperationException("Called on interface.")

    def getResourceMethod(self) -> Callable:
        raise UnsupportedOperationException("Called on interface.")
