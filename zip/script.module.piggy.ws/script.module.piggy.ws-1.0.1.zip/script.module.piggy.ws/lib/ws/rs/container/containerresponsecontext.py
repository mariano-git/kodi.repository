# interface

from typing import List, Type, Set

from piggy.base import UnsupportedOperationException, Overload
from piggy.base.io.outputstream import OutputStream
from piggy.base.net.uri import URI
from piggy.base.notation import Annotation
from piggy.base.util.date import Date
from piggy.base.util.locale import Locale
from piggy.base.util.map import Map
from ws.rs.core.entitytag import EntityTag
from ws.rs.core.link import Link
from ws.rs.core.mediatype import MediaType
from ws.rs.core.multivaluedmap import MultivaluedMap
from ws.rs.core.newcookie import NewCookie
from ws.rs.core.response import Response


class ContainerResponseContext:
    def getAllowedMethods(self) -> Set[str]:
        raise UnsupportedOperationException("Called on interface.")

    def getCookies(self) -> Map[str, NewCookie]:
        raise UnsupportedOperationException("Called on interface.")

    def getDate(self) -> Date:
        raise UnsupportedOperationException("Called on interface.")

    def getEntity(self) -> object:
        raise UnsupportedOperationException("Called on interface.")

    def getEntityAnnotations(self) -> List[Annotation]:
        raise UnsupportedOperationException("Called on interface.")

    def getEntityClass(self) -> Type:
        raise UnsupportedOperationException("Called on interface.")

    def getEntityStream(self) -> OutputStream:
        raise UnsupportedOperationException("Called on interface.")

    def getEntityTag(self) -> EntityTag:
        raise UnsupportedOperationException("Called on interface.")

    def getEntityType(self) -> Type:
        raise UnsupportedOperationException("Called on interface.")

    def getHeaderString(self, name: str) -> str:
        raise UnsupportedOperationException("Called on interface.")

    def getHeaders(self) -> MultivaluedMap[str, object]:
        raise UnsupportedOperationException("Called on interface.")

    def getLanguage(self) -> Locale:
        raise UnsupportedOperationException("Called on interface.")

    def getLastModified(self) -> Date:
        raise UnsupportedOperationException("Called on interface.")

    def getLength(self) -> int:
        raise UnsupportedOperationException("Called on interface.")

    def getLink(self, relation: str) -> Link:
        raise UnsupportedOperationException("Called on interface.")

    def getLinkBuilder(self, relation: str) -> Link.Builder:
        raise UnsupportedOperationException("Called on interface.")

    def getLinks(self) -> Set[Link]:
        raise UnsupportedOperationException("Called on interface.")

    def getLocation(self) -> URI:
        raise UnsupportedOperationException("Called on interface.")

    def getMediaType(self) -> MediaType:
        raise UnsupportedOperationException("Called on interface.")

    def getStatus(self) -> int:
        raise UnsupportedOperationException("Called on interface.")

    def getStatusInfo(self) -> Response.StatusType:
        raise UnsupportedOperationException("Called on interface.")

    def getStringHeaders(self) -> MultivaluedMap[str, str]:
        raise UnsupportedOperationException("Called on interface.")

    def hasEntity(self) -> bool:
        raise UnsupportedOperationException("Called on interface.")

    def hasLink(self, relation: str) -> bool:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def setEntity(self, entity: object):
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def setEntity(self, entity: object, annotations: List[Annotation], mediaType: MediaType):
        raise UnsupportedOperationException("Called on interface.")

    def setEntityStream(self, outputstream: OutputStream):
        raise UnsupportedOperationException("Called on interface.")

    def setStatus(self, code: int):
        raise UnsupportedOperationException("Called on interface.")

    def setStatusInfo(self, statusInfo: Response.StatusType):
        raise UnsupportedOperationException("Called on interface.")
