# interface
from piggy.base import UnsupportedOperationException
from ws.rs.container.asyncresponse import AsyncResponse


class TimeoutHandler:
	def handleTimeout(self, asyncResponse:AsyncResponse):
		raise UnsupportedOperationException("Called on interface.")
