# interface
from piggy.base import UnsupportedOperationException
from ws.rs.container.containerrequestcontext import ContainerRequestContext


class ContainerRequestFilter:
	def filter(self, context:ContainerRequestContext):
		raise UnsupportedOperationException("Called on interface.")
