# interface
from piggy.base import UnsupportedOperationException
from ws.rs.container.asyncresponse import AsyncResponse


class ConnectionCallback:
	def onDisconnect(self, disconnected:AsyncResponse):
		raise UnsupportedOperationException("Called on interface.")
