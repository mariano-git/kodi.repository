# interface
from piggy.base import Raisable, UnsupportedOperationException


class CompletionCallback:
	def onComplete(self, cause:Raisable):
		raise UnsupportedOperationException("Called on interface.")
