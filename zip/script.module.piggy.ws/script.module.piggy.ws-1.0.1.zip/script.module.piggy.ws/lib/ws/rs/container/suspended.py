# interface
from piggy.base.notation import Target, ElementType, AnnotationType


@Target({ElementType.PARAMETER})
class Suspended(AnnotationType):
    pass
