from typing import Type, Collection

from piggy.base import UnsupportedOperationException, Raisable, Overload
from piggy.base.util.concurrent.timeunit import TimeUnit
from piggy.base.util.date import Date
from piggy.base.util.map import Map
from ws.rs.container.timeouthandler import TimeoutHandler


class AsyncResponse:
    NO_TIMEOUT: int = 0

    @Overload
    def cancel(self, retryAfter: Date) -> bool:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def cancel(self, retryAfter: int) -> bool:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def cancel(self) -> bool:
        raise UnsupportedOperationException("Called on interface.")

    def isCancelled(self) -> bool:
        raise UnsupportedOperationException("Called on interface.")

    def isDone(self) -> bool:
        raise UnsupportedOperationException("Called on interface.")

    def isSuspended(self) -> bool:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def register(self, callback: Type) -> Collection[Type]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def register(self, callback: object) -> Collection[Type]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def register(self, *callbacks: Type) -> Map[Type, Collection[Type]]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def register(self, *callback: object) -> Map[Type, Collection[Type]]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def resume(self, cause: Raisable) -> bool:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def resume(self, response: object) -> bool:
        raise UnsupportedOperationException("Called on interface.")

    def setTimeout(self, time: int, unit: TimeUnit) -> bool:
        raise UnsupportedOperationException("Called on interface.")

    def setTimeoutHandler(self, handler: TimeoutHandler):
        raise UnsupportedOperationException("Called on interface.")
