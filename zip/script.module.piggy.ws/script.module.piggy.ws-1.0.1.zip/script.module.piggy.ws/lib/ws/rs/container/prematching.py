from piggy.base.notation import Target, ElementType, AnnotationType

@Target({ ElementType.TYPE })
class PreMatching(AnnotationType):
    pass
