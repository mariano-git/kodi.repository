from piggy.base import Overload, Raisable
from ws.rs.core.response import Response
from ws.rs.servererrorexception import ServerErrorException


class InternalServerErrorException(ServerErrorException):

    @Overload
    def __init__(self):
        super().__init__(Response.Status.INTERNAL_SERVER_ERROR)

    @Overload
    def __init__(self, message: str):
        super().__init__(message, Response.Status.INTERNAL_SERVER_ERROR)

    @Overload
    def __init__(self, response: Response):
        super().__init__(self._validate(response, Response.Status.INTERNAL_SERVER_ERROR))

    @Overload
    def __init__(self, message: str, response: Response):
        super().__init__(message, self._validate(response, Response.Status.INTERNAL_SERVER_ERROR))

    @Overload
    def __init__(self, cause: Raisable):
        super().__init__(Response.Status.INTERNAL_SERVER_ERROR, cause)

    @Overload
    def __init__(self, message: str, cause: Raisable):
        super().__init__(message, Response.Status.INTERNAL_SERVER_ERROR, cause)

    @Overload
    def __init__(self, response: Response, cause: Raisable):
        super().__init__(self._validate(response, Response.Status.INTERNAL_SERVER_ERROR), cause)

    @Overload
    def __init__(self, message: str, response: Response, cause: Raisable):
        super().__init__(message, self._validate(response, Response.Status.INTERNAL_SERVER_ERROR), cause)
