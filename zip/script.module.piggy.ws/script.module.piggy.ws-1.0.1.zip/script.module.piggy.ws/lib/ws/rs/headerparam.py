from piggy.base.notation import Target, ElementType, AnnotationType


@Target({ElementType.PARAMETER, ElementType.METHOD, ElementType.FIELD})
class HeaderParam(AnnotationType):
    def value(self) -> str:
        pass
