# interface
from typing import Type

from piggy.base import UnsupportedOperationException
from ws.rs.client.rxinvoker import RxInvoker
from ws.rs.client.syncinvoker import SyncInvoker


class RxInvokerProvider:
	def getRxInvoker(self, _syncinvoker:SyncInvoker, _executorservice:'ExecutorService') -> RxInvoker:
		raise UnsupportedOperationException("Called on interface.")
	def isProviderFor(self, _class:Type) -> bool:
		raise UnsupportedOperationException("Called on interface.")
