from piggy.base import Overload, UnsupportedOperationException
from piggy.base.net.uri import URI
from ws.rs.client.invocation import Invocation
from ws.rs.client.webtarget import WebTarget
from ws.rs.core.configurable import Configurable
from ws.rs.core.link import Link
from ws.rs.core.uribuilder import UriBuilder


# interface
class Client(Configurable['Client']):

    def close(self):
        raise UnsupportedOperationException("Called on Interface.")

    def getHostnameVerifier(self) -> 'HostnameVerifier':
        raise UnsupportedOperationException("Called on Interface.")

    def getSslContext(self) -> 'SSLContext':
        raise UnsupportedOperationException("Called on Interface.")

    def invocation(self, link: Link) -> Invocation.Builder:
        raise UnsupportedOperationException("Called on Interface.")

    @Overload
    def target(self, uribuilder: UriBuilder) -> WebTarget:
        raise UnsupportedOperationException("Called on Interface.")

    @Overload
    def target(self, uri: URI) -> WebTarget:
        raise UnsupportedOperationException("Called on Interface.")

    @Overload
    def target(self, uri: str) -> WebTarget:
        raise UnsupportedOperationException("Called on Interface.")

    @Overload
    def target(self, link: Link) -> WebTarget:
        raise UnsupportedOperationException("Called on Interface.")
