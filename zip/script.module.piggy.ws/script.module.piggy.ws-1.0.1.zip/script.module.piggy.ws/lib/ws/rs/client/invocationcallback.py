# interface
from typing import TypeVar, Generic

from piggy.base import Raisable, UnsupportedOperationException

RESPONSE = TypeVar('RESPONSE')


class InvocationCallback(Generic[RESPONSE]):
    def completed(self, response: RESPONSE):
        raise UnsupportedOperationException("Called on interface.")

    def failed(self, cause: Raisable):
        raise UnsupportedOperationException("Called on interface.")
