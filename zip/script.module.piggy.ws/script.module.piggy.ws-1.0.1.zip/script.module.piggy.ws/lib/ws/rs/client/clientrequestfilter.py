from piggy.base import UnsupportedOperationException
from ws.rs.client.clientrequestcontext import ClientRequestContext


# interface
class ClientRequestFilter:
    def filter(self, requestContext: ClientRequestContext):
        raise UnsupportedOperationException("Called on interface.")
