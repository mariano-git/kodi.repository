import sys
from types import TracebackType

from ws.rs.core.response import Response
from ws.rs.processingexception import ProcessingException


class ResponseProcessingException(ProcessingException):
    __slots__ = '__response__'

    def __init__(self, *args):
        self.__response__ = None
        frame = sys._getframe().f_back
        a = list(args)
        for arg in args:
            if isinstance(arg, TracebackType):
                a.remove(arg)
                frame = arg
            if isinstance(arg, Response):
                a.remove(arg)
                self.__response__ = arg
        a.append(frame)
        super().__init__(*tuple(a))
 
    def getResponse(self) -> Response:
        return self.__response__
