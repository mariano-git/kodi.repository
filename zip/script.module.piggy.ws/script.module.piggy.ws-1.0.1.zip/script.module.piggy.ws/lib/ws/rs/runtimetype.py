from enum import Enum


class RuntimeType(Enum):
    CLIENT = 0
    SERVER = 1