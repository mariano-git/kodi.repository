from typing import Final

from piggy.base import UnsupportedOperationException


class Priorities:
    AUTHENTICATION: Final[int] = 1000
    AUTHORIZATION: Final[int] = 2000
    HEADER_DECORATOR: Final[int] = 3000
    ENTITY_CODER: Final[int] = 4000
    USER: Final[int] = 5000

    def __init__(self):
        raise UnsupportedOperationException("Not allowed.")
