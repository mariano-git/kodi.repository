from piggy.base import UnsupportedOperationException
from piggy.base.notation import Target, ElementType, AnnotationType


@Target({ElementType.TYPE})
class ApplicationPath(AnnotationType):
    def value(self) -> str:
        pass
