import sys
from types import TracebackType
from typing import List

from piggy.base import Raisable, NullPointerException
from ws.rs.clienterrorexception import ClientErrorException
from ws.rs.core.httpheaders import HttpHeaders
from ws.rs.core.response import Response


class NotAuthorizedException(ClientErrorException):
    __slots__ = '__challenges__'

    # FIXME This class won't work on server mode

    def __init__(self, *args):
        frame = sys._getframe().f_back
        a = list(args)
        challenges = list()
        for arg in args:
            if isinstance(arg, TracebackType):
                a.remove(arg)
                frame = arg
            if isinstance(arg, Response):
                a.remove(arg)
                a.append(self._validate(arg, Response.Status.UNAUTHORIZED))
            if not isinstance(arg, Response.Status) or \
                    not isinstance(arg, int) or \
                    not isinstance(arg,Raisable) or \
                    not isinstance(arg, BaseException):
                challenges.append(arg)

        a.append(frame)
        super().__init__(*tuple(a))
        self.__challenges__ = challenges

    def getChallenges(self) -> List[object]:
        if self.__challenges__ is None:
            self.__challenges__ = self.getResponse().getHeaders().get(HttpHeaders.WWW_AUTHENTICATE)

        return self.__challenges__

    def _createUnauthorizedResponse(self, *challenges: object):
        if challenges is None:
            raise NullPointerException("challenges parameter must not be null.")
        builder: Response.ResponseBuilder = Response.status(Response.Status.UNAUTHORIZED)
        for challenge in challenges:
            builder.header(HttpHeaders.WWW_AUTHENTICATE, challenge)
        return builder.build()
