# interface
from typing import Type, List

from piggy.base import UnsupportedOperationException
from piggy.base.notation import Annotation
from ws.rs.core.mediatype import MediaType
from ws.rs.ext.contextresolver import ContextResolver, T
from ws.rs.ext.exceptionmapper import ExceptionMapper, E
from ws.rs.ext.messagebodyreader import MessageBodyReader
from ws.rs.ext.messagebodywriter import MessageBodyWriter


class Providers:
    def getContextResolver(self, contextType: Type[T], mediaType: MediaType) -> ContextResolver[T]:
        raise UnsupportedOperationException("Called on interface.")

    def getExceptionMapper(self, typ: Type[T]) -> ExceptionMapper[E]:
        raise UnsupportedOperationException("Called on interface.")

    def getMessageBodyReader(self,
                             typ: Type,
                             genericType: Type[T],
                             annotations: List[Annotation],
                             mediaType: MediaType) -> MessageBodyReader[T]:
        raise UnsupportedOperationException("Called on interface.")

    def getMessageBodyWriter(self,
                             typ: Type,
                             genericType: Type[T],
                             annotations: List[Annotation],
                             mediaType: MediaType) -> MessageBodyWriter[T]:
        raise UnsupportedOperationException("Called on interface.")
