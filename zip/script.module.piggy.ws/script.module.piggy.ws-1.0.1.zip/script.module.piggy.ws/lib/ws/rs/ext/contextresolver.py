from typing import Generic, TypeVar, Type

from piggy.base import UnsupportedOperationException

T = TypeVar('T')


# interface
class ContextResolver(Generic[T]):
    def getContext(self, typ: Type[T]) -> T:
        raise UnsupportedOperationException("Called on interface.")
