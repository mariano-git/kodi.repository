from typing import TypeVar, Generic

from piggy.base import UnsupportedOperationException, Raisable
from ws.rs.core.response import Response

E = TypeVar('E', bound=Raisable)


class ExceptionMapper(Generic[E]):
    def toResponse(self, exception: E) -> Response:
        raise UnsupportedOperationException("Called on interface.")
