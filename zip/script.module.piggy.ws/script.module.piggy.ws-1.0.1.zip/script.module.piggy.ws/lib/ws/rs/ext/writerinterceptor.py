# interface
from piggy.base import UnsupportedOperationException
from ws.rs.ext.writerinterceptorcontext import WriterInterceptorContext


class WriterInterceptor:
	def aroundWriteTo(self, context:WriterInterceptorContext):
		raise UnsupportedOperationException("Called on interface.")
