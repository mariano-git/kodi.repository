from typing import Type, List, Generic, TypeVar

from piggy.base import UnsupportedOperationException
from piggy.base.io.outputstream import OutputStream
from piggy.base.notation import Annotation
from ws.rs.core.mediatype import MediaType
from ws.rs.core.multivaluedmap import MultivaluedMap

T = TypeVar('T')


# interface
class MessageBodyWriter(Generic[T]):
    def getSize(self, entity: T, cls: Type, genericType: Type, annotations: List[Annotation],
                mediaType: MediaType) -> int:
        """
        Originally, the method has been called before writeTo to ascertain the length in bytes of the serialized form of t.
        A non-negative return value has been used in a HTTP Content-Length header.
        As of JAX-RS 2.0, the method has been deprecated and the value returned by the method is ignored by a JAX-RS runtime.
        All MessageBodyWriter implementations are advised to return -1 from the method.
        Responsibility to compute the actual Content-Length header value has been delegated to JAX-RS runtime.

        :param entity: the instance to write
        :param cls: the class of instance that is to be written.
        :param genericType: the type of instance to be written. GenericEntity provides a way to specify this information at runtime.
        :param annotations: an array of the annotations attached to the message entity instance.
        :param mediaType: the media type of the HTTP entity.
        :return: length in bytes or -1 if the length cannot be determined in advance.
        """
        return -1

    def isWriteable(self, cls: Type, genericType: Type, annotations: List[Annotation], mediaType: MediaType) -> bool:
        raise UnsupportedOperationException("Called on interface.")

    def writeTo(self, t: T, cls: Type, genericType: Type, annotations: List[Annotation], mediaType: MediaType,
                httpHeaders: MultivaluedMap[str, object], entityStream: OutputStream):
        raise UnsupportedOperationException("Called on interface.")
