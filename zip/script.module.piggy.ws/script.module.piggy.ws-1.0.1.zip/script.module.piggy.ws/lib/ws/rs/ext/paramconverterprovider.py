from typing import Type, List

from piggy.base import UnsupportedOperationException
from piggy.base.notation import Annotation
from ws.rs.ext.paramconverter import ParamConverter, T


class ParamConverterProvider:
    def getConverter(self, rawType: Type, genericType: Type, annotations: List[Annotation]) -> ParamConverter[T]:
        raise UnsupportedOperationException("Called on interface.")
