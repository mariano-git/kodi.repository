from typing import Generic, TypeVar, Type, List

from piggy.base import UnsupportedOperationException
from piggy.base.io.inputstream import InputStream
from piggy.base.notation import Annotation
from ws.rs.core.mediatype import MediaType
from ws.rs.core.multivaluedmap import MultivaluedMap

T = TypeVar('T')


# interface
class MessageBodyReader(Generic[T]):
    def isReadable(self, cls: Type, genericType: Type, annotations: List[Annotation], mediaType: MediaType) -> bool:
        raise UnsupportedOperationException("Called on interface.")

    def readFrom(self, cls: Type, genericType: Type, annotations: List[Annotation], mediaType: MediaType,
                 httpHeaders: MultivaluedMap[str, str], entityStream: InputStream) -> T:
        raise UnsupportedOperationException("Called on interface.")
