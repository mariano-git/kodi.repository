# interface
from typing import Set

from piggy.base.notation import Target, ElementType, AnnotationType


@Target({ElementType.TYPE, ElementType.METHOD})
class Consumes(AnnotationType):
    def value(self) -> Set[str]:
        return {"*/*"}
