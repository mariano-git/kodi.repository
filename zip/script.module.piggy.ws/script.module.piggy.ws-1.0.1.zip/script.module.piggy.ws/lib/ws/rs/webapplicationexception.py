import sys
from types import TracebackType

from piggy.base import Overload, Raisable, RuntimeException, IllegalArgumentException
from ws.rs.core.response import Response


class WebApplicationException(RuntimeException):
    __slots__ = '__response__'

    def __init__(self, *args):
        frame = sys._getframe().f_back
        a = []
        message = cause =  code = response = status = None

        for arg in args:
            if isinstance(arg, TracebackType):
                frame = arg
            if isinstance(arg, Response):
                response = arg
            elif isinstance(arg, str):
                message = arg
            elif isinstance(arg, Raisable) or isinstance(arg, BaseException):
                a.append(arg)
            elif isinstance(arg, Response.Status):
                status = arg
            elif isinstance(arg, int):
                code = arg
        a.append(frame)

        if not response and not status and not code and not message:
            self.__response__ = Response.status(Response.Status.INTERNAL_SERVER_ERROR).build()
            a.append(self._computeExceptionMessage(self.__response__))
            super().__init__(*tuple(a))
            return

        if not message:
            if response:
                self.__response__ = response
                message = self._computeExceptionMessage(self.__response__)
            elif not response and status or code:
                self.__response__ = Response.status(code if code else status).build()
                message = self._computeExceptionMessage(self.__response__)

        a.append(message)
        super().__init__(*tuple(a))
        if not response and status or code:
            self.__response__ = Response.status(code if code else status).build()
        else:
            self.__response__ = response

    def getResponse(self) -> Response:
        return self.__response__

    def _computeExceptionMessage(self, response: Response) -> str:
        if response:
            statusInfo = response.getStatusInfo()
        else:
            statusInfo = Response.Status.INTERNAL_SERVER_ERROR

        return f"HTTP {statusInfo.getStatusCode()} - {statusInfo.getReasonPhrase()}"

    @Overload
    def _validate(self, response: Response, expectedStatus: Response.Status) -> Response:
        if expectedStatus.getStatusCode() != response.getStatus():
            raise IllegalArgumentException(
                f"Invalid response status code. Expected {expectedStatus.getStatusCode()}, was response.getStatus()")
        return response

    @Overload
    def _validate(self, response: Response, expectedStatusFamily: Response.Status.Family) -> Response:
        if response.getStatusInfo().getFamily() != expectedStatusFamily:
            raise IllegalArgumentException(
                f"Status code of the supplied response {response.getStatus()} "
                f"is not from the required status code family \"{expectedStatusFamily}\".")
        return response
