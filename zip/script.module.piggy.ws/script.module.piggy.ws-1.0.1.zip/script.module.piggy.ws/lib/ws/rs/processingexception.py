from piggy.base import RuntimeException
from piggy.base.exceptions import raisable


@raisable
class ProcessingException(RuntimeException):
    pass
