from piggy.base import Overload, Raisable
from ws.rs.clienterrorexception import ClientErrorException
from ws.rs.core.response import Response


class NotAcceptableException(ClientErrorException):

    @Overload
    def __init__(self):
        super().__init__(Response.Status.NOT_ACCEPTABLE)

    @Overload
    def __init__(self, message: str):
        super().__init__(message, Response.Status.NOT_ACCEPTABLE)

    @Overload
    def __init__(self, response: Response):
        super().__init__(self._validate(response, Response.Status.NOT_ACCEPTABLE))

    @Overload
    def __init__(self, message: str, response: Response):
        super().__init__(message, self._validate(response, Response.Status.NOT_ACCEPTABLE))

    @Overload
    def __init__(self, cause: Raisable):
        super().__init__(Response.Status.NOT_ACCEPTABLE, cause)

    @Overload
    def __init__(self, message: str, cause: Raisable):
        super().__init__(message, Response.Status.NOT_ACCEPTABLE, cause)

    @Overload
    def __init__(self, response: Response, cause: Raisable):
        super().__init__(self._validate(response, Response.Status.NOT_ACCEPTABLE), cause)

    @Overload
    def __init__(self, message: str, response: Response, cause: Raisable):
        super().__init__(message, self._validate(response, Response.Status.NOT_ACCEPTABLE), cause)
