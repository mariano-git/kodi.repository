import sys
from types import TracebackType

from ws.rs.core.response import Response
from ws.rs.webapplicationexception import WebApplicationException


class ClientErrorException(WebApplicationException):

    def __init__(self, *args):
        frame = sys._getframe().f_back
        a = list(args)
        for arg in args:
            if isinstance(arg, TracebackType):
                a.remove(arg)
                frame = arg
            if isinstance(arg, Response):
                a.remove(arg)
                a.append(self._validate(arg, Response.Status.Family.CLIENT_ERROR))
            elif isinstance(arg, Response.Status) or isinstance(arg, int):
                a.remove(arg)
                a.append(self._validate(Response.status(arg).build(), Response.Status.Family.CLIENT_ERROR))
        a.append(frame)
        super().__init__(*tuple(a))
