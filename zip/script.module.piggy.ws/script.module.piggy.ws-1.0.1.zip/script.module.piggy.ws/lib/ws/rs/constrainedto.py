# interface
from piggy.base import UnsupportedOperationException
from piggy.base.notation import Target, ElementType, AnnotationType
from ws.rs.runtimetype import RuntimeType


@Target({ElementType.TYPE})
class ConstrainedTo(AnnotationType):
    def value(self) -> RuntimeType:
        pass
