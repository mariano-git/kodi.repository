import sys

from piggy.base import Overload, Raisable, RuntimeException, IllegalArgumentException
from ws.rs.core.response import Response


class WebApplicationExceptionOrg(RuntimeException):
    __slots__ = '__response__'

    def __init__(self, *args):
        a = [sys._getframe().f_back]
        message, cause, code, response, status = None

        for arg in args:
            if isinstance(arg, Response):
                response = arg
            elif isinstance(arg, str):
                message = arg
            elif isinstance(arg, Raisable) or isinstance(arg, BaseException):
                a.append(arg)
            elif isinstance(arg, Response.Status):
                status = arg
            elif isinstance(arg, int):
                code = arg

        if not response and not status and not code and not message:
            self.__response__ = Response.status(Response.Status.INTERNAL_SERVER_ERROR).build()
            a.append(self._computeExceptionMessage(self.__response__))
            super().__init__(*tuple(a))
            return

        if not message:
            if response:
                self.__response__ = response
                message = self._computeExceptionMessage(self.__response__)
            elif not response and status or code:
                self.__response__ = Response.status(code if code else status).build()
                message = self._computeExceptionMessage(self.__response__)
            a.append(message)
            super().__init__(*tuple(a))
            return
        a.append(message)
        super().__init__(*tuple(a))
        if not response and status or code:
            self.__response__ = Response.status(code if code else status).build()
        else:
            self.__response__ = response

        '''
        def __init__(self, message: str, cause: Raisable, response: Response):
        def __init__(self, cause: Raisable, response: Response):
        def __init__(self, message: str, cause: Raisable):
        def __init__(self, cause: Raisable):
        def __init__(self, message: str, cause: Raisable, status: Response.Status):
        def __init__(self, cause: Raisable, status: Response.Status):
        def __init__(self, message: str, cause: Raisable, status: int):
        def __init__(self, cause: Raisable, status: int):
        def __init__(self, message: str, response: Response):
        def __init__(self, response: Response):
        def __init__(self, message: str):
        def __init__(self):
        def __init__(self, status: Response.Status):
        def __init__(self, message: str, status: int):
        def __init__(self, status: int):
        def __init__(self, message: str, status: Response.Status):
        '''

    @Overload
    def __init__(self, message: str, cause: Raisable, response: Response):
        super().__init__(message, cause)
        if response is None:
            self.__response__ = Response.serverError().build()
        else:
            self.__response__ = response

    @Overload
    def __init__(self, cause: Raisable, response: Response):
        self.__init__(self._computeExceptionMessage(response), cause, response)

    @Overload
    def __init__(self, message: str, cause: Raisable):
        self.__init__(message, cause, Response.Status.INTERNAL_SERVER_ERROR)

    @Overload
    def __init__(self, cause: Raisable):
        self.__init__(cause, Response.Status.INTERNAL_SERVER_ERROR)

    @Overload
    def __init__(self, message: str, cause: Raisable, status: Response.Status):
        self.__init__(message, cause, Response.status(status).build())

    @Overload
    def __init__(self, cause: Raisable, status: Response.Status):
        self.__init__(cause, Response.status(status).build())

    @Overload
    def __init__(self, message: str, cause: Raisable, status: int):
        self.__init__(message, cause, Response.status(status).build())

    @Overload
    def __init__(self, cause: Raisable, status: int):
        self.__init__(cause, Response.status(status).build())

    @Overload
    def __init__(self, message: str, response: Response):
        self.__init__(message, None, response)

    @Overload
    def __init__(self, response: Response):
        self.__init__(None, response)

    @Overload
    def __init__(self, message: str):
        self.__init__(message, None, Response.Status.INTERNAL_SERVER_ERROR)

    @Overload
    def __init__(self):
        self.__init__(None, Response.Status.INTERNAL_SERVER_ERROR)

    @Overload
    def __init__(self, status: Response.Status):
        self.__init__(None, status)

    @Overload
    def __init__(self, message: str, status: int):
        self.__init__(message, None, status)

    @Overload
    def __init__(self, status: int):
        self.__init__(None, status)

    @Overload
    def __init__(self, message: str, status: Response.Status):
        self.__init__(message, None, status)

    def getResponse(self) -> Response:
        return self.__response__

    def _computeExceptionMessage(self, response: Response) -> str:
        if response:
            statusInfo = response.getStatusInfo()
        else:
            statusInfo = Response.Status.INTERNAL_SERVER_ERROR

        return f"HTTP {statusInfo.getStatusCode()} {statusInfo.getReasonPhrase()}"

    @Overload
    def _validate(self, response: Response, expectedStatus: Response.Status) -> Response:
        if expectedStatus.getStatusCode() != response.getStatus():
            raise IllegalArgumentException(
                f"Invalid response status code. Expected {expectedStatus.getStatusCode()}, was response.getStatus()")
        return response

    @Overload
    def _validate(self, response: Response, expectedStatusFamily: Response.Status.Family) -> Response:
        if response.getStatusInfo().getFamily() != expectedStatusFamily:
            raise IllegalArgumentException(
                f"Status code of the supplied response {response.getStatus()} "
                f"is not from the required status code family \"{expectedStatusFamily}\".")
        return response
