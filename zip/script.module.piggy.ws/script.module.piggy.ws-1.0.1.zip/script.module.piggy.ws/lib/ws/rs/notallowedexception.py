from typing import Set

from piggy.base import Overload, NullPointerException, Raisable, IllegalArgumentException
from ws.rs.clienterrorexception import ClientErrorException
from ws.rs.core.httpheaders import HttpHeaders
from ws.rs.core.response import Response


class NotAllowedException(ClientErrorException):
    @Overload
    def __init__(self, *allowed: str):
        super().__init__(self._validateAllow(self.createNotAllowedResponse(*allowed)))

    @Overload
    def __init__(self, message: str, *allowed: str):
        super().__init__(message, self._validateAllow(self.createNotAllowedResponse(*allowed)))

    def createNotAllowedResponse(*allowed: str) -> Response:
        if allowed is None:
            raise NullPointerException("No allowed method specified.")

        methods: Set[str] = set()
        for allow in allowed:
            methods.add(allow)

        return Response.status(Response.Status.METHOD_NOT_ALLOWED).allow(tuple(methods)).build()

    @Overload
    def __init__(self, response: Response):
        super().__init__(self._validate(response, Response.Status.METHOD_NOT_ALLOWED))

    @Overload
    def __init__(self, message: str, response: Response):
        super().__init__(message, self._validate(response, Response.Status.METHOD_NOT_ALLOWED))

    @Overload
    def __init__(self, cause: Raisable, *allowedMethods: str):
        super().__init__(
            self._validateAllow(Response.status(Response.Status.METHOD_NOT_ALLOWED).allow(allowedMethods).build()),
            cause)

    @Overload
    def __init__(self, message: str, cause: Raisable, *allowedMethods: str):
        super().__init__(
            message, self._validateAllow(
                Response.status(
                    Response.Status.METHOD_NOT_ALLOWED
                ).allow(allowedMethods).build()), cause
        )

    @Overload
    def __init__(self, response: Response, cause: Raisable):
        super().__init__(self._validateAllow(self._validate(response, Response.Status.METHOD_NOT_ALLOWED)), cause)

    @Overload
    def __init__(self, message: str, response: Response, cause: Raisable):
        super().__init__(message, self._validateAllow(self._validate(response, Response.Status.METHOD_NOT_ALLOWED)),
                         cause)

    def _validateAllow(self, response: Response) -> Response:
        if not response.getHeaders().containsKey(HttpHeaders.ALLOW):
            raise IllegalArgumentException("Response does not contain required 'Allow' HTTP header.")

        return response
