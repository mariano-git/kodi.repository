from piggy.base.notation import Target, ElementType, Annotation


@Target({ElementType.TYPE})
class Singleton(Annotation):
    pass


@Target({ElementType.TYPE, ElementType.PARAMETER})
class Priority(Annotation):
    def value(self) -> int:
        pass
