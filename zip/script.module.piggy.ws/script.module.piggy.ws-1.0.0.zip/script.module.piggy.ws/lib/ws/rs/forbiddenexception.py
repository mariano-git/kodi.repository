import sys
from types import TracebackType

from ws.rs.clienterrorexception import ClientErrorException
from ws.rs.core.response import Response


class ForbiddenException(ClientErrorException):

    def __init__(self, *args):
        frame = sys._getframe().f_back
        a = list(args)
        for arg in args:
            if isinstance(arg, TracebackType):
                a.remove(arg)
                frame = arg
            if isinstance(arg, Response):
                a.remove(arg)
                a.append(self._validate(arg, Response.Status.FORBIDDEN))
        a.append(frame)
        super().__init__(*tuple(a))
