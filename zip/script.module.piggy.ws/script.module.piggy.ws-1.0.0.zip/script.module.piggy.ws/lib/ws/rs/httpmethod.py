# interface
from piggy.base import UnsupportedOperationException
from piggy.base.notation import Target, ElementType, AnnotationType


@Target({ElementType.ANNOTATION_TYPE})
class HttpMethod(AnnotationType):
    GET: str = 'GET'
    POST: str = 'POST'
    PUT: str = 'PUT'
    DELETE: str = 'DELETE'
    PATCH: str = 'PATCH'
    HEAD: str = 'HEAD'
    OPTIONS: str = 'OPTIONS'

    def value(self) -> str:
        pass


@Target({ElementType.METHOD})
@HttpMethod(HttpMethod.GET)
class GET(AnnotationType):
    pass


@Target({ElementType.METHOD})
@HttpMethod(HttpMethod.POST)
class POST(AnnotationType):
    pass


@Target({ElementType.METHOD})
@HttpMethod(HttpMethod.PUT)
class PUT(AnnotationType):
    pass


@Target({ElementType.METHOD})
@HttpMethod(HttpMethod.HEAD)
class HEAD(AnnotationType):
    pass


@Target({ElementType.METHOD})
@HttpMethod(HttpMethod.OPTIONS)
class OPTIONS(AnnotationType):
    pass


@Target({ElementType.METHOD})
@HttpMethod(HttpMethod.PATCH)
class PATCH(AnnotationType):
    pass


@Target({ElementType.METHOD})
@HttpMethod(HttpMethod.DELETE)
class DELETE(AnnotationType):
    pass
