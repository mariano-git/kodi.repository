from piggy.base.notation import Target, ElementType, AnnotationType


@Target({ElementType.PARAMETER, ElementType.METHOD, ElementType.FIELD, ElementType.CONSTRUCTOR, ElementType.TYPE})
class Encoded(AnnotationType):
    pass
