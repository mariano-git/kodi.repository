# interface
from piggy.base.notation import Annotation, Target, ElementType


@Target({ElementType.PARAMETER, ElementType.METHOD, ElementType.FIELD})
class Context(AnnotationType):
    pass
