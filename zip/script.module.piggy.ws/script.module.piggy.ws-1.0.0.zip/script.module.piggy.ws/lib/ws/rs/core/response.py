from __future__ import annotations

from enum import Enum
from typing import List, cast, Set, Type

from piggy.base import UnsupportedOperationException, IllegalArgumentException, Overload
from piggy.base.net.uri import URI
from piggy.base.notation import Annotation
from piggy.base.util.date import Date
from piggy.base.util.locale import Locale
from piggy.base.util.map import Map
from ws.rs.core.cachecontrol import CacheControl
from ws.rs.core.entitytag import EntityTag
from ws.rs.core.generictype import GenericType
from ws.rs.core.link import Link
from ws.rs.core.mediatype import MediaType
from ws.rs.core.multivaluedmap import MultivaluedMap
from ws.rs.core.newcookie import NewCookie
from ws.rs.core.variant import Variant
from ws.rs.ext.runtimedelegate import RuntimeDelegate


class Response:
    class StatusType:

        def getFamily(self) -> Response.Status.Family:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        def getStatusCode(self) -> int:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        def getReasonPhrase(self) -> str:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        def toEnum(self) -> Response.Status:
            return Response.Status.fromStatusCode(self.getStatusCode())

    # --------------------------------

    class Status(StatusType):

        class Family(Enum):
            INFORMATIONAL = 1
            SUCCESSFUL = 2
            REDIRECTION = 3
            CLIENT_ERROR = 4
            SERVER_ERROR = 5
            OTHER = 6

            @staticmethod
            def familyOf(statusCode: int) -> Response.Status.Family:
                value = int(statusCode / 100)

                if value == 1:
                    return Response.Status.Family.INFORMATIONAL
                if value == 2:
                    return Response.Status.Family.SUCCESSFUL
                if value == 3:
                    return Response.Status.Family.REDIRECTION
                if value == 4:
                    return Response.Status.Family.CLIENT_ERROR
                if value == 5:
                    return Response.Status.Family.SERVER_ERROR

                return Response.Status.Family.OTHER

        def __init__(self, code, reason):
            if isinstance(code, int):
                self.__status__ = code
                self.__reason__ = reason
                self.__family__ = Response.Status.Family.familyOf(code)

        def toString(self) -> str:
            return f'{self.__status__} - {self.__reason__}'

        @classmethod
        def values(cls) -> List[Response.Status]:
            values = list()
            for k, v in cls.__dict__.items():
                if isinstance(v, cls):
                    values.append(v)
            return values

        @classmethod
        def valueOf(cls, name: str) -> Response.Status:
            return cls.__dict__.get(name)

        def getFamily(self) -> Response.Status.Family:
            return self.__family__

        def getStatusCode(self) -> int:
            return self.__status__

        def getReasonPhrase(self) -> str:
            return self.__reason__

        @classmethod
        def fromStatusCode(cls, statusCode: int) -> Response.Status:
            for s in Response.Status.values():
                if s.getStatusCode() == statusCode:
                    return s
            return None

        OK: Response.Status
        CREATED: Response.Status
        ACCEPTED: Response.Status
        NO_CONTENT: Response.Status
        RESET_CONTENT: Response.Status
        PARTIAL_CONTENT: Response.Status
        MOVED_PERMANENTLY: Response.Status
        FOUND: Response.Status
        SEE_OTHER: Response.Status
        NOT_MODIFIED: Response.Status
        USE_PROXY: Response.Status
        TEMPORARY_REDIRECT: Response.Status
        BAD_REQUEST: Response.Status
        UNAUTHORIZED: Response.Status
        PAYMENT_REQUIRED: Response.Status
        FORBIDDEN: Response.Status
        NOT_FOUND: Response.Status
        METHOD_NOT_ALLOWED: Response.Status
        NOT_ACCEPTABLE: Response.Status
        PROXY_AUTHENTICATION_REQUIRED: Response.Status
        REQUEST_TIMEOUT: Response.Status
        CONFLICT: Response.Status
        GONE: Response.Status
        LENGTH_REQUIRED: Response.Status
        PRECONDITION_FAILED: Response.Status
        REQUEST_ENTITY_TOO_LARGE: Response.Status
        REQUEST_URI_TOO_LONG: Response.Status
        UNSUPPORTED_MEDIA_TYPE: Response.Status
        REQUESTED_RANGE_NOT_SATISFIABLE: Response.Status
        EXPECTATION_FAILED: Response.Status
        PRECONDITION_REQUIRED: Response.Status
        TOO_MANY_REQUESTS: Response.Status
        REQUEST_HEADER_FIELDS_TOO_LARGE: Response.Status
        INTERNAL_SERVER_ERROR: Response.Status
        NOT_IMPLEMENTED: Response.Status
        BAD_GATEWAY: Response.Status
        SERVICE_UNAVAILABLE: Response.Status
        GATEWAY_TIMEOUT: Response.Status
        HTTP_VERSION_NOT_SUPPORTED: Response.Status
        NETWORK_AUTHENTICATION_REQUIRED: Response.Status

    # --------------------------------

    class ResponseBuilder:

        @Overload
        def link(self, uri: str, rel: str) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        @Overload
        def link(self, uri: URI, rel: str) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        @Overload
        def language(self, language: str) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        @Overload
        def language(self, language: Locale) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        def variant(self, variant: Variant) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        @Overload
        def tag(self, tag: str) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        @Overload
        def tag(self, tag: EntityTag) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        @Overload
        def variants(self, variants: List[Variant]) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        @Overload
        def variants(self, *variants: Variant) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        @Overload
        def type(self, mediaType: str) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        @Overload
        def type(self, mediaType: MediaType) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        def clone(self) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        def replaceAll(self, headers: MultivaluedMap[str, object]) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        @classmethod
        def newInstance(cls) -> Response.ResponseBuilder:
            return RuntimeDelegate.getInstance().createResponseBuilder()

        @Overload
        def status(self, status: Response.StatusType) -> Response.ResponseBuilder:
            if status is None:
                raise IllegalArgumentException()

            return self.status(status.getStatusCode(), status.getReasonPhrase())

        @Overload
        def status(self, status: int) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        @Overload
        def status(self, status: int, reasonPhrase: str) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        @Overload
        def status(self, status: Response.Status) -> Response.ResponseBuilder:
            return self.status(cast(Response.StatusType, status))

        def encoding(self, encoding: str) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        def location(self, location: URI) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        def build(self) -> Response:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        def lastModified(self, lastModified: Date) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        @Overload
        def entity(self, entity: object) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        @Overload
        def entity(self, entity: object, annotations: List[Annotation]) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        def header(self, name: str, value: object) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        @Overload
        def allow(self, *methods: str) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        @Overload
        def allow(self, methods: Set[str]) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        def cacheControl(self, cacheControl: CacheControl) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        def contentLocation(self, location: URI) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        def cookie(self, *cookie: NewCookie) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        def expires(self, expires: Date) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        def links(self, *links: Link) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

    # --------------------------------
    @Overload
    @classmethod
    def accepted(cls, entity: object) -> Response.ResponseBuilder:
        return cls.accepted().entity(entity)

    @Overload
    @classmethod
    def accepted(cls) -> Response.ResponseBuilder:
        return cls.status(Response.Status.ACCEPTED)

    def bufferEntity(self) -> bool:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def close(self):
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    @classmethod
    def created(cls, location: URI) -> Response.ResponseBuilder:
        return cls.status(Response.Status.CREATED).location(location)

    @classmethod
    def fromResponse(cls, response: Response) -> Response.ResponseBuilder:
        b: Response.ResponseBuilder = cls.status(response.getStatus())
        if response.hasEntity():
            b.entity(response.getEntity())

        for headerName in response.getHeaders().keySet():
            headerValues: List[object] = response.getHeaders().get(headerName)
            for headerValue in headerValues:
                b.header(headerName, headerValue)
        return b

    def getAllowedMethods(self) -> Set[str]:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def getCookies(self) -> Map[str, NewCookie]:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def getDate(self) -> Date:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def getEntity(self) -> object:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def getEntityTag(self) -> EntityTag:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def getHeaderString(self, name: str) -> str:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def getHeaders(self) -> MultivaluedMap[str, object]:
        return self.getMetadata()

    def getLanguage(self) -> Locale:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def getLastModified(self) -> Date:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def getLength(self) -> int:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def getLink(self, relation: str) -> Link:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def getLinkBuilder(self, relation: str) -> Link.Builder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def getLinks(self) -> Set:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def getLocation(self) -> URI:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def getMediaType(self) -> MediaType:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def getMetadata(self) -> MultivaluedMap[str, object]:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def getStatus(self) -> int:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def getStatusInfo(self) -> Response.StatusType:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def getStringHeaders(self) -> MultivaluedMap[str, str]:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def hasEntity(self) -> bool:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def hasLink(self, relation: str) -> bool:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    @classmethod
    def noContent(cls) -> Response.ResponseBuilder:
        return cls.status(Response.Status.NO_CONTENT)

    @classmethod
    def notAcceptable(cls, variants: List[Variant]) -> Response.ResponseBuilder:
        return cls.status(Response.Status.NOT_ACCEPTABLE).variants(variants)

    @Overload
    @classmethod
    def notModified(cls, tag: EntityTag) -> Response.ResponseBuilder:
        return cls.notModified().tag(tag)

    @Overload
    @classmethod
    def notModified(cls, tag: str) -> Response.ResponseBuilder:
        return cls.notModified().tag(tag)

    @Overload
    @classmethod
    def notModified(cls) -> Response.ResponseBuilder:
        return cls.status(Response.Status.NOT_MODIFIED)

    @Overload
    @classmethod
    def ok(cls, entity: object, variant: Variant) -> Response.ResponseBuilder:
        return cls.ok().entity(entity).variant(variant)

    @Overload
    @classmethod
    def ok(cls, entity: object, mediatype: str) -> Response.ResponseBuilder:
        return cls.ok().entity(entity).type(mediatype)

    @Overload
    @classmethod
    def ok(cls, entity: object, mediaType: MediaType) -> Response.ResponseBuilder:
        return cls.ok().entity(entity).type(mediaType)

    @Overload
    @classmethod
    def ok(cls, entity: object) -> Response.ResponseBuilder:
        b: Response.ResponseBuilder = cls.ok()
        b.entity(entity)
        return b

    @Overload
    @classmethod
    def ok(cls) -> Response.ResponseBuilder:
        return cls.status(Response.Status.OK)

    @Overload
    def readEntity(self, entityType: Type[T], annotations: List[Annotation]) -> T:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    @Overload
    def readEntity(self, entityType: Type[T]) -> T:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    @Overload
    def readEntity(self, entityType: GenericType[T], annotations: List[Annotation]) -> T:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    @Overload
    def readEntity(self, entityType: GenericType[T]) -> T:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    @classmethod
    def seeOther(cls, location: URI) -> Response.ResponseBuilder:
        return cls.status(Response.Status.SEE_OTHER).location(location)

    @classmethod
    def serverError(cls) -> Response.ResponseBuilder:
        return cls.status(Response.Status.INTERNAL_SERVER_ERROR)

    @classmethod
    def status(cls, *args) -> Response.ResponseBuilder:
        return Response.ResponseBuilder.newInstance().status(*args)

    @classmethod
    def temporaryRedirect(cls, location: URI) -> Response.ResponseBuilder:
        return cls.status(Response.Status.TEMPORARY_REDIRECT).location(location)


Response.Status.OK = Response.Status(200, "OK")
Response.Status.CREATED = Response.Status(201, "Created")
Response.Status.ACCEPTED = Response.Status(202, "Accepted")
Response.Status.NO_CONTENT = Response.Status(204, "No Content")
Response.Status.RESET_CONTENT = Response.Status(205, "Reset Content")
Response.Status.PARTIAL_CONTENT = Response.Status(206, "Partial Content")
Response.Status.MOVED_PERMANENTLY = Response.Status(301, "Moved Permanently")
Response.Status.FOUND = Response.Status(302, "Found")
Response.Status.SEE_OTHER = Response.Status(303, "See Other")
Response.Status.NOT_MODIFIED = Response.Status(304, "Not Modified")
Response.Status.USE_PROXY = Response.Status(305, "Use Proxy")
Response.Status.TEMPORARY_REDIRECT = Response.Status(307, "Temporary Redirect")
Response.Status.BAD_REQUEST = Response.Status(400, "Bad Request")
Response.Status.UNAUTHORIZED = Response.Status(401, "Unauthorized")
Response.Status.PAYMENT_REQUIRED = Response.Status(402, "Payment Required")
Response.Status.FORBIDDEN = Response.Status(403, "Forbidden")
Response.Status.NOT_FOUND = Response.Status(404, "Not Found")
Response.Status.METHOD_NOT_ALLOWED = Response.Status(405, "Method Not Allowed")
Response.Status.NOT_ACCEPTABLE = Response.Status(406, "Not Acceptable")
Response.Status.PROXY_AUTHENTICATION_REQUIRED = Response.Status(407, "Proxy Authentication Required")
Response.Status.REQUEST_TIMEOUT = Response.Status(408, "Request Timeout")
Response.Status.CONFLICT = Response.Status(409, "Conflict")
Response.Status.GONE = Response.Status(410, "Gone")
Response.Status.LENGTH_REQUIRED = Response.Status(411, "Length Required")
Response.Status.PRECONDITION_FAILED = Response.Status(412, "Precondition Failed")
Response.Status.REQUEST_ENTITY_TOO_LARGE = Response.Status(413, "Request Entity Too Large")
Response.Status.REQUEST_URI_TOO_LONG = Response.Status(414, "Request-URI Too Long")
Response.Status.UNSUPPORTED_MEDIA_TYPE = Response.Status(415, "Unsupported Media Type")
Response.Status.REQUESTED_RANGE_NOT_SATISFIABLE = Response.Status(416,
                                                                  "Requested Range Not Satisfiable")
Response.Status.EXPECTATION_FAILED = Response.Status(417, "Expectation Failed")
Response.Status.PRECONDITION_REQUIRED = Response.Status(428, "Precondition Required")
Response.Status.TOO_MANY_REQUESTS = Response.Status(429, "Too Many Requests")
Response.Status.REQUEST_HEADER_FIELDS_TOO_LARGE = Response.Status(431,
                                                                  "Request Header Fields Too Large")
Response.Status.INTERNAL_SERVER_ERROR = Response.Status(500, "Internal Server Error")
Response.Status.NOT_IMPLEMENTED = Response.Status(501, "Not Implemented")
Response.Status.BAD_GATEWAY = Response.Status(502, "Bad Gateway")
Response.Status.SERVICE_UNAVAILABLE = Response.Status(503, "Service Unavailable")
Response.Status.GATEWAY_TIMEOUT = Response.Status(504, "Gateway Timeout")
Response.Status.HTTP_VERSION_NOT_SUPPORTED = Response.Status(505, "HTTP Version Not Supported")
Response.Status.NETWORK_AUTHENTICATION_REQUIRED = Response.Status(511,
                                                                  "Network Authentication Required")
