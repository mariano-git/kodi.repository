from piggy.base import Overload
from piggy.base.util.map import Map
from piggy.base.util.simplemap import SimpleMap
from ws.rs.core.abstractmultivaluedmap import AbstractMultivaluedMap

from ws.rs.core.multivaluedmap import K, V, MultivaluedMap


class MultivaluedSimpleMap(AbstractMultivaluedMap[K, V]):
    @Overload
    def __init__(self):
        super().__init__(SimpleMap())

    @Overload
    def __init__(self, map: MultivaluedMap[K, V]):
        super().__init__(SimpleMap())
        if map:
            self.__putAll(map)

    @Overload
    def __init__(self, map: Map[K, V]):
        super().__init__(SimpleMap())
        for e in map.entrySet():
            self.putSingle(e.getKey(), e.getValue())

    def __putAll(self, map: MultivaluedMap[K, V]):
        for e in map.entrySet():
            v = e.getValue()
            v = v if isinstance(v,list) else list(v)
            self.store.put(e.getKey(), v)
