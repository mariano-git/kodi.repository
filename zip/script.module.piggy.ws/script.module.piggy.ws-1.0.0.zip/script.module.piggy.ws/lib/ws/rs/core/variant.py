from __future__ import annotations

from typing import cast, List

from piggy.base import IllegalArgumentException, UnsupportedOperationException, Overload
from piggy.base.stringbuilder import StringBuilder
from piggy.base.util import Objects
from piggy.base.util.locale import Locale
from ws.rs.core.mediatype import MediaType
from ws.rs.ext.runtimedelegate import RuntimeDelegate


class Variant:
    class VariantListBuilder:

        @classmethod
        def newInstance(cls) -> Variant.VariantListBuilder:
            return RuntimeDelegate.getInstance().createVariantListBuilder()

        def build(self) -> List[Variant]:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        def add(self) -> Variant.VariantListBuilder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        def languages(self, *languages: Locale) -> Variant.VariantListBuilder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        def encodings(self, *encodings: str) -> Variant.VariantListBuilder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

        def mediaTypes(self, *mediaTypes: MediaType) -> Variant.VariantListBuilder:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

    __slots__ = '__language__', '__mediaType__', '__encoding__'

    @Overload
    def __init__(self, mediaType: MediaType, language: str, encoding: str):
        if mediaType is None and language is None and encoding is None:
            raise IllegalArgumentException("mediaType, language, encoding all None")

        self.__encoding__ = encoding
        self.__language__ = None if (language is None) else Locale(language)
        self.__mediaType__ = mediaType

    @Overload
    def __init__(self, mediaType: MediaType, language: str, country: str, encoding: str):
        if mediaType is None and language is None and encoding is None:
            raise IllegalArgumentException("mediaType, language, encoding all None")

        self.__encoding__ = encoding
        self.__language__ = None if (language is None) else Locale(language, country)
        self.__mediaType__ = mediaType

    @Overload
    def __init__(self, mediaType: MediaType, language: str, country: str, languageVariant: str, encoding: str):
        if mediaType is None and language is None and encoding is None:
            raise IllegalArgumentException("mediaType, language, encoding all None")

        self.__encoding__ = encoding
        self.__language__ = None if (language is None) else Locale(language, country, languageVariant)
        self.__mediaType__ = mediaType

    @Overload
    def __init__(self, mediaType: MediaType, language: Locale, encoding: str):
        if mediaType is None and language is None and encoding is None:
            raise IllegalArgumentException("mediaType, language, encoding all None")

        self.__encoding__ = encoding
        self.__language__ = language
        self.__mediaType__ = mediaType

    def getLanguage(self) -> Locale:
        return self.__language__

    def getLanguageString(self) -> str:
        return None if (self.__language__ is None) else self.__language__.toString()

    def getMediaType(self) -> MediaType:
        return self.__mediaType__

    def getEncoding(self) -> str:
        return self.__encoding__

    @classmethod
    def mediaTypes(*mediaTypes: MediaType) -> VariantListBuilder:
        b: Variant.VariantListBuilder = Variant.VariantListBuilder.newInstance()
        b.mediaTypes(mediaTypes)
        return b

    @classmethod
    def languages(*languages: Locale) -> VariantListBuilder:
        b: Variant.VariantListBuilder = Variant.VariantListBuilder.newInstance()
        b.languages(languages)
        return b

    @classmethod
    def encodings(*encodings: str) -> VariantListBuilder:
        b: Variant.VariantListBuilder = Variant.VariantListBuilder.newInstance()
        b.encodings(encodings)
        return b

    def hashCode(self) -> int:
        h = 7
        h = 29 * h + Objects.hashCodeOf(self.__language__)
        h = 29 * h + Objects.hashCodeOf(self.__mediaType__)
        h = 29 * h + Objects.hashCodeOf(self.__encoding__)
        return h

    def equals(self, obj: object) -> bool:
        if obj is None:
            return False

        if type(self) != type(obj):
            return False

        other: Variant = cast(Variant, obj)
        if not Objects.equals(self.__language__, other.__language__):
            return False

        if not Objects.equals(self.__mediaType__, other.__mediaType__):
            return False

        return Objects.equals(self.__encoding__, other.__encoding__)

    def toString(self) -> str:
        w = StringBuilder()
        w.append("Variant[mediaType=")
        w.append("None" if self.__mediaType__ is None else self.__mediaType__.toString())
        w.append(", language=")
        w.append("None" if self.__language__ is None else self.__language__.toString())
        w.append(", encoding=")
        w.append("None" if self.__encoding__ is None else self.__encoding__)
        w.append("]")
        return w.toString()
