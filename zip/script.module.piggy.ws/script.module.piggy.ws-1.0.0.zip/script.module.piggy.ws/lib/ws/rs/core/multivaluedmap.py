from __future__ import annotations

from typing import TypeVar, List, Any

from piggy.base import UnsupportedOperationException, Overload
from piggy.base.util.map import Map

K = TypeVar('K')
V = TypeVar('V', bound=Any)


#interface
class MultivaluedMap(Map[K, List[V]]):
    def addFirst(self, key: K, value: V):
        raise UnsupportedOperationException("Called on interface.")

    def add(self, key: K, value: V):
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def addAll(self, key: K, values: List[V]):
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def addAll(self, key: K, *values: V):
        raise UnsupportedOperationException("Called on interface.")

    def getFirst(self, key: K) -> V:
        raise UnsupportedOperationException("Called on interface.")

    def putSingle(self, key: K, value: V):
        raise UnsupportedOperationException("Called on interface.")

    def equalsIgnoreValueOrder(self, other: MultivaluedMap[K, V]) -> bool:
        raise UnsupportedOperationException("Called on interface.")
