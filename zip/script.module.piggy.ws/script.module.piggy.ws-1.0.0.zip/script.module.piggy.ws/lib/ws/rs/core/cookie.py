from typing import cast

from piggy.base import IllegalArgumentException, Overload
from piggy.base.util import Objects


class Cookie:
    DEFAULT_VERSION: int = 1

    __slots__ = '_name_', '_value_', '_version_', '_path_', '_domain_'

    @Overload
    def __init__(self, name: str, value: str, path: str, domain: str, version: int):
        self._name_: str = Objects.requireNonEmptyElseRaise(name, IllegalArgumentException, "name None or blank")
        self._value_: str = value
        self._path_: str = path
        self._domain_: str = domain
        self._version_: int = version

    @Overload
    def __init__(self, name: str, value: str, path: str, domain: str):
        self.__init__(name, value, path, domain, Cookie.DEFAULT_VERSION)

    @Overload
    def __init__(self, name: str, value: str):
        self.__init__(name, value, None, None, None, Cookie.DEFAULT_VERSION)

    def getVersion(self) -> int:
        return self._version_

    def getDomain(self) -> str:
        return self._domain_

    def getName(self) -> str:
        return self._name_

    def equals(self, obj: object) -> bool:
        if obj is None:
            return False

        if type(self) != type(obj):
            return False

        other: Cookie = cast(Cookie, obj)
        if self._name_ != other._name_ and (self._name_ is None or self._name_ != other._name_):
            return False

        if self._value_ != other._value_ and (self._value_ is None or self._value_ != other._value_):
            return False

        if self._version_ != other._version_:
            return False

        if self._path_ != other._path_ and (self._path_ is None or self._path_ != other._path_):
            return False

        if self._domain_ != other._domain_ and (self._domain_ is None or self._domain_ != other._domain_):
            return False
        return True

    def toString(self) -> str:
        raise NotImplementedError("Not supported yet.")

    def hashCode(self) -> int:
        _hash_: int = 7
        _hash_ = 97 * _hash_ + Objects.hashCodeOf(self._name_)
        _hash_ = 97 * _hash_ + Objects.hashCodeOf(self._value_)
        _hash_ = 97 * _hash_ + self._version_
        _hash_ = 97 * _hash_ + Objects.hashCodeOf(self._path_)
        _hash_ = 97 * _hash_ + Objects.hashCodeOf(self._domain_)
        return _hash_

    def getValue(self) -> str:
        return self._value_

    def getPath(self) -> str:
        return self._path_
