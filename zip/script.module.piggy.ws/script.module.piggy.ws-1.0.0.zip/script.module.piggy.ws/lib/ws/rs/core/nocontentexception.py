from piggy.base import Overload, Raisable, raisable
from piggy.base.io import IOException

@raisable
class NoContentException(IOException):
   pass