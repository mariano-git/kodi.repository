from piggy.base import UnsupportedOperationException
from ws.rs.core.multivaluedmap import MultivaluedMap


# interface
class PathSegment:
    def getMatrixParameters(self) -> MultivaluedMap[str, str]:
        raise UnsupportedOperationException("Called on interface.")

    def getPath(self) -> str:
        raise UnsupportedOperationException("Called on interface.")
