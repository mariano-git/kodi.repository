from typing import Set, Type

from piggy.base.util.collections import Collections
from piggy.base.util.map import Map


class Application:

    def getClasses(self) -> Set[Type]:
        return Collections.emptySet()

    def getProperties(self) -> Map[str, object]:
        return Collections.emptyMap()

    def getSingletons(self) -> Set[object]:
        return Collections.emptySet()
