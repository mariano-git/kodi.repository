from __future__ import annotations

from piggy.base import Overload
from ws.rs.core.multivaluedmap import MultivaluedMap
from ws.rs.core.multivaluesimplemap import MultivaluedSimpleMap


class Form:
    __slots__ = '__parameters__'

    @Overload
    def __init__(self):
        self.__parameters__: MultivaluedMap[str, str] = MultivaluedSimpleMap()

    @Overload
    def __init__(self, paramName: str, paramValue: str):
        self.__init__()
        self.__parameters__.add(paramName, paramValue)

    @Overload
    def __init__(self, store: MultivaluedMap[str, str]):
        self.__init__()
        self.__parameters__ = store

    def param(self, name: str, value: str) -> Form:
        self.__parameters__.add(name, value)
        return self

    def asMap(self) -> MultivaluedMap[str, str]:
        return self.__parameters__
