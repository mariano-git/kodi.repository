from typing import List, cast

from piggy.base import UnsupportedOperationException
from piggy.base.util.map import Map
from piggy.base.util.objects import Objects
from piggy.base.util.simplemap import SimpleMap


class CacheControl:
    __slots__ = '__privateFields__', '__noCacheFields__', '__cacheExtension__', \
                '__privateFlag__', '__noCache__', '__noStore__', '__noTransform__', \
                '__mustRevalidate__', '__proxyRevalidate__', '__maxAge__', '__sMaxAge__'

    def __init__(self):
        self.__privateFields__: List[str] = None
        self.__noCacheFields__: List[str] = None
        self.__cacheExtension__: Map[str, str] = None
        self.__privateFlag__: bool = False
        self.__noCache__: bool = False
        self.__noStore__: bool = False
        self.__noTransform__: bool = False
        self.__mustRevalidate__: bool = False
        self.__proxyRevalidate__: bool = False
        self.__maxAge__: int = -1
        self.__sMaxAge__: int = -1

    def getCacheExtension(self) -> Map[str, str]:
        if self.__cacheExtension__ is None:
            self.__cacheExtension__ = SimpleMap()
        return self.__cacheExtension__

    def getMaxAge(self) -> int:
        return self.__maxAge__

    def getNoCacheFields(self) -> List[str]:
        if self.__noCacheFields__ is None:
            self.__noCacheFields__ = list()
        return self.__noCacheFields__

    def getPrivateFields(self) -> List[str]:
        if self.__privateFields__ is None:
            self.__privateFields__ = list()
        return self.__privateFields__

    def getSMaxAge(self) -> int:
        return self.__sMaxAge__

    def hashCode(self) -> int:
        _hash_ = 7
        _hash_ = 41 * _hash_ + Objects.hashCodeOf(self.__privateFlag__)
        _hash_ = 41 * _hash_ + Objects.hashCodeOf(self.__noCache__)
        _hash_ = 41 * _hash_ + Objects.hashCodeOf(self.__noStore__)
        _hash_ = 41 * _hash_ + Objects.hashCodeOf(self.__noTransform__)
        _hash_ = 41 * _hash_ + Objects.hashCodeOf(self.__mustRevalidate__)
        _hash_ = 41 * _hash_ + Objects.hashCodeOf(self.__proxyRevalidate__)
        _hash_ = 41 * _hash_ + Objects.hashCodeOf(self.__maxAge__)
        _hash_ = 41 * _hash_ + Objects.hashCodeOf(self.__sMaxAge__)
        _hash_ = 41 * _hash_ + Objects.hashCodeOf(self.__privateFields__)
        _hash_ = 41 * _hash_ + Objects.hashCodeOf(self.__noCacheFields__)
        _hash_ = 41 * _hash_ + Objects.hashCodeOf(self.__cacheExtension__)
        return _hash_

    def isMustRevalidate(self) -> bool:
        return self.__mustRevalidate__

    def isNoCache(self) -> bool:
        return self.__noCache__

    def isNoStore(self) -> bool:
        return self.__noStore__

    def isNoTransform(self) -> bool:
        return self.__noTransform__

    def isPrivate(self) -> bool:
        return self.__privateFlag__

    def isProxyRevalidate(self) -> bool:
        return self.__proxyRevalidate__

    def setMaxAge(self, maxAge: int):
        self.__maxAge__ = maxAge

    def setMustRevalidate(self, mustRevalidate: bool):
        self.__mustRevalidate__ = mustRevalidate

    def setNoCache(self, noCache: bool):
        self.__noCache__ = noCache

    def setNoStore(self, noStore: bool):
        self.__noStore__ = noStore

    def setNoTransform(self, noTransform: bool):
        self.__noTransform__ = noTransform

    def setPrivate(self, flag: bool):
        self.__privateFlag__ = flag

    def setProxyRevalidate(self, proxyRevalidate: bool):
        self.__proxyRevalidate__ = proxyRevalidate

    def setSMaxAge(self, sMaxAge: int):
        self.__sMaxAge__ = sMaxAge

    def toString(self) -> str:
        raise UnsupportedOperationException("Not supported yet.")

    def equals(self, obj: object) -> bool:

        if obj is None:
            return False

        if type(self) != type(obj):
            return False

        other: CacheControl = cast(CacheControl, obj)
        if self.__privateFlag__ != other.__privateFlag__:
            return False

        if self.__noCache__ != other.__noCache__:
            return False

        if self.__noStore__ != other.__noStore__:
            return False

        if self.__noTransform__ != other.__noTransform__:
            return False

        if self.__mustRevalidate__ != other.__mustRevalidate__:
            return False

        if self.__proxyRevalidate__ != other.__proxyRevalidate__:
            return False

        if self.__maxAge__ != other.__maxAge__:
            return False

        if self.__sMaxAge__ != other.__sMaxAge__:
            return False

        if not Objects.equals(self.__privateFields__, other.__privateFields__):
            return False

        if not Objects.equals(self.__noCacheFields__, other.__noCacheFields__):
            return False

        if not Objects.equals(self.__cacheExtension__, other.__cacheExtension__):
            return False

        return True
