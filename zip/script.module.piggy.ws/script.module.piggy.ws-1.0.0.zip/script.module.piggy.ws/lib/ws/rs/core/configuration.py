from typing import Set, Type, Collection

from piggy.base import Overload, UnsupportedOperationException
from piggy.base.util.map import Map

from ws.rs.runtimetype import RuntimeType


# interface
class Configuration:
    @Overload
    def isEnabled(self, feature: 'Feature') -> bool:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def isEnabled(self, featureType: Type['Feature']) -> bool:
        raise UnsupportedOperationException("Called on interface.")

    def getProperty(self, name: str) -> object:
        raise UnsupportedOperationException("Called on interface.")

    def getClasses(self) -> Set[Type]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def isRegistered(self, provider: object) -> bool:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def isRegistered(self, provider: Type) -> bool:
        raise UnsupportedOperationException("Called on interface.")

    def getProperties(self) -> Map[str, object]:
        raise UnsupportedOperationException("Called on interface.")

    def getPropertyNames(self) -> Collection[str]:
        raise UnsupportedOperationException("Called on interface.")

    def getRuntimeType(self) -> RuntimeType:
        raise UnsupportedOperationException("Called on interface.")

    def getContracts(self, providerType: Type) -> Map[type, int]:
        raise UnsupportedOperationException("Called on interface.")

    def getInstances(self) -> Set[object]:
        raise UnsupportedOperationException("Called on interface.")
