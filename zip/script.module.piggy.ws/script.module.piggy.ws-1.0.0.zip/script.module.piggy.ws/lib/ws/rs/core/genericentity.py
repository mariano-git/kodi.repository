from typing import TypeVar, Generic, Type, cast

from piggy.base import IllegalArgumentException, Overload
from piggy.base.util.objects import Objects

T = TypeVar('T')


class GenericEntity(Generic[T]):
    __slots__ = '__rawType__', '__type__', '__entity__'

    @Overload
    def __init__(self, entity: T):
        if entity is None:
            raise IllegalArgumentException("The entity must not be null")

        self.__entity__ = entity
        self.__type__ = type(entity)
        self.__rawType__ = entity.__class__

    @Overload
    def __init__(self, entity: T, genericType: Type):
        if entity is None or genericType is None:
            raise IllegalArgumentException("Arguments must not be null.")

        self.__entity__ = entity
        self.__rawType__ = entity.__class__
        self._checkTypeCompatibility(self.__rawType__, genericType)
        self.__type__ = genericType

    def _checkTypeCompatibility(self, c: Type, t: Type):
        if c == t:
            return

        raise IllegalArgumentException("The type is incompatible with the class of the entity.")

    def getRawType(self) -> Type:
        return self.__rawType__

    def getType(self) -> Type:
        return self.__type__

    def getEntity(self) -> T:
        return self.__entity__

    def equals(self, obj: object):
        result = self == obj
        if not result and isinstance(obj, GenericEntity):
            # Compare inner type for equality
            that: GenericEntity = cast(GenericEntity, obj)
            return self.__type__ == that.__type__ and self.__entity__ == that.__entity__

        return result

    def hashCode(self) -> int:
        return Objects.hashCodeOf(self.__entity__) + Objects.hashCodeOf(self.__type__) * 37 + 5

    def toString(self) -> str:
        return f"GenericEntity({self.__entity__}, {self.__type__})"
