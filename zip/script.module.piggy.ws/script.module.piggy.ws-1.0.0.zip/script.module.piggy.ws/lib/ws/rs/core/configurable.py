from typing import Type, Generic, TypeVar

from piggy.base import Overload, UnsupportedOperationException
from piggy.base.util.map import Map
from ws.rs.core.configuration import Configuration

C = TypeVar('C')


class Configurable(Generic[C]):
    @Overload
    def register(self, provider: Type, *contracts: Type) -> C:
        raise UnsupportedOperationException("Called on interface")

    @Overload
    def register(self, provider: object, contracts: Map[Type, int]) -> C:
        raise UnsupportedOperationException("Called on interface")

    @Overload
    def register(self, provider: object) -> C:
        raise UnsupportedOperationException("Called on interface")

    @Overload
    def register(self, provider: object, priority: int) -> C:
        raise UnsupportedOperationException("Called on interface")

    @Overload
    def register(self, provider: object, *contracts: Type) -> C:
        raise UnsupportedOperationException("Called on interface")

    @Overload
    def register(self, provider: Type, priority: int) -> C:
        raise UnsupportedOperationException("Called on interface")

    @Overload
    def register(self, provider: Type) -> C:
        raise UnsupportedOperationException("Called on interface")

    @Overload
    def register(self, provider: Type, contracts: Map[Type, int]) -> C:
        raise UnsupportedOperationException("Called on interface")

    def getConfiguration(self) -> Configuration:
        raise UnsupportedOperationException("Called on interface")

    def property(self, name: str, value: object) -> C:
        raise UnsupportedOperationException("Called on interface")
