from typing import cast

from piggy.base import IllegalArgumentException, Overload
from piggy.base.util.objects import Objects


class EntityTag:
    __slots__ = '__value__', '__weak__'

    @Overload
    def __init__(self, value: str):
        self.__init__(value, False)

    @Overload
    def __init__(self, value: str, weak: bool):
        if value is None:
            raise IllegalArgumentException("value==null")
        self.__value__ = value
        self.__weak__ = weak

    def getValue(self) -> str:
        return self.__value__

    def isWeak(self) -> bool:
        return self.__weak__

    def equals(self, obj: object) -> bool:
        if not isinstance(obj, EntityTag):
            return False

        other: EntityTag = cast(EntityTag, obj)
        return Objects.equals(self.getValue(), other.getValue()) and self.isWeak() == other.isWeak()

    def hashCode(self) -> int:
        return Objects.hashCodeOf(self.getValue(), self.isWeak())
