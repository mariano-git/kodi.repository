from __future__ import annotations

import typing
from typing import Type, TypeVar, Generic

from piggy.base import UnsupportedOperationException, IllegalArgumentException

T = TypeVar('T')


class GenericType(Generic[T]):
    __slots__ = '__type__', '__rawType__'

    def __init__(self, genericType: Type):
        if genericType is None:
            raise IllegalArgumentException("Type must not be null")
        self.__type__ = genericType
        self.__rawType__ = self.__getClass__(genericType)

    def equals(self, obj: object) -> bool:
        raise UnsupportedOperationException("Not supported yet.")

    @classmethod
    def forInstance(cls, instance: object) -> GenericType:
        raise UnsupportedOperationException("Not supported yet.")

    def getRawType(self) -> Type:
        return self.__rawType__

    def getType(self) -> Type:
        return self.__type__

    def hashCode(self) -> int:
        raise UnsupportedOperationException("Not supported yet.")

    def toString(self) -> str:
        return f"GenericType: {self.__type__}"

    def __getClass__(self, clsType):

        if isinstance(clsType, type):
            return clsType
        origin = typing.get_origin(clsType)
        if origin:
            return origin
        raise IllegalArgumentException(f'Type parameter: "{clsType}" '
                                       f'not a class or parameterized type whose raw type is a class')


