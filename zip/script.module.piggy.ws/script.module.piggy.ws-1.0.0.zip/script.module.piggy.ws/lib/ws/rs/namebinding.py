from piggy.base.notation import Target, ElementType, AnnotationType


@Target({ElementType.ANNOTATION_TYPE})
class NameBinding(AnnotationType):
    pass
