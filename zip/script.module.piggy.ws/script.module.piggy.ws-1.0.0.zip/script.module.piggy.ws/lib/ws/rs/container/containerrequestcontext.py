from typing import Collection, List

from piggy.base import UnsupportedOperationException, Overload
from piggy.base.io.inputstream import InputStream
from piggy.base.net.uri import URI
from piggy.base.util.date import Date
from piggy.base.util.locale import Locale
from piggy.base.util.map import Map
from ws.rs.core.cookie import Cookie
from ws.rs.core.mediatype import MediaType
from ws.rs.core.multivaluedmap import MultivaluedMap
from ws.rs.core.request import Request
from ws.rs.core.response import Response
from ws.rs.core.securitycontext import SecurityContext
from ws.rs.core.uriinfo import UriInfo


class ContainerRequestContext:
    def abortWith(self, response: Response):
        raise UnsupportedOperationException("Called on interface.")

    def getAcceptableLanguages(self) -> List[Locale]:
        raise UnsupportedOperationException("Called on interface.")

    def getAcceptableMediaTypes(self) -> List[MediaType]:
        raise UnsupportedOperationException("Called on interface.")

    def getCookies(self) -> Map[str, Cookie]:
        raise UnsupportedOperationException("Called on interface.")

    def getDate(self) -> Date:
        raise UnsupportedOperationException("Called on interface.")

    def getEntityStream(self) -> InputStream:
        raise UnsupportedOperationException("Called on interface.")

    def getHeaderString(self, name: str) -> str:
        raise UnsupportedOperationException("Called on interface.")

    def getHeaders(self) -> MultivaluedMap[str, str]:
        raise UnsupportedOperationException("Called on interface.")

    def getLanguage(self) -> Locale:
        raise UnsupportedOperationException("Called on interface.")

    def getLength(self) -> int:
        raise UnsupportedOperationException("Called on interface.")

    def getMediaType(self) -> MediaType:
        raise UnsupportedOperationException("Called on interface.")

    def getMethod(self) -> str:
        raise UnsupportedOperationException("Called on interface.")

    def getProperty(self, name: str) -> object:
        raise UnsupportedOperationException("Called on interface.")

    def getPropertyNames(self) -> Collection[str]:
        raise UnsupportedOperationException("Called on interface.")

    def getRequest(self) -> Request:
        raise UnsupportedOperationException("Called on interface.")

    def getSecurityContext(self) -> SecurityContext:
        raise UnsupportedOperationException("Called on interface.")

    def getUriInfo(self) -> UriInfo:
        raise UnsupportedOperationException("Called on interface.")

    def hasEntity(self) -> bool:
        raise UnsupportedOperationException("Called on interface.")

    def removeProperty(self, name: str):
        raise UnsupportedOperationException("Called on interface.")

    def setEntityStream(self, input: InputStream):
        raise UnsupportedOperationException("Called on interface.")

    def setMethod(self, method: str):
        raise UnsupportedOperationException("Called on interface.")

    def setProperty(self, name: str, value: object):
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def setRequestUri(self, baseUri: URI, requestUri: URI):
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def setRequestUri(self, requestUri: URI):
        raise UnsupportedOperationException("Called on interface.")

    def setSecurityContext(self, context: SecurityContext):
        raise UnsupportedOperationException("Called on interface.")
