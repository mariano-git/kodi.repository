# interface
from typing import Type

from piggy.base import UnsupportedOperationException


class ResourceContext:
    def getResource(self, resourceClass: Type) -> object:
        raise UnsupportedOperationException("Called on interface.")

    def initResource(self, resource: object) -> object:
        raise UnsupportedOperationException("Called on interface.")
