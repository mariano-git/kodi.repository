# interface
from piggy.base import UnsupportedOperationException
from ws.rs.container.containerrequestcontext import ContainerRequestContext
from ws.rs.container.containerresponsecontext import ContainerResponseContext


class ContainerResponseFilter:
	def filter(self, requestContext:ContainerRequestContext, responseContext:ContainerResponseContext):
		raise UnsupportedOperationException("Called on interface.")
