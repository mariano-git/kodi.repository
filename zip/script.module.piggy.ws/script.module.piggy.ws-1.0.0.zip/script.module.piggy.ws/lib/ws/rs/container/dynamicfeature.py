# interface
from piggy.base import UnsupportedOperationException
from ws.rs.container.resourceinfo import ResourceInfo
from ws.rs.core.featurecontext import FeatureContext


class DynamicFeature:
	def configure(self, resourceInfo:ResourceInfo, context:FeatureContext):
		raise UnsupportedOperationException("Called on interface.")
