from piggy.base import Overload, Raisable
from ws.rs.core.response import Response
from ws.rs.webapplicationexception import WebApplicationException


class ServerErrorException(WebApplicationException):

    @Overload
    def __init__(self, status: Response.Status):
        super().__init__(None, self._validate(Response.status(status).build(), Response.Status.Family.SERVER_ERROR))

    @Overload
    def __init__(self, message: str, status: Response.Status):
        super().__init__(message, None,
                         self._validate(Response.status(status).build(), Response.Status.Family.SERVER_ERROR))

    @Overload
    def __init__(self, status: int):
        super().__init__(None, self._validate(Response.status(status).build(), Response.Status.Family.SERVER_ERROR))

    @Overload
    def __init__(self, message: str, status: int):
        super().__init__(message, None,
                         self._validate(Response.status(status).build(), Response.Status.Family.SERVER_ERROR))

    @Overload
    def __init__(self, response: Response):
        super().__init__(None, self._validate(response, Response.Status.Family.SERVER_ERROR))

    @Overload
    def __init__(self, message: str, response: Response):
        super().__init__(message, None, self._validate(response, Response.Status.Family.SERVER_ERROR))

    @Overload
    def __init__(self, status: Response.Status, cause: Raisable):
        super().__init__(cause, self._validate(Response.status(status).build(), Response.Status.Family.SERVER_ERROR))

    @Overload
    def __init__(self, message: str, status: Response.Status, cause: Raisable):
        super().__init__(message, cause,
                         self._validate(Response.status(status).build(), Response.Status.Family.SERVER_ERROR))

    @Overload
    def __init__(self, status: int, cause: Raisable):
        super().__init__(cause, self._validate(Response.status(status).build(), Response.Status.Family.SERVER_ERROR))

    @Overload
    def __init__(self, message: str, status: int, cause: Raisable):
        super().__init__(message, cause,
                         self._validate(Response.status(status).build(), Response.Status.Family.SERVER_ERROR))

    @Overload
    def __init__(self, response: Response, cause: Raisable):
        super().__init__(cause, self._validate(response, Response.Status.Family.SERVER_ERROR))

    @Overload
    def __init__(self, message: str, response: Response, cause: Raisable):
        super().__init__(message, cause, self._validate(response, Response.Status.Family.SERVER_ERROR))
