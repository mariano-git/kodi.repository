# interface
from piggy.base import UnsupportedOperationException
from piggy.base.notation import Target, ElementType, AnnotationType


@Target({ElementType.PARAMETER, ElementType.METHOD, ElementType.FIELD})
class DefaultValue(AnnotationType):
    def value(self) -> str:
        raise UnsupportedOperationException("Called on interface.")
