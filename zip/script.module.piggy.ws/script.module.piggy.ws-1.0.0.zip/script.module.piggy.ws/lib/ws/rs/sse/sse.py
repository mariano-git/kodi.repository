from piggy.base import IllegalArgumentException, UnsupportedOperationException, Overload
from ws.rs.sse.outboundsseevent import OutboundSseEvent
from ws.rs.sse.ssebroadcaster import SseBroadcaster


class Sse:
    def newBroadcaster(self) -> SseBroadcaster:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def newEvent(self, name: str, data: str) -> OutboundSseEvent:
        if data is None:
            raise IllegalArgumentException("Parameter 'data' must not be null.")
        if name is None:
            raise IllegalArgumentException("Parameter 'name' must not be null.")
        return self.newEventBuilder().data(str, data).name(name).build()

    @Overload
    def newEvent(self, data: str) -> OutboundSseEvent:
        if data is None:
            raise IllegalArgumentException("Parameter 'data' must not be null.")
        return self.newEventBuilder().data(str, data).build()

    def newEventBuilder(self) -> OutboundSseEvent.Builder:
        raise UnsupportedOperationException("Called on interface.")
