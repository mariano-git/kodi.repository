from __future__ import annotations

from typing import Type

from piggy.base import UnsupportedOperationException, Overload
from ws.rs.core.generictype import GenericType
from ws.rs.core.mediatype import MediaType
from ws.rs.sse.sseevent import SseEvent


class OutboundSseEvent(SseEvent):
    # interface
    class Builder:
        def mediaType(self, mediaType: MediaType) -> OutboundSseEvent.Builder:
            raise UnsupportedOperationException("Called on interface.")

        def reconnectDelay(self, milliseconds: int) -> OutboundSseEvent.Builder:
            raise UnsupportedOperationException("Called on interface.")

        def name(self, name: str) -> OutboundSseEvent.Builder:
            raise UnsupportedOperationException("Called on interface.")

        @Overload
        def data(self, typ: Type, data: object) -> OutboundSseEvent.Builder:
            raise UnsupportedOperationException("Called on interface.")

        @Overload
        def data(self, data: object) -> OutboundSseEvent.Builder:
            raise UnsupportedOperationException("Called on interface.")

        @Overload
        def data(self, typ: GenericType, data: object) -> OutboundSseEvent.Builder:
            raise UnsupportedOperationException("Called on interface.")

        def id(self, id: str) -> OutboundSseEvent.Builder:
            raise UnsupportedOperationException("Called on interface.")

        def comment(self, comment: str) -> OutboundSseEvent.Builder:
            raise UnsupportedOperationException("Called on interface.")

        def build(self) -> OutboundSseEvent:
            raise UnsupportedOperationException("Called on interface.")

    # --------------------------------
    def getData(self) -> object:
        raise UnsupportedOperationException("Called on interface.")

    def getGenericType(self) -> Type:
        raise UnsupportedOperationException("Called on interface.")

    def getMediaType(self) -> MediaType:
        raise UnsupportedOperationException("Called on interface.")

    def getType(self) -> Type:
        raise UnsupportedOperationException("Called on interface.")
