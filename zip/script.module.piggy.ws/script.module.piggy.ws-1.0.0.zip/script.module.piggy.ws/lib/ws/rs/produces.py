from typing import Set

from piggy.base.notation import ElementType, Target, AnnotationType


@Target({ElementType.TYPE, ElementType.METHOD})
class Produces(AnnotationType):
    def value(self) -> Set[str]:
        return {"*/*"}
