from __future__ import annotations

from threading import Lock
from typing import Type, Generic, TypeVar

from piggy.base import UnsupportedOperationException

from ws.rs.core.application import Application
from ws.rs.core.link import Link

T = TypeVar('T')


class RuntimeDelegate:
    # interface
    class HeaderDelegate(Generic[T]):

        def toString(self, value: T) -> str:
            raise UnsupportedOperationException("Called on interface.")

        def fromString(self, value: str) -> T:
            raise UnsupportedOperationException("Called on interface.")

    __cacheDelegate__: RuntimeDelegate = None
    __lock__: Lock = Lock()

    @staticmethod
    def getInstance() -> RuntimeDelegate:
        if RuntimeDelegate.__cacheDelegate__:
            return RuntimeDelegate.__cacheDelegate__
        # FIXME This should be configurable to allow loading of different delegates
        from piggy.restful.ext.piggyruntimedelegate import PiggyRuntimeDelegate
        delegate = PiggyRuntimeDelegate  # Class.forName('piggy.restful.bad.container.piggyruntimedelegate.PiggyRuntimeDelegate')
        RuntimeDelegate.setInstance(object.__new__(delegate))

        return RuntimeDelegate.__cacheDelegate__

    def createEndpoint(self, application: Application, endpoint: Type) -> object:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def createHeaderDelegate(self, cls: Type) -> RuntimeDelegate.HeaderDelegate:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def createLinkBuilder(self) -> Link.Builder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def createResponseBuilder(self) -> 'Response.ResponseBuilder':
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def createUriBuilder(self) -> 'UriBuilder':
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def createVariantListBuilder(self) -> 'Variant.VariantListBuilder':
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    @staticmethod
    def setInstance(delegate: RuntimeDelegate):
        if delegate and isinstance(delegate, RuntimeDelegate):
            with RuntimeDelegate.__lock__:
                RuntimeDelegate.__cacheDelegate__ = delegate
