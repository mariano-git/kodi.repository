from typing import Generic, TypeVar

from piggy.base import UnsupportedOperationException
from piggy.base.notation import Annotation, Target, ElementType, AnnotationType

T = TypeVar('T')


class ParamConverter(Generic[T]):
    # interface
    @Target({ElementType.TYPE})
    class Lazy(AnnotationType):
        pass

    # --------------------------------
    def fromString(self, value: str) -> T:
        raise UnsupportedOperationException("Called on interface.")

    def toString(self, value: T) -> str:
        raise UnsupportedOperationException("Called on interface.")
