# interface
from piggy.base import UnsupportedOperationException
from piggy.base.io.inputstream import InputStream
from ws.rs.core.multivaluedmap import MultivaluedMap
from ws.rs.ext.interceptorcontext import InterceptorContext


class ReaderInterceptorContext(InterceptorContext):
    def getHeaders(self) -> MultivaluedMap[str, str]:
        raise UnsupportedOperationException("Called on interface.")

    def getInputStream(self) -> InputStream:
        raise UnsupportedOperationException("Called on interface.")

    def proceed(self) -> object:
        raise UnsupportedOperationException("Called on interface.")

    def setInputStream(self, input: InputStream):
        raise UnsupportedOperationException("Called on interface.")
