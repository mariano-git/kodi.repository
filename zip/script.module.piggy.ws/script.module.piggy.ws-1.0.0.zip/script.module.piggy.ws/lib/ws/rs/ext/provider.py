from piggy.base.notation import Annotation, Target, ElementType


@Target({ElementType.TYPE})
class Provider:
    pass
