from piggy.base import UnsupportedOperationException
from piggy.base.io.outputstream import OutputStream
from ws.rs.core.multivaluedmap import MultivaluedMap
from ws.rs.ext.interceptorcontext import InterceptorContext


class WriterInterceptorContext(InterceptorContext):
    def getEntity(self) -> object:
        raise UnsupportedOperationException("Called on interface.")

    def getHeaders(self) -> MultivaluedMap[str, object]:
        raise UnsupportedOperationException("Called on interface.")

    def getOutputStream(self) -> OutputStream:
        raise UnsupportedOperationException("Called on interface.")

    def proceed(self):
        raise UnsupportedOperationException("Called on interface.")

    def setEntity(self, entity: object):
        raise UnsupportedOperationException("Called on interface.")

    def setOutputStream(self, output: OutputStream):
        raise UnsupportedOperationException("Called on interface.")
