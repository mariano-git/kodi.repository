from piggy.base import UnsupportedOperationException
from ws.rs.ext.readerinterceptorcontext import ReaderInterceptorContext


class ReaderInterceptor:
    def aroundReadFrom(self, context: ReaderInterceptorContext) -> object:
        raise UnsupportedOperationException("Called on interface.")
