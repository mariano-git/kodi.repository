# interface
from typing import List, Type, Collection

from piggy.base import UnsupportedOperationException
from piggy.base.notation import Annotation
from ws.rs.core.mediatype import MediaType


class InterceptorContext:
    def getAnnotations(self) -> List[Annotation]:
        raise UnsupportedOperationException("Called on interface.")

    def getGenericType(self) -> Type:
        raise UnsupportedOperationException("Called on interface.")

    def getMediaType(self) -> MediaType:
        raise UnsupportedOperationException("Called on interface.")

    def getProperty(self, name: str) -> object:
        raise UnsupportedOperationException("Called on interface.")

    def getPropertyNames(self) -> Collection[str]:
        raise UnsupportedOperationException("Called on interface.")

    def getType(self) -> Type:
        raise UnsupportedOperationException("Called on interface.")

    def removeProperty(self, name: str):
        raise UnsupportedOperationException("Called on interface.")

    def setAnnotations(self, annotations: List[Annotation]):
        raise UnsupportedOperationException("Called on interface.")

    def setGenericType(self, typ: Type):
        raise UnsupportedOperationException("Called on interface.")

    def setMediaType(self, mediaType: MediaType):
        raise UnsupportedOperationException("Called on interface.")

    def setProperty(self, name: str, value: object):
        raise UnsupportedOperationException("Called on interface.")

    def setType(self, typ: Type):
        raise UnsupportedOperationException("Called on interface.")
