from piggy.base.notation import Target, ElementType, AnnotationType


@Target({ElementType.TYPE, ElementType.METHOD})
class Path(AnnotationType):
    def value(self) -> str:
        pass
