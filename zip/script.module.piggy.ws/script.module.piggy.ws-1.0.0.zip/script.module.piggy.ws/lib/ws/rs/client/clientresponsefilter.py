from piggy.base import UnsupportedOperationException
from ws.rs.client.clientrequestcontext import ClientRequestContext
from ws.rs.client.clientresponsecontext import ClientResponseContext


class ClientResponseFilter:
    def filter(self, requestContext: ClientRequestContext, responseContext: ClientResponseContext):
        raise UnsupportedOperationException("Called on interface.")
