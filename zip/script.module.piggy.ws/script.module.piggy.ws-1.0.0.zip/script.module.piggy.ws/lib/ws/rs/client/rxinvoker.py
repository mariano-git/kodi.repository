# interface
from typing import TypeVar, Type, Generic

from piggy.base import UnsupportedOperationException, Overload
from ws.rs.client.entity import Entity
from ws.rs.core.generictype import GenericType

T = TypeVar('T')
R = TypeVar('R')


class RxInvoker(Generic[T]):
    @Overload
    def get(self) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def get(self, responseType: Type[R]) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def get(self, responseType: GenericType[R]) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def put(self, entity: Entity) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def put(self, entity: Entity, responseType: Type[R]) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def put(self, entity: Entity, responseType: GenericType[R]) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def post(self, entity: Entity) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def post(self, entity: Entity, responseType: Type[R]) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def post(self, entity: Entity, responseType: GenericType[R]) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def delete(self) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def delete(self, responseType: Type[R]) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def delete(self, responseType: GenericType[R]) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def head(self) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def options(self) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def options(self, responseType: Type[R]) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def options(self, responseType: GenericType[R]) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def trace(self) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def trace(self, responseType: Type[R]) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def trace(self, responseType: GenericType[R]) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def method(self, name: str) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def method(self, name: str, responseType: Type[R]) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def method(self, name: str, responseType: GenericType[R]) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def method(self, name: str, entity: Entity) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def method(self, name: str, entity: Entity, responseType: Type[R]) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def method(self, name: str, entity: Entity, responseType: GenericType[R]) -> T:
        raise UnsupportedOperationException("Called on interface.")
