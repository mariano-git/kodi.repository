from __future__ import annotations

from typing import Union

from piggy.base import UnsupportedOperationException, Overload
from piggy.base.util.concurrent.timeunit import TimeUnit


from ws.rs.client.client import Client
from ws.rs.core.configurable import Configurable
from ws.rs.core.configuration import Configuration


# abstract
class ClientBuilder(Configurable['ClientBuilder']):

    # abstract
    def build(self) -> Client:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    # abstract
    def connectTimeout(self, timeout: int, unit: TimeUnit) -> ClientBuilder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def executorService(self, executorService: 'ExecutorService') -> ClientBuilder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def hostnameVerifier(self, verifier: 'HostnameVerifier') -> ClientBuilder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def keyStore(self, keyStore: 'KeyStore', password: Union[str, bytes]) -> ClientBuilder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    # abstract
    def readTimeout(self, timeout: int, unit: TimeUnit) -> ClientBuilder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def scheduledExecutorService(self, scheduledExecutorService: 'ScheduledExecutorService') -> ClientBuilder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def sslContext(self, sslContext: 'SSLContext') -> ClientBuilder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def trustStore(self, trustStore: 'KeyStore') -> ClientBuilder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    # abstract
    def withConfig(self, config: Configuration) -> ClientBuilder:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    @classmethod
    def newBuilder(cls) -> ClientBuilder:
        from piggy.restful.client.piggyclientbuilder import PiggyClientBuilder
        return PiggyClientBuilder()

    @Overload
    @classmethod
    def newClient(cls) -> Client:
        return cls.newBuilder().build()

    @Overload
    @classmethod
    def newClient(cls, configuration: Configuration) -> Client:
        return cls.newBuilder().withConfig(configuration).build()
