# interface
from typing import Type, TypeVar

from piggy.base import UnsupportedOperationException, Overload
from piggy.base.util.concurrent.completionstage import CompletionStage
from ws.rs.client.entity import Entity
from ws.rs.client.rxinvoker import RxInvoker
from ws.rs.core.generictype import GenericType
from ws.rs.core.response import Response

T = TypeVar('T')


class CompletionStageRxInvoker(RxInvoker[CompletionStage]):

    @Overload
    def get(self) -> CompletionStage[Response]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def get(self, responseType: Type[T]) -> CompletionStage[T]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def get(self, responseType: GenericType[T]) -> CompletionStage[T]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def put(self, entity: Entity) -> CompletionStage[T]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def put(self, entity: Entity, typ: Type[T]) -> CompletionStage[T]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def put(self, entity: Entity, typ: GenericType[T]) -> CompletionStage[T]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def post(self, entity: Entity) -> CompletionStage[Response]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def post(self, entity: Entity, typ: Type[T]) -> CompletionStage[T]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def post(self, entity: Entity, typ: GenericType[T]) -> CompletionStage[T]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def delete(self) -> CompletionStage[Response]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def delete(self, responseType: Type[T]) -> CompletionStage[T]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def delete(self, responseType: GenericType[T]) -> CompletionStage[T]:
        raise UnsupportedOperationException("Called on interface.")

    def head(self) -> CompletionStage[T]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def options(self) -> CompletionStage[Response]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def options(self, responseType: Type[T]) -> CompletionStage[T]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def options(self, responseType: GenericType[T]) -> CompletionStage[T]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def trace(self) -> CompletionStage[Response]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def trace(self, responseType: Type[T]) -> CompletionStage[T]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def trace(self, responseType: GenericType[T]) -> CompletionStage[T]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def method(self, name: str) -> CompletionStage[Response]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def method(self, name: str, responseType: Type[T]) -> CompletionStage[T]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def method(self, name: str, responseType: GenericType[T]) -> CompletionStage[T]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def method(self, name: str, entity: Entity) -> CompletionStage[Response]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def method(self, name: str, entity: Entity, responseType: Type[T]) -> CompletionStage[T]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def method(self, name: str, entity: Entity, responseType: GenericType[T]) -> CompletionStage[T]:
        raise UnsupportedOperationException("Called on interface.")
