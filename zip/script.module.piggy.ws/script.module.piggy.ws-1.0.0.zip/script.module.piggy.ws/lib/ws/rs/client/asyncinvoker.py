# interface

from typing import Type, TypeVar

from piggy.base import UnsupportedOperationException, Overload
from piggy.base.util.concurrent.future import Future
from ws.rs.client.entity import Entity
from ws.rs.client.invocationcallback import InvocationCallback
from ws.rs.core.generictype import GenericType
from ws.rs.core.response import Response

T = TypeVar('T')


class AsyncInvoker:

    # GET
    @Overload
    def get(self) -> Future[Response]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def get(self, responseType: Type[T]) -> Future[T]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def get(self, responseType: GenericType[T]) -> Future[T]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def get(self, callback: InvocationCallback[T]) -> Future[T]:
        raise UnsupportedOperationException("Called on interface.")

    # PUT
    @Overload
    def put(self, entity: Entity) -> Future[Response]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def put(self, entity: Entity, responseType: Type[T]) -> Future[T]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def put(self, entity: Entity, responseType: GenericType[T]) -> Future[T]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def put(self, entity: Entity, callback: InvocationCallback[T]) -> Future[T]:
        raise UnsupportedOperationException("Called on interface.")

    # POST
    @Overload
    def post(self, entity: Entity) -> Future[Response]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def post(self, entity: Entity, responseType: Type[T]) -> Future[T]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def post(self, entity: Entity, responseType: GenericType[T]) -> Future[T]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def post(self, entity: Entity, callback: InvocationCallback[T]) -> Future[T]:
        raise UnsupportedOperationException("Called on interface.")

    # DELETE
    @Overload
    def delete(self) -> Future[Response]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def delete(self, responseType: Type[T]) -> Future[T]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def delete(self, responseType: GenericType[T]) -> Future[T]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def delete(self, callback: InvocationCallback[T]) -> Future[T]:
        raise UnsupportedOperationException("Called on interface.")

    # HEAD
    @Overload
    def head(self) -> Future[Response]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def head(self, callback: InvocationCallback[Response]) -> Future[Response]:
        raise UnsupportedOperationException("Called on interface.")

    # OPTIONS
    @Overload
    def options(self) -> Future[Response]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def options(self, responseType: Type[T]) -> Future[T]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def options(self, responseType: GenericType[T]) -> Future[T]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def options(self, callback: InvocationCallback[T]) -> Future[T]:
        raise UnsupportedOperationException("Called on interface.")

    # TRACE
    @Overload
    def trace(self) -> Future[Response]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def trace(self, responseType: Type[T]) -> Future[T]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def trace(self, responseType: GenericType[T]) -> Future[T]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def trace(self, callback: InvocationCallback[T]) -> Future[T]:
        raise UnsupportedOperationException("Called on interface.")

    # ARBITRARY METHOD
    @Overload
    def method(self, name: str) -> Future[Response]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def method(self, name: str, responseType: Type[T]) -> Future[T]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def method(self, name: str, responseType: GenericType[T]) -> Future[T]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def method(self, name: str, callback: InvocationCallback[T]) -> Future[T]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def method(self, name: str, entity: Entity) -> Future[Response]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def method(self, name: str, entity: Entity, responseType: Type[T]) -> Future[T]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def method(self, name: str, entity: Entity, responseType: GenericType[T]) -> Future[T]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def method(self, name: str, entity: Entity, callback: InvocationCallback[T]) -> Future[T]:
        raise UnsupportedOperationException("Called on interface.")
