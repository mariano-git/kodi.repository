from __future__ import annotations

from concurrent.futures import Future
from typing import TypeVar, Type

from piggy.base import Overload, UnsupportedOperationException
from piggy.base.util.locale import Locale
from ws.rs.client.asyncinvoker import AsyncInvoker
from ws.rs.client.completionstagerxinvoker import CompletionStageRxInvoker
from ws.rs.client.entity import Entity
from ws.rs.client.invocationcallback import InvocationCallback
from ws.rs.client.rxinvoker import RxInvoker
from ws.rs.client.syncinvoker import SyncInvoker
from ws.rs.core.cachecontrol import CacheControl
from ws.rs.core.cookie import Cookie
from ws.rs.core.generictype import GenericType
from ws.rs.core.mediatype import MediaType
from ws.rs.core.multivaluedmap import MultivaluedMap
from ws.rs.core.response import Response

T = TypeVar('T')


# interface
class Invocation:
    # interface
    class Builder(SyncInvoker):
        @Overload
        def accept(self, *mediaTypes: str) -> Invocation.Builder:
            raise UnsupportedOperationException("Called on interface.")

        @Overload
        def accept(self, *mediaTypes: MediaType) -> Invocation.Builder:
            raise UnsupportedOperationException("Called on interface.")

        @Overload
        def build(self, method: str) -> Invocation:
            raise UnsupportedOperationException("Called on interface.")

        @Overload
        def build(self, method: str, entity: Entity) -> Invocation:
            raise UnsupportedOperationException("Called on interface.")

        def property(self, name: str, value: object) -> Invocation.Builder:
            raise UnsupportedOperationException("Called on interface.")

        def buildGet(self) -> Invocation:
            raise UnsupportedOperationException("Called on interface.")

        def buildDelete(self) -> Invocation:
            raise UnsupportedOperationException("Called on interface.")

        def buildPost(self, entity: Entity) -> Invocation:
            raise UnsupportedOperationException("Called on interface.")

        def buildPut(self, entity: Entity) -> Invocation:
            raise UnsupportedOperationException("Called on interface.")

        def asyncronic(self) -> AsyncInvoker:
            raise UnsupportedOperationException("Called on interface.")

        @Overload
        def acceptLanguage(self, *locales: str) -> Invocation.Builder:
            raise UnsupportedOperationException("Called on interface.")

        @Overload
        def acceptLanguage(self, *locales: Locale) -> Invocation.Builder:
            raise UnsupportedOperationException("Called on interface.")

        def acceptEncoding(self, *encodings: str) -> Invocation.Builder:
            raise UnsupportedOperationException("Called on interface.")

        @Overload
        def cookie(self, cookie: Cookie) -> Invocation.Builder:
            raise UnsupportedOperationException("Called on interface.")

        @Overload
        def cookie(self, name: str, value: str) -> Invocation.Builder:
            raise UnsupportedOperationException("Called on interface.")

        def cacheControl(self, cacheControl: CacheControl) -> Invocation.Builder:
            raise UnsupportedOperationException("Called on interface.")

        def header(self, name: str, value: object) -> Invocation.Builder:
            raise UnsupportedOperationException("Called on interface.")

        def headers(self, headers: MultivaluedMap[str, object]) -> Invocation.Builder:
            raise UnsupportedOperationException("Called on interface.")

        @Overload
        def rx(self, _class: Type[T]) -> RxInvoker[T]:
            raise UnsupportedOperationException("Called on interface.")

        @Overload
        def rx(self) -> CompletionStageRxInvoker:
            raise UnsupportedOperationException("Called on interface.")

        # --------------------------------

    @Overload
    def invoke(self, responseType: Type[T]) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def invoke(self) -> Response:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def invoke(self, responseType: GenericType[T]) -> T:
        raise UnsupportedOperationException("Called on interface.")

    def property(self, name: str, value: object) -> Invocation:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def submit(self, callback: InvocationCallback[T]) -> Future[T]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def submit(self, responseType: GenericType[T]) -> Future[T]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def submit(self, responseType: Type[T]) -> Future[T]:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def submit(self) -> Future[Response]:
        raise UnsupportedOperationException("Called on interface.")
