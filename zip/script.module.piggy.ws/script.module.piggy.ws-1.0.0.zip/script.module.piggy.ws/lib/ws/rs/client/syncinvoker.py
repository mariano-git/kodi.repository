# interface
from typing import TypeVar, Type

from piggy.base import Overload, UnsupportedOperationException
from ws.rs.client.entity import Entity
from ws.rs.core.generictype import GenericType
from ws.rs.core.response import Response

T = TypeVar('T')
class SyncInvoker:

    # DELETE
    @Overload
    def delete(self, responseType: GenericType[T]) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def delete(self, responseType: Type[T]) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def delete(self) -> Response:
        raise UnsupportedOperationException("Called on interface.")

    # GET
    @Overload
    def get(self, responseType: GenericType[T]) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def get(self, responseType: Type[T]) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def get(self) -> Response:
        raise UnsupportedOperationException("Called on interface.")

    # head
    def head(self) -> Response:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def method(self, name: str, responseType: Type[T]) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def method(self, name: str) -> Response:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def method(self, name: str, entity: Entity, responseType: GenericType[T]) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def method(self, name: str, responseType: GenericType[T]) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def method(self, name: str, entity: Entity) -> Response:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def method(self, name: str, entity: Entity, responseType: Type[T]) -> T:
        raise UnsupportedOperationException("Called on interface.")

    # OPTIONS
    @Overload
    def options(self) -> Response:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def options(self, responseType: Type[T]) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def options(self, responseType: GenericType[T]) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def post(self, entity: Entity, responseType: Type[T]) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def post(self, entity: Entity) -> Response:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def post(self, entity: Entity, responseType: GenericType[T]) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def put(self, entity: Entity, responseType: GenericType[T]) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def put(self, entity: Entity, responseType: Type[T]) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def put(self, entity: Entity) -> Response:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def trace(self) -> Response:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def trace(self, responseType: Type[T]) -> T:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def trace(self, responseType: GenericType[T]) -> T:
        raise UnsupportedOperationException("Called on interface.")
