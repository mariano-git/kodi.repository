from typing import Generic, List, TypeVar, cast

from piggy.base import Overload
from piggy.base.notation import Annotation
from piggy.base.util import Objects
from piggy.base.util.locale import Locale
from ws.rs.core.form import Form
from ws.rs.core.mediatype import MediaType
from ws.rs.core.multivaluedmap import MultivaluedMap
from ws.rs.core.variant import Variant

T = TypeVar('T', bound=object)


class Entity(Generic[T]):
    __slots__ = '__entity__', '__variant__', '__notations__'

    def __init__(self, entity: T, variant: Variant, annotations: List[Annotation]):
        self.__entity__ = entity
        self.__variant__ = variant
        self.__notations__ = [] if annotations is None else annotations

    @Overload
    @staticmethod
    def entity(entity: T, mediaType: MediaType, annotations: List[Annotation]) -> 'Entity[T]':
        return Entity(entity, Variant(mediaType, None, None), annotations)

    @Overload
    @staticmethod
    def entity(entity: T, mediaType: str) -> 'Entity[T]':
        return Entity.entity(entity, MediaType.valueOf(mediaType))

    @Overload
    @staticmethod
    def entity(entity: T, mediaType: MediaType) -> 'Entity[T]':
        return Entity.entity(entity, mediaType, None)

    @Overload
    @staticmethod
    def entity(entity: T, variant: Variant) -> 'Entity[T]':
        return Entity(entity, variant, None)

    @Overload
    @staticmethod
    def entity(entity: T, variant: Variant, annotations: List[Annotation]) -> 'Entity[T]':
        return Entity(entity, variant, annotations)

    def equals(self, o: object) -> bool:

        if self == o:
            return True
        if not isinstance(o, Entity):
            return False

        other: Entity = cast(Entity, o)

        if not (Objects.equals(self.__notations__, other.__notations__)):
            return False
        if not (Objects.equals(self.__entity__, other.__entity__)):
            return False
        if not (Objects.equals(self.__variant__, other.__variant__)):
            return False

        return True

    @Overload
    @classmethod
    def form(cls, form: Form) -> 'Entity[Form]':
        return Entity(form, MediaType.APPLICATION_FORM_URLENCODED_TYPE)

    @Overload
    @classmethod
    def form(cls, formData: MultivaluedMap[str, str]) -> 'Entity[Form]':
        return Entity(Form(formData), MediaType.APPLICATION_FORM_URLENCODED_TYPE)

    def getAnnotations(self) -> List[Annotation]:
        return self.__notations__

    def getEncoding(self) -> str:
        return self.__variant__.getEncoding()

    def getEntity(self) -> object:
        return self.__entity__

    def getLanguage(self) -> Locale:
        return self.__variant__.getLanguage()

    def getMediaType(self) -> MediaType:
        return self.__variant__.getMediaType()

    def getVariant(self) -> Variant:
        return self.__variant__

    def hashCode(self) -> int:
        result = Objects.hashCodeOf(self.__entity__)
        result = 31 * result + Objects.hashCodeOf(self.__variant__)
        result = 31 * result + Objects.hashCodeOf(self.__notations__)
        return result

    @classmethod
    def html(cls, entity: T) -> 'Entity[T]':
        return Entity.entity(entity, MediaType.TEXT_HTML_TYPE)

    @classmethod
    def json(cls, entity: T) -> 'Entity[T]':
        return Entity.entity(entity, MediaType.APPLICATION_JSON_TYPE)

    @classmethod
    def text(cls, entity: T) -> 'Entity[T]':
        return Entity.entity(entity, MediaType.TEXT_PLAIN_TYPE)

    def toString(self) -> str:
        return f"Entity(entity={self.__entity__}, variant={self.__variant__}, annotations={self.__notations__})"

    @classmethod
    def xhtml(cls, entity: T) -> 'Entity[T]':
        return Entity.entity(entity, MediaType.APPLICATION_XHTML_XML_TYPE)

    @classmethod
    def xml(cls, entity: T) -> 'Entity[T]':
        return Entity.entity(entity, MediaType.APPLICATION_XML_TYPE)
