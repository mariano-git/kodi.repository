from __future__ import annotations

from piggy.base import Overload, UnsupportedOperationException
from piggy.base.net.uri import URI
from piggy.base.util.map import Map
from ws.rs.client.invocation import Invocation
from ws.rs.core.configurable import Configurable
from ws.rs.core.mediatype import MediaType
from ws.rs.core.uribuilder import UriBuilder


class WebTarget(Configurable['WebTarget']):

    def getUri(self) -> URI:
        raise UnsupportedOperationException("Called on interface.")

    def getUriBuilder(self) -> UriBuilder:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def resolveTemplate(self, name: str, value: object) -> WebTarget:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def resolveTemplate(self, name: str, value: object, encodeSlashInPath: bool) -> WebTarget:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def resolveTemplateFromEncoded(self, name: str, value: object) -> WebTarget:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def resolveTemplatesFromEncoded(self, templateValues: Map[str, object]) -> WebTarget:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def resolveTemplates(self, templateValues: Map[str, object], encodeSlashInPath: bool) -> WebTarget:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def resolveTemplates(self, templateValues: Map[str, object]) -> WebTarget:
        raise UnsupportedOperationException("Called on interface.")

    def matrixParam(self, name: str, *values: object) -> WebTarget:
        raise UnsupportedOperationException("Called on interface.")

    def queryParam(self, name: str, *values: object) -> WebTarget:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def request(self) -> Invocation.Builder:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def request(self, *acceptedResponseTypes: MediaType) -> Invocation.Builder:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def request(self, *acceptedResponseTypes: str) -> Invocation.Builder:
        raise UnsupportedOperationException("Called on interface.")

    def path(self, path: str) -> WebTarget:
        raise UnsupportedOperationException("Called on interface.")
