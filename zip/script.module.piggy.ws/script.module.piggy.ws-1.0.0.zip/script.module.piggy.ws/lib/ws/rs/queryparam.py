from piggy.base import UnsupportedOperationException
from piggy.base.notation import Target, ElementType, AnnotationType

# FIXME TODO: QueryParam as any other Param needs to hold the type(class) too
@Target({ElementType.PARAMETER, ElementType.METHOD, ElementType.FIELD})
class QueryParam(AnnotationType):
    def value(self) -> str:
        pass
