from piggy.base import Overload, Raisable
from ws.rs.clienterrorexception import ClientErrorException
from ws.rs.core.response import Response


class BadRequestException(ClientErrorException):
    @Overload
    def __init__(self):
        super().__init__(Response.Status.BAD_REQUEST)

    @Overload
    def __init__(self, message: str):
        super().__init__(message, Response.Status.BAD_REQUEST)

    @Overload
    def __init__(self, response: Response):
        super().__init__(self._validate(response, Response.Status.BAD_REQUEST))

    @Overload
    def __init__(self, message: str, response: Response):
        super().__init__(message, self._validate(response, Response.Status.BAD_REQUEST))

    @Overload
    def __init__(self, cause: Raisable):
        super().__init__(Response.Status.BAD_REQUEST, cause)

    @Overload
    def __init__(self, message: str, cause: Raisable):
        super().__init__(message, Response.Status.BAD_REQUEST, cause)

    @Overload
    def __init__(self, response: Response, cause: Raisable):
        super().__init__(self._validate(response, Response.Status.BAD_REQUEST), cause)

    @Overload
    def __init__(self, message: str, response: Response, cause: Raisable):
        super().__init__(message, self._validate(response, Response.Status.BAD_REQUEST), cause)
