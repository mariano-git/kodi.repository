from typing import cast

from piggy.base import Overload, Raisable
from piggy.base.util.date import Date
from ws.rs.core.httpheaders import HttpHeaders
from ws.rs.core.response import Response
from ws.rs.ext.runtimedelegate import RuntimeDelegate
from ws.rs.servererrorexception import ServerErrorException


class ServiceUnavailableException(ServerErrorException):
    @Overload
    def __init__(self):
        super().__init__(Response.status(Response.Status.SERVICE_UNAVAILABLE).build())

    @Overload
    def __init__(self, message: str):
        super().__init__(message, Response.status(Response.Status.SERVICE_UNAVAILABLE).build())

    @Overload
    def __init__(self, retryAfter: int):
        super().__init__(
            Response.status(Response.Status.SERVICE_UNAVAILABLE).header(HttpHeaders.RETRY_AFTER, retryAfter).build())

    @Overload
    def __init__(self, message: str, retryAfter: int):
        super().__init__(message, Response.status(
            Response.Status.SERVICE_UNAVAILABLE).header(
            HttpHeaders.RETRY_AFTER, retryAfter
        ).build())

    @Overload
    def __init__(self, retryAfter: Date):
        super().__init__(
            Response.status(Response.Status.SERVICE_UNAVAILABLE).header(HttpHeaders.RETRY_AFTER, retryAfter).build())

    @Overload
    def __init__(self, message: str, retryAfter: Date):
        super().__init__(
            message,
            Response.status(
                Response.Status.SERVICE_UNAVAILABLE).header(
                HttpHeaders.RETRY_AFTER, retryAfter).build()
        )

    @Overload
    def __init__(self, response: Response):
        super().__init__(self._validate(response, Response.Status.SERVICE_UNAVAILABLE))

    @Overload
    def __init__(self, message: str, response: Response):
        super().__init__(message, self._validate(response, Response.Status.SERVICE_UNAVAILABLE))

    @Overload
    def __init__(self, retryAfter: Date, cause: Raisable):
        super().__init__(
            Response.status(
                Response.Status.SERVICE_UNAVAILABLE).header(
                HttpHeaders.RETRY_AFTER, retryAfter
            ).build(), cause)

    @Overload
    def __init__(self, message: str, retryAfter: Date, cause: Raisable):
        super().__init__(message,
                         Response.status(
                             Response.Status.SERVICE_UNAVAILABLE).header(
                             HttpHeaders.RETRY_AFTER, retryAfter).build(),
                         cause)

    @Overload
    def __init__(self, retryAfter: int, cause: Raisable):
        super().__init__(
            Response.status(
                Response.Status.SERVICE_UNAVAILABLE).header(
                HttpHeaders.RETRY_AFTER, retryAfter).build(),
            cause)

    @Overload
    def __init__(self, message: str, retryAfter: int, cause: Raisable):
        super().__init__(message,
                         Response.status(
                             Response.Status.SERVICE_UNAVAILABLE).header(
                             HttpHeaders.RETRY_AFTER, retryAfter
                         ).build(), cause)

    @Overload
    def __init__(self, response: Response, cause: Raisable):
        super().__init__(self._validate(response, Response.Status.SERVICE_UNAVAILABLE), cause)

    @Overload
    def __init__(self, message: str, response: Response, cause: Raisable):
        super().__init__(message, self._validate(response, Response.Status.SERVICE_UNAVAILABLE), cause)

    def hasRetryAfter(self) -> bool:
        return self.getResponse().getHeaders().containsKey(HttpHeaders.RETRY_AFTER)

    def getRetryTime(self, requestTime: Date) -> Date:
        value = self.getResponse().getHeaderString(HttpHeaders.RETRY_AFTER)
        if value is None:
            return cast(Date, None)
        try:
            interval = int(value)
            return Date(requestTime.getTime() + interval * 1000)
        except Exception:
            # not an decimal value ignoring exception and parsing as date
            pass

        dateDelegate = RuntimeDelegate.getInstance().createHeaderDelegate(Date)
        return dateDelegate.fromString(value)
