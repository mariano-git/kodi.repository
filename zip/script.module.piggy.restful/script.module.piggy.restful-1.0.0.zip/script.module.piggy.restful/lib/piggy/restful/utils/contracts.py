from piggy.base.util.logging import Logger
from typing import Set, Type, Tuple, Dict, Union, Optional, List

from piggy.base.util import Objects
from piggy.base.util.map import Map
from piggy.base.util.simplemap import SimpleMap
from ws.rs.client.clientrequestfilter import ClientRequestFilter
from ws.rs.client.clientresponsefilter import ClientResponseFilter
from ws.rs.client.rxinvokerprovider import RxInvokerProvider
from ws.rs.constrainedto import ConstrainedTo
from ws.rs.container.containerrequestfilter import ContainerRequestFilter
from ws.rs.container.containerresponsefilter import ContainerResponseFilter
from ws.rs.container.dynamicfeature import DynamicFeature
from ws.rs.core.feature import Feature
from ws.rs.ext.contextresolver import ContextResolver
from ws.rs.ext.exceptionmapper import ExceptionMapper
from ws.rs.ext.messagebodyreader import MessageBodyReader
from ws.rs.ext.messagebodywriter import MessageBodyWriter
from ws.rs.ext.paramconverterprovider import ParamConverterProvider
from ws.rs.ext.readerinterceptor import ReaderInterceptor
from ws.rs.ext.writerinterceptor import WriterInterceptor
from ws.rs.runtimetype import RuntimeType

from piggy.restful.utils.annotationutils import AnnotationUtils


class Contracts:
    __lg__ = Logger.getLogger(f'{__name__}.{__qualname__}')

    CONSTRAINED_CONTRACTS: Dict[RuntimeType, Tuple[Type]] = {
        RuntimeType.CLIENT: (ContainerRequestFilter, ClientRequestFilter, RxInvokerProvider),
        RuntimeType.SERVER: (ContainerResponseFilter, ClientResponseFilter, DynamicFeature)
    }

    CONTRACTS: Tuple[Type] = (
        ContextResolver,
        ExceptionMapper,
        MessageBodyReader,
        MessageBodyWriter,
        ReaderInterceptor,
        WriterInterceptor,
        ParamConverterProvider,
        Feature
    )

    @classmethod
    def getOppositeContracts(cls, runtimeType: RuntimeType) -> Tuple[Type]:
        return cls.CONSTRAINED_CONTRACTS[
            RuntimeType.SERVER if runtimeType == RuntimeType.CLIENT else RuntimeType.CLIENT]

    @classmethod
    def isValidConstraint(cls, provider: Union[object, Type], runtimeType: RuntimeType) -> bool:
        providerCls: Type = Objects.asType(provider)
        constrained: Optional[ConstrainedTo] = AnnotationUtils.getAnnotationValue(providerCls, ConstrainedTo, None)
        if constrained:
            if constrained != runtimeType:
                cls.__lg__.warning(
                    'Provider: "%s" cannot be registered in this %s runtime because it is constrained to "%s" runtime.',
                    provider, runtimeType, constrained
                )
                return False
            opposite: Tuple[Type] = cls.getOppositeContracts(runtimeType)
            for contract in opposite:
                if issubclass(providerCls, contract):
                    cls.__lg__.warning(
                        'Provider "%s" is invalid. It is constrained to "%s" runtimes but implements "%s" contract',
                        providerCls, runtimeType, contract
                    )
                    return False
        return True

    @classmethod
    def isValidForContracts(cls, provider: Union[object, Type], contracts: Set[Type]) -> bool:
        if Objects.isEmpty(contracts):
            cls.__lg__.warning('Null, empty or invalid contracts specified for "%s"... ignoring.', provider)
            return False
        providerCls = Objects.asType(provider)
        for contract in contracts:
            if not issubclass(providerCls, contract):
                cls.__lg__.warning(
                    'Provider: "%s" cannot be registered for contract: "%s" because not implements it...',
                    provider, contract
                    )
                return False
        return True

    @classmethod
    def createContractsMap(cls, priority: int, *contracts: Type) -> Map[Type, int]:
        metadata: Map[Type, int] = SimpleMap()
        for contract in contracts:
            metadata.put(contract, priority)
        return metadata

    @classmethod
    def isWhiteListed(cls, contract: Type, runtimeType: RuntimeType) -> bool:
        return contract in cls.CONSTRAINED_CONTRACTS[runtimeType] or contract in cls.CONTRACTS

    @classmethod
    def getProviderContracts(cls, provider: object, runtimeType: RuntimeType) -> List[Type]:
        providerCls: Type = Objects.asType(provider)
        interfaces: Set[Type] = cls.collectAllInterfaces(providerCls)
        contracts = list(filter(lambda contract: cls.isWhiteListed(contract, runtimeType), interfaces))
        return contracts

    @classmethod
    def collectAllInterfaces(cls, classType: Type) -> Set[Type]:
        interfaces: Set[Type] = set()
        for base in classType.__bases__:
            cls.collectInterfaces(interfaces, base)
        return interfaces

    @classmethod
    def collectInterfaces(cls, interfaces: Set[Type], classType: Type):
        if classType is not object:
            interfaces.add(classType)
            for base in classType.__bases__:
                cls.collectInterfaces(interfaces, base)

    @classmethod
    def message(cls, message, *args):
        cls.__lg__.log(Logger.WARNING, message, *args)
