from typing import List, Set, Collection

from piggy.base import Overload, UnsupportedOperationException, NullPointerException, IllegalArgumentException
from piggy.base.util.map import Map
from piggy.base.util.simplemap import SimpleMap
from ws.rs.core.abstractmultivaluedmap import AbstractMultivaluedMap

from ws.rs.core.multivaluedmap import V


class KeyIgnoreCaseMultivaluedMap(AbstractMultivaluedMap[str, V]):
    class Entry(Map.Entry[str, V]):
        def __init__(self, key: str, value: V, parent: SimpleMap[str, V]):
            self.__parent__ = parent
            self.key = key
            self.value = value

        def getKey(self) -> str:
            return self.key

        def getValue(self) -> V:
            return self.value

        def setValue(self, value: V) -> V:
            return self.__parent__.put(self.key, value)

        def equals(self, o: object):
            raise UnsupportedOperationException("Not supported yet.")

        def hashCode(self) -> int:
            raise UnsupportedOperationException("Not supported yet.")

    def __init__(self):
        self.__store__: Map[str, KeyIgnoreCaseMultivaluedMap.Entry[str, V]] = SimpleMap()

    def putSingle(self, key: str, value: V):
        values: List[V] = self.getValues(key)
        values.clear()
        if value:
            values.append(value)
        else:
            self.addNull(values)

    def addNull(self, values: List[V]):
        # do nothing in the default implementation ignore the null value
        pass

    def addFirstNull(self, values: List[V]):
        # do nothing in the default implementation ignore the null value
        pass

    def add(self, key: str, value: V):
        values: List[V] = self.getValues(key)
        if values is not None and value is not None:
            values.append(value)
        elif values is not None:
            self.addNull(values)

    @Overload
    def addAll(self, key: str, *newValues: V):
        if newValues is None:
            raise NullPointerException("Supplied array of values must not be null.")
        if len(newValues) == 0:
            return
        values: List[V] = self.getValues(key)
        for value in newValues:
            if value:
                values.append(value)
            else:
                self.addNull(values)

    @Overload
    def addAll(self, key: str, valueList: List[V]):
        if valueList is None:
            raise NullPointerException("Supplied list of values must not be null.")

        if len(valueList) == 0:
            return
        values: List[V] = self.getValues(key)

        for value in valueList:
            if value:
                values.append(value)
            else:
                self.addNull(values)

    def getFirst(self, key: str) -> V:
        values = self.__store__.get(key.lower())
        if values:
            if values.getValue() > 0:
                return values.getValue()[0]

        return None

    def addFirst(self, key: str, value: V):
        values: List[V] = self.getValues(key)
        if value:
            values.insert(0, value)
        else:
            self.addFirstNull(values)

    def getValues(self, key: str) -> List[V]:
        entry = self.__store__.get(key.lower())
        if entry is None:
            l = list()
            self.__store__.put(key.lower(), KeyIgnoreCaseMultivaluedMap.Entry(key, l, self))
        else:
            l = entry.getValue()
        return l

    def toString(self) -> str:
        return str(self.__store__)

    def hashCode(self) -> int:
        return self.__store__.hashCode()

    def equals(self, o: object) -> bool:
        return self.__store__.equals(o)

    def values(self) -> Collection[List[V]]:
        generator = (entry.getValue() for entry in self.__store__.values())
        return generator

    def size(self) -> int:
        return self.__store__.size()

    def remove(self, key: str) -> List[V]:
        ret = self.__store__.get(key.lower())
        if ret:
            self.__store__.remove(key.lower())
            return ret.getValue()
        return None

    def putAll(self, m: Map[str, List[V]]):
        for e in m.entrySet():
            value = e.getValue()
            if isinstance(value, KeyIgnoreCaseMultivaluedMap.Entry):
                self.put(e.getKey(), value.value)
            else:
                self.put(e.getKey(), value)

    def put(self, key: str, value: List[V]) -> List[V]:
        if not isinstance(value, list):
            raise IllegalArgumentException('only lists values are allowed')
        self.__store__.put(key.lower(), KeyIgnoreCaseMultivaluedMap.Entry(key, value, self))
        return value

    def keySet(self) -> Set[str]:
        return self.__store__.keySet()

    def isEmpty(self) -> bool:
        return self.__store__.isEmpty()

    def get(self, key: str) -> List[V]:
        value:KeyIgnoreCaseMultivaluedMap.Entry = self.__store__.get(key.lower())
        if value:
            return value.getValue()
        return None

    def entrySet(self) -> Set[Map.Entry[str, List[V]]]:
        entrySet = set()
        for entry in self.__store__.entrySet():
            entrySet.add(entry.getValue())
        return entrySet

    def containsValue(self, value: object) -> bool:
        return self.__store__.containsValue(value)

    def containsKey(self, key: str) -> bool:
        return self.__store__.containsKey(key.lower())

    def clear(self):
        self.__store__.clear()
