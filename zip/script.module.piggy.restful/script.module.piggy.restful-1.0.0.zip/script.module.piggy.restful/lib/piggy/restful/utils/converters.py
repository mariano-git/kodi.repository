class Converters:
    @staticmethod
    def toBool(value) -> bool:
        if value is None:
            return False
        if isinstance(value, str):
            value = value.lower()
            return value == 'yes' or value == 'true' or value == '1'
        if isinstance(value, bool):
            return value
        if isinstance(value, int):
            return True if value > 0 else False
        return value
