from typing import Union, Type, TypeVar

T = TypeVar('T')


class AnnotationUtils:
    @staticmethod
    def getAnnotationValue(subject: Union[Type, object], annotationType: Type, defaultValue: T) -> T:
        value = None
        if isinstance(subject, annotationType):
            try:
                value = subject.value()
            except Exception as e:
                value = defaultValue
        else:
            try:
                annot = subject.getAnnotation(annotationType)
                value = annot.value()
            except Exception as e:
                value = defaultValue
        return value if value is not None else defaultValue

    @classmethod
    def getAnnotation(cls, subject: Union[Type, object], annotationType: Type):
        try:
            return subject.getAnnotation(annotationType)
        except Exception as e:
            return None
