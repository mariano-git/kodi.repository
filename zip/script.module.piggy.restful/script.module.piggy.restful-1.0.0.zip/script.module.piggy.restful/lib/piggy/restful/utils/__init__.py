from piggy.base.util.logging import Logger


class SafeObject:
    __logger__ = Logger.getLogger(f'{__name__}.{__qualname__}')

    def __getitem__(self, item):
        self.__logger__.warning('Object: "%s" doesn\'t contain item: "%s"', self, item)
        return None

    '''
    def __getattribute__(self, item):
        self.__logger__.debug('__getattribute__(%s, %s)', self, item)
    '''
    def __getattr__(self, item):
        if item == '__bases__': # FIXME breaks inspect
            raise AttributeError(f'Object: "{self}" doesn\'t contain attribute: "{item}"')
        #self.__logger__.warning('Object: "%s" doesn\'t contain attribute: "%s"', self, item)

        return None

