from piggy.restful.ext.spi.json.provider.defaultjsonprovider import DefaultJsonProvider
from piggy.restful.ext.spi.json.provider.jsonmappingexceptionmapper import JsonMappingExceptionMapper
from piggy.restful.ext.spi.json.provider.jsonparseexceptionmapper import JsonParseExceptionMapper
from piggy.restful.ext.spi.json.provider.jsonprovider import JsonProvider
from ws.rs.core.configuration import Configuration
from ws.rs.core.feature import Feature
from ws.rs.core.featurecontext import FeatureContext
from ws.rs.ext.messagebodyreader import MessageBodyReader
from ws.rs.ext.messagebodywriter import MessageBodyWriter


class JsonFeature(Feature):
    def __init__(self, registerExceptionMappers: bool = True):
        self.registerExceptionMappers = registerExceptionMappers

    def configure(self, context: FeatureContext) -> bool:

        config: Configuration = context.getConfiguration()

        if not config.isRegistered(JsonProvider):
            if self.registerExceptionMappers:
                context.register(JsonParseExceptionMapper)
                context.register(JsonMappingExceptionMapper)

            context.register(DefaultJsonProvider, MessageBodyReader, MessageBodyWriter)
        return True
