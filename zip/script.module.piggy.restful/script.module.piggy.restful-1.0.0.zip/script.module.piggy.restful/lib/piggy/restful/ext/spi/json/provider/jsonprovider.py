class JsonProvider:
    pass
