from __future__ import annotations

from piggy.restful.ext.binder import Binder
from ws.rs.core.configuration import Configuration


class Runtime:
    def __init__(self, configuration: Configuration):
        self.configuration: Configuration = None
        self.update(configuration)
        self.binder = Binder()

    def getConfiguration(self) -> Configuration:
        return self.configuration

    def getBinder(self) -> Binder:
        return self.binder

    def update(self, configuration: Configuration):
        self.configuration = configuration

    def isOpen(self) -> bool:
        pass

    def close(self):
        pass
