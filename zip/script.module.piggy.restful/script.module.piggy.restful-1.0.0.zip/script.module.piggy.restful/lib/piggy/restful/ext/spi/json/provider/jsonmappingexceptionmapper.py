from ws.rs.ext.exceptionmapper import ExceptionMapper


class JsonMappingExceptionMapper(ExceptionMapper):
    pass