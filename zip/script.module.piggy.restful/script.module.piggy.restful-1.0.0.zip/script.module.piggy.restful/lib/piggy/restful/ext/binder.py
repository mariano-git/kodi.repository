from typing import Dict, Type, Set, Tuple, TypeVar

from piggy.base.util.logging import Logger
from piggy.restful.utils.annotationutils import AnnotationUtils
from ws.rs.client.clientrequestfilter import ClientRequestFilter
from ws.rs.client.clientresponsefilter import ClientResponseFilter
from ws.rs.client.rxinvokerprovider import RxInvokerProvider
from ws.rs.container.containerrequestfilter import ContainerRequestFilter
from ws.rs.container.containerresponsefilter import ContainerResponseFilter
from ws.rs.container.dynamicfeature import DynamicFeature
from ws.rs.core.feature import Feature
from ws.rs.ext.contextresolver import ContextResolver
from ws.rs.ext.exceptionmapper import ExceptionMapper
from ws.rs.ext.messagebodyreader import MessageBodyReader
from ws.rs.ext.messagebodywriter import MessageBodyWriter
from ws.rs.ext.paramconverterprovider import ParamConverterProvider
from ws.rs.ext.readerinterceptor import ReaderInterceptor
from ws.rs.ext.writerinterceptor import WriterInterceptor
from ws.rs.namebinding import NameBinding

T = TypeVar('T')


class Binder:
    __lg__ = Logger.getLogger(f'{__name__}.{__qualname__}')
    CONTRACTS: Dict[Type, Dict[Type, Tuple[object, int]]] = {
        ContextResolver: dict(),
        ExceptionMapper: dict(),
        MessageBodyReader: dict(),
        MessageBodyWriter: dict(),
        ReaderInterceptor: dict(),
        WriterInterceptor: dict(),
        ParamConverterProvider: dict(),
        ContainerRequestFilter: dict(),
        ContainerResponseFilter: dict(),
        DynamicFeature: dict(),
        ClientResponseFilter: dict(),
        ClientRequestFilter: dict(),
        RxInvokerProvider: dict(),
        Feature: dict()
    }

    def __init__(self):
        self.contracts = dict()
        self.providers = dict()
        self.contracts.update(Binder.CONTRACTS)

    def addProvider(self, provider: object, contract: Type, priority: int):
        self.__lg__.debug("Adding provider: %s, contract: %s, priority: %s", provider, contract, priority)
        pproviders: Dict[Type, Tuple[object, int]] = self.contracts.get(contract)
        if pproviders is not None:
            cls = provider.__class__
            entry = pproviders.get(cls)
            if entry is None:
                pproviders[cls] = (provider, priority)
                # FIXME
                # self.providers[contract] = frozenset(map(lambda p: p[0], set(sorted(pproviders, key=lambda t: t[2]))))
            else:
                self.__lg__.debug("Rejecting already registered provider: %s with priority: %s", cls, priority)

        else:
            self.__lg__.debug("Rejecting contract: %s with priority: %s", contract, priority)

    def getByContract(self, contract: Type[T], predicate=None) -> Set[T]:
        providers: Dict[Type, Tuple[object, int]] = self.contracts.get(contract)
        results = set()
        if not providers:
            return frozenset(results)

        def noBindingFilter(provider):
            nameBinding = AnnotationUtils.getAnnotation(provider, NameBinding)
            if predicate is not None:
                return predicate(provider, nameBinding)
            else:
                return nameBinding is None

        return frozenset(filter(lambda p: noBindingFilter(p), map(lambda p: p[0], providers.values())))
