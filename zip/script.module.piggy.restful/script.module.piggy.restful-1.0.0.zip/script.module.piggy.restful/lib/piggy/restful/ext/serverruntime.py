from typing import Union, Type

from piggy.base import Raisable
from piggy.base.util.logging import Logger
from piggy.restful.ext.runtime import Runtime
from piggy.restful.internal.phase.server import ServerPhaseContext
from piggy.restful.internal.phase.server.messagebodyreading import MessageBodyReading
from piggy.restful.internal.phase.server.messagebodywriting import MessageBodyWriting
from piggy.restful.internal.phase.server.methodprocessing import MethodProcessing
from piggy.restful.internal.phase.server.postmatchingrequestfiltering import PostMatchingRequestFiltering
from piggy.restful.internal.phase.server.prematchingrequestfiltering import PreMatchingRequestFiltering
from piggy.restful.internal.phase.server.readinginterception import ReadingInterception
from piggy.restful.internal.phase.server.resourcematching import ResourceMatching
from piggy.restful.internal.phase.server.responsefiltering import ResponseFiltering
from piggy.restful.internal.phase.server.writinginterception import WritingInteception
from piggy.restful.internal.server.containerrequest import ContainerRequest
from piggy.restful.internal.server.routing import Router
from ws.rs.core.application import Application
from ws.rs.core.configuration import Configuration


class ServerRuntime(Runtime):
    __lg__ = Logger.getLogger(f'{__name__}.{__qualname__}')
    PHASES = (
        PreMatchingRequestFiltering(),
        ResourceMatching(),
        PostMatchingRequestFiltering(),
        ReadingInterception(),
        MessageBodyReading(),
        MethodProcessing(),
        ResponseFiltering(),
        WritingInteception(),
        MessageBodyWriting()
    )

    def __init__(self, configuration: Configuration):
        super().__init__(configuration)
        self.router = Router()

    def createEndpoint(self, application: Application, endpoint: Union[Type, object]):
        self.router.add(application, endpoint)

    '''
    Processing order
        Server Pre-Matching Request Filter
        Server Post-Matching Request Filter
        Server Reader Interceptor
        Server Message Body Reader
        Server Resource Method Processing
        Server Response Filter
        Server Writer Interceptor
        Server Message Body Writer
    '''

    def process(self, request: ContainerRequest):

        context: ServerPhaseContext = ServerPhaseContext(request, self.getBinder(), self.router)
        try:
            for phase in self.PHASES:
                self.__lg__.debug('Appliying phase: %s', phase)
                phase.apply(context)
        except Raisable as raisable:
            # FIXME
            responder.process(raisable)
