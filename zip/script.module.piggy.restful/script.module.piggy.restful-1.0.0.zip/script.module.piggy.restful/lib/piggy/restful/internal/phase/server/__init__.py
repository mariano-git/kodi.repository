from piggy.restful.ext.binder import Binder
from piggy.restful.internal.phase import PhaseContext
from piggy.restful.internal.server.containerrequest import ContainerRequest


class ServerPhaseContext(PhaseContext):
    def __init__(self, request: ContainerRequest, binder: Binder, router: 'Router'):
        self.request = request
        self.binder = binder
        self.router = router
        self.abortResponse = None

    def getRequestContext(self):
        return self.request

    def getBinder(self):
        return self.binder

    def getRouter(self):
        return self.router

    def setAbortResponse(self, abortResponse):
        self.abortResponse = abortResponse
