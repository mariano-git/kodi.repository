from __future__ import annotations

from typing import Type, List, Callable, Optional, TypeVar, Iterable

from piggy.base import Overload, IllegalArgumentException, Raisable, UnsupportedOperationException
from piggy.base.io import Closeable, IOException
from piggy.base.io.bytearrayinputstream import ByteArrayInputStream
from piggy.base.io.bytearrayoutputstream import ByteArrayOutputStream
from piggy.base.io.inputstream import InputStream
from piggy.base.notation import Annotation
from piggy.base.util import Objects
from piggy.restful.internal.message.entityinputstream import EntityInputStream
from piggy.restful.internal.message.headervalueexception import HeaderValueException
from piggy.restful.internal.message.messagebodyworkers import MessageBodyWorkers
from piggy.restful.internal.propertiesdelegate import PropertiesDelegate
from piggy.restful.utils.headerutils import HeaderUtils
from ws.rs.core.configuration import Configuration
from ws.rs.core.httpheaders import HttpHeaders
from ws.rs.core.mediatype import MediaType
from ws.rs.core.multivaluedmap import MultivaluedMap
from ws.rs.ext.readerinterceptor import ReaderInterceptor
from ws.rs.ext.runtimedelegate import RuntimeDelegate
from ws.rs.processingexception import ProcessingException

T = TypeVar('T')


class EntityContent(EntityInputStream):

    def __init__(self):
        super().__init__(None)
        self.buffered = False

    def setContent(self, inputStream, param):
        self.buffered = isinstance(inputStream, ByteArrayInputStream)
        super().setWrappedStream(inputStream)

    def isBuffered(self):
        return self.buffered

    def hasContent(self):
        return self.getWrappedStream() is not None


class InboundMessageContext:
    EMPTY_ANNOTATIONS: List[Annotation] = list()

    def __init__(self, configuration: Configuration, translateNce: bool = False):
        self.headers_: MultivaluedMap[str, str] = HeaderUtils.createInbound()
        self.entityContent = EntityContent()
        self.translateNce = translateNce
        self.configuration = configuration
        self.workers: MessageBodyWorkers = None

    def getReaderInterceptors(self) -> Iterable[ReaderInterceptor]:
        raise UnsupportedOperationException("This method is abstract and must be implemented.")

    def setWorkers(self, workers: MessageBodyWorkers):
        self.workers = workers

    def getHeaders(self) -> MultivaluedMap[str, str]:
        return self.headers_

    def header(self, name: str, value: object) -> InboundMessageContext:
        self.getHeaders().add(name, HeaderUtils.asString(value, RuntimeDelegate.getInstance()))
        return self

    @Overload
    def headers(self, name: str, *values: object) -> InboundMessageContext:
        self.getHeaders().addAll(name, HeaderUtils.asStringList(*values), RuntimeDelegate.getInstance())
        return self

    @Overload
    def headers(self, headerValues: MultivaluedMap[str, str]) -> InboundMessageContext:
        for header in headerValues.entrySet():
            self.headers_.addAll(header.getKey(), header.getValue())
        return self

    def remove(self, name: str) -> InboundMessageContext:
        self.getHeaders().remove(name)
        return self

    def getMediaType(self) -> MediaType:
        def convert(headerStr: str) -> MediaType:
            try:
                return RuntimeDelegate.getInstance().createHeaderDelegate(
                    MediaType
                ).fromString(headerStr)
            except IllegalArgumentException as e:
                raise ProcessingException(e)

        return self.singleHeader(HttpHeaders.CONTENT_TYPE, MediaType, convert, False)

    def setEntityStream(self, input: InputStream):
        self.entityContent.setContent(input, False)

    def bufferEntity(self) -> bool:
        self.entityContent.ensureNotClosed()

        try:
            if self.entityContent.isBuffered() or not self.entityContent.hasContent():
                return True
            entityStream: InputStream = self.entityContent.getWrappedStream()
            if isinstance(entityStream, ByteArrayInputStream):
                return True
            baos: ByteArrayOutputStream = ByteArrayOutputStream()
            try:
                entityStream.transferTo(baos)  # ReaderWriter.writeTo(entityStream, baos);
            finally:
                entityStream.close()
            self.entityContent.setContent(ByteArrayInputStream(baos.toBytes()), True)
            return True
        except IOException as ex:
            raise ProcessingException('Failed to buffer the message content input stream.', ex)

    def readEntity(self, rawType: Type[T], cls: Type, annotations: List[Annotation],
                   propertiesDelegate: PropertiesDelegate) -> T:
        buffered = self.entityContent.isBuffered()
        if buffered:
            self.entityContent.reset()
        self.entityContent.ensureNotClosed()

        if self.workers is None:
            return None
        mediaType: MediaType = self.getMediaType()
        mediaType = MediaType.APPLICATION_OCTET_STREAM_TYPE if mediaType is None else mediaType
        shouldClose = not buffered
        try:
            t: T = self.workers.readFrom(
                rawType,
                cls,
                annotations,
                mediaType,
                self.headers_,
                propertiesDelegate,
                self.entityContent.getWrappedStream(),
                self.getReaderInterceptors() if self.entityContent.hasContent() else list(),
                self.translateNce
            )
            shouldClose = shouldClose and not isinstance(t, Closeable)  # and not isinstance(t, Source)
            return t
        except IOException as ex:
            raise ProcessingException('Error reading entity from input stream.', ex)
        finally:
            if shouldClose:
                self.entityContent.close()

    def singleHeader(self,
                     name: str,
                     valueType: Type,
                     converter: Callable[[Optional[str]], Optional[T]],
                     convertNull: bool) -> Optional[T]:

        values: List[object] = self.headers_.get(name)

        if Objects.isEmpty(values):
            return converter(None) if convertNull else None

        if len(values) > 1:
            raise HeaderValueException(
                f'Too many "{name}" header values: "{values}"',
                HeaderValueException.Context.INBOUND
            )

        value = values[0]
        if value is None:
            return converter(None) if convertNull else None

        if isinstance(value, valueType):
            return value
        else:
            try:
                return converter(HeaderUtils.asString(value, None))
            except ProcessingException as ex:
                raise self.exception(name, value, ex)

    def exception(self, headerName: str, headerValue: object, e: Raisable) -> HeaderValueException:
        return HeaderValueException(
            f'Unable to parse "{headerName}" header value: "{headerValue}"', e,
            HeaderValueException.Context.INBOUND)
