from typing import List, Type, Collection

from piggy.base.notation import Annotation
from piggy.restful.internal.propertiesdelegate import PropertiesDelegate
from ws.rs.core.mediatype import MediaType
from ws.rs.ext.interceptorcontext import InterceptorContext


class BaseInterceptorContext(InterceptorContext):

    def __init__(self, rawType: Type, genericType: Type, annotations: List[Annotation], mediaType: MediaType,
                 propertiesDelegate: PropertiesDelegate):
        self.rawType = rawType
        self.genericType = genericType
        self._annotations_ = annotations
        self.mediaType = mediaType
        self.propertiesDelegate = propertiesDelegate

    def getAnnotations(self) -> List[Annotation]:
        return self._annotations_

    def getGenericType(self) -> Type:
        return self.genericType

    def getMediaType(self) -> MediaType:
        return self.mediaType

    def getProperty(self, name: str) -> object:
        return self.propertiesDelegate.getProperty(name)

    def getPropertyNames(self) -> Collection[str]:
        return self.propertiesDelegate.getPropertyNames()

    def getType(self) -> Type:
        return self.rawType

    def removeProperty(self, name: str):
        return self.propertiesDelegate.removeProperty(name)

    def setAnnotations(self, annotations: List[Annotation]):
        self._annotations_ = annotations

    def setGenericType(self, genericType: Type):
        self.genericType = genericType

    def setMediaType(self, mediaType: MediaType):
        self.mediaType = mediaType

    def setProperty(self, name: str, value: object):
        self.propertiesDelegate.setProperty(name, value)

    def setType(self, typ: Type):
        self.rawType = typ
