class TokenEventHander:
    def onToken(self, token: str, headerValue: str, start: int, end: int):
        pass


class HeaderTokenizer:
    def __init__(self, tokens: str, handler:TokenEventHander):
        self.handler = handler
        self.index = 0
        self.offset = 0
        self.tokens = bytes(tokens, 'utf-8')

    def process(self, value: str):
        for s in value:
            if ord(s) in self.tokens:
                self.handler.onToken(s, value, self.offset, self.index)
                self.offset = self.index + 1
            self.index += 1
        self.handler.onToken('EOL', value, self.offset, self.index)