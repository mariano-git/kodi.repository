from urllib.parse import unquote

from piggy.base.net.uri import URI
from piggy.restful.internal.server.routing.uriroutingcontext import UriRoutingContext
from ws.rs.container.containerrequestcontext import ContainerRequestContext
from ws.rs.core.configuration import Configuration
from ws.rs.core.httpheaders import HttpHeaders
from ws.rs.core.request import Request
from ws.rs.core.securitycontext import SecurityContext

from piggy.restful.internal.message.inboundmessagecontext import InboundMessageContext
from piggy.restful.internal.propertiesdelegate import PropertiesDelegate


class ContainerRequest(InboundMessageContext, ContainerRequestContext, Request, HttpHeaders):
    DEFAULT_BASE_URI: URI = URI.create("/")

    def __init__(self, baseUri: URI,
                 requestUri: URI,
                 httpMethod: str,
                 securityContext: SecurityContext,
                 propertiesDelegate: PropertiesDelegate,
                 configuration: Configuration):
        super().__init__(configuration, True)
        self.baseUri = baseUri.normalize() if baseUri is not None else self.DEFAULT_BASE_URI
        self.requestUri = requestUri.normalize()
        self.httpMethod = httpMethod
        self.securityContext = securityContext
        self.propertiesDelegate = propertiesDelegate
        self.uriRoutingContext = UriRoutingContext(self)
        self.requestPath = None
        self.requestRawPath = None

    def getUriRoutingContext(self) -> UriRoutingContext:
        return self.uriRoutingContext

    def checkState(self):
        pass

    def getRequestUri(self) -> URI:
        return self.requestUri

    def getBaseUri(self) -> URI:
        return self.baseUri

    def getPath(self, decode: bool):

        if decode:
            if self.requestPath:
                return self.requestPath
            self.requestPath = unquote(self.requestUri.getRawPath())
            return self.requestPath
        elif self.requestRawPath:
            return self.requestRawPath

        self.requestRawPath = self.requestUri.getRawPath()
        return self.requestRawPath
