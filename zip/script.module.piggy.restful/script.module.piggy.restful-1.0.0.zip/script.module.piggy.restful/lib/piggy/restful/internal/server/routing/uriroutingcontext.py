from typing import Type, Callable, List

from piggy.base import UnsupportedOperationException
from piggy.base.net.uri import URI
from piggy.base.util.collections import Collections
from piggy.restful.core.piggyuribuilder import PiggyUriBuilder
from piggy.restful.utils.collection.immutablemultivaluedmap import ImmutableMultivaluedMap
from ws.rs.container.resourceinfo import ResourceInfo
from ws.rs.core.multivaluedmap import MultivaluedMap
from ws.rs.core.multivaluesimplemap import MultivaluedSimpleMap
from ws.rs.core.pathsegment import PathSegment
from ws.rs.core.uribuilder import UriBuilder
from ws.rs.core.uriinfo import UriInfo


class UriRoutingContext(ResourceInfo, UriInfo):
    def __init__(self, requestContext: 'ContainerRequest'):
        self.matchedResources = list()
        self.requestContext = requestContext
        self.resourceMethodInvoker = None
        self.decodedQuery = None
        self.encodedQuery = None
        self.decodedPathParams = None
        self.encodedPathParams = None

    def setResourceMethodInvoker(self, rmi: 'ResourceMethodInvoker'):
        self.resourceMethodInvoker = rmi

    def getResourceMethodInvoker(self) -> 'ResourceMethodInvoker':
        return self.resourceMethodInvoker

    # ResourceInfo
    def getResourceClass(self) -> Type:
        return self.resourceMethodInvoker.getResourceClass()

    def getResourceMethod(self) -> Callable:
        return self.resourceMethodInvoker.getResourceMethod()

    # UriInfo
    def getAbsolutePath(self) -> URI:
        return self.requestContext.getAbsolutePath()

    def getAbsolutePathBuilder(self) -> UriBuilder:
        return PiggyUriBuilder().uri(self.getAbsolutePath())

    def getBaseUri(self) -> URI:
        return self.requestContext.getBaseUri()

    def getBaseUriBuilder(self) -> UriBuilder:
        return PiggyUriBuilder().uri(self.getBaseUri())

    def getMatchedResources(self) -> List[object]:
        # FIXME
        '''
        @Path("foo")
        public class FooResource {
            @GET
            public String getFoo() {...}
            @Path("bar")
            public BarResource getBarResource() {...}
        }

         public class BarResource {
            @GET
            public String getBar() {...}
         }
        GET /foo/bar	BarResource.getBar	BarResource, FooResource

        '''
        return Collections.unmodifiableList(self.matchedResources)

    def getMatchedURIs(self, decode: bool = True) -> List[str]:
        raise UnsupportedOperationException("Not supported yet.")

    def getPath(self, decode: bool = True) -> str:
        return self.requestContext.getPath(decode)

    def getPathParams(self, decode: bool) -> MultivaluedMap[str, str]:
        map: MultivaluedSimpleMap[str, str] = MultivaluedSimpleMap[str, str]()
        aPath: str = PiggyUriBuilder.fromResource(self.resourceMethodInvoker.app).path(
            self.resourceMethodInvoker.endpoint
        ).path(self.resourceMethodInvoker.fnc).toTemplate()
        rPath = self.getPath(decode)
        template = aPath.split('/')
        requestURI = rPath.split('/')
        for idx in range(0, len(template)):
            if template[idx].find('{') > -1:
                map.addFirst(template[idx].replace('{', '').replace('}', ''), requestURI[idx])
        return ImmutableMultivaluedMap(map)

    def getPathParameters(self, decode: bool = True) -> MultivaluedMap[str, str]:
        if decode:
            if self.decodedPathParams:
                return self.decodedPathParams
            self.decodedPathParams = self.getPathParams(decode)
            return self.decodedPathParams
        else:
            if self.encodedPathParams:
                return self.encodedPathParams
            self.encodedPathParams = self.getPathParams(decode)
            return self.encodedPathParams

    def getPathSegments(self, decode: bool = True) -> List[PathSegment]:
        raise UnsupportedOperationException("Not supported yet.")

    def getQueryParams(self, decode: bool) -> MultivaluedMap[str, str]:
        # FIXME
        qp = MultivaluedSimpleMap[str, str]()
        query = self.getRequestUri().getQuery() if decode else self.getRequestUri().getRawQuery()
        qc = query.split('&')
        for q in qc:
            k, v = q.split('=')
            qp.add(k, v)
        return ImmutableMultivaluedMap(qp)

    def getQueryParameters(self, decode: bool = True) -> MultivaluedMap[str, str]:
        if decode:
            if self.decodedQuery:
                return self.decodedQuery
            self.decodedQuery = self.getQueryParams(decode)
            return self.decodedQuery

        else:
            if self.encodedQuery:
                return self.encodedQuery
            self.encodedQuery = self.getQueryParams(decode)
            return self.encodedQuery

    def getRequestUri(self) -> URI:
        return self.requestContext.getRequestUri()

    def getRequestUriBuilder(self) -> UriBuilder:
        return UriBuilder.fromUri(self.getRequestUri())

    def relativize(self, uri: URI) -> URI:
        raise UnsupportedOperationException("Not supported yet.")

    def resolve(self, uri: URI) -> URI:
        raise UnsupportedOperationException("Not supported yet.")
