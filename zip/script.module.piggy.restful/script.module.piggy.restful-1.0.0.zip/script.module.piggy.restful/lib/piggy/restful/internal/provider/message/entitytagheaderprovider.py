from piggy.base import UnsupportedOperationException
from ws.rs.core.entitytag import EntityTag
from ws.rs.ext.runtimedelegate import RuntimeDelegate, T


class EntityTagHeaderProvider(RuntimeDelegate.HeaderDelegate[EntityTag]):
    def toString(self, value: T) -> str:
        raise UnsupportedOperationException("Not supported yet.")

    def fromString(self, value: str) -> T:
        raise UnsupportedOperationException("Not supported yet.")

