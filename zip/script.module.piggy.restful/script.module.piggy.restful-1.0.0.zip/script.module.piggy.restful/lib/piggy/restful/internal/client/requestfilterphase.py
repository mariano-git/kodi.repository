from piggy.base.util.logging import Logger
from typing import Set

from piggy.base import Raisable
from piggy.restful.client.abortexception import AbortException
from piggy.restful.client.clientproperties import ClientProperties
from piggy.restful.client.clientrequest import ClientRequest
from piggy.restful.client.clientresponse import ClientResponse
from piggy.restful.ext.binder import Binder
from piggy.restful.utils.annotationutils import AnnotationUtils
from ws.rs.client.clientrequestfilter import ClientRequestFilter
from ws.rs.core.response import Response
from ws.rs.namebinding import NameBinding
from ws.rs.processingexception import ProcessingException


class RequestFilterPhase:
    __lg__ = Logger.getLogger(f'{__name__}.{__qualname__}')

    def __init__(self, binder: Binder):
        self.binder = binder

    def apply(self, requestContext: ClientRequest):
        self.__lg__.debug("Start Applying filters for: %s", requestContext)
        bindings = requestContext.getConfiguration().getProperty(ClientProperties.CLIENT_NAME_BINDINGS)

        predicate = None
        if bindings is not None:
            bindings = set(bindings)

            def bind(provider, nameBinding):
                if nameBinding:
                    bounds = set(nameBinding.getAnnotations())
                    common = bindings.intersection(bounds)
                    return common is not None and len(common) > 0
                return True

            predicate = bind

        filters: Set[ClientRequestFilter] = self.binder.getByContract(ClientRequestFilter, predicate)
        self.__lg__.debug("Filters to apply: %s", filters)
        for requestFilter in filters:
            self.__lg__.debug("Applying Filter: %s", requestFilter)
            try:
                requestFilter.filter(requestContext)
            except Raisable as raisable:
                raise ProcessingException(raisable)
            abortResponse: Response = requestContext.getAbortResponse()
            if abortResponse:
                raise AbortException(ClientResponse(requestContext, abortResponse))
