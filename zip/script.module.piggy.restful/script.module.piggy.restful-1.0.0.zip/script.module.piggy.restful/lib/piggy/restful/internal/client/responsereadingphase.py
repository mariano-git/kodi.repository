from typing import Type, List, Iterable

from piggy.base import Raisable, Overload
from piggy.base.io.bytearrayinputstream import ByteArrayInputStream
from piggy.base.io.inputstream import InputStream
from piggy.base.notation import Annotation
from piggy.base.util.logging import Logger
from piggy.restful.ext.binder import Binder
from piggy.restful.internal.message.baseinterceptorcontext import BaseInterceptorContext
from piggy.restful.internal.message.entityinputstream import EntityInputStream
from piggy.restful.internal.message.messagebodyprovidernotfoundexception import MessageBodyProviderNotFoundException
from piggy.restful.internal.propertiesdelegate import PropertiesDelegate
from ws.rs.badrequestexception import BadRequestException
from ws.rs.core.httpheaders import HttpHeaders
from ws.rs.core.mediatype import MediaType
from ws.rs.core.multivaluedmap import MultivaluedMap
from ws.rs.core.nocontentexception import NoContentException
from ws.rs.ext.messagebodyreader import MessageBodyReader
from ws.rs.ext.readerinterceptor import ReaderInterceptor
from ws.rs.ext.readerinterceptorcontext import ReaderInterceptorContext


class UnCloseableInputStream(InputStream):
    def __init__(self, original: InputStream, reader: MessageBodyReader):
        self.original = original
        self.reader = reader

    @Overload
    def read(self) -> int:
        return self.original.read()

    @Overload
    def read(self, b: bytearray) -> int:
        return self.original.read(b, 0, len(b))

    @Overload
    def read(self, b: bytearray, off: int, length: int) -> int:
        return self.original.read(b, off, length)

    def skip(self, l: int) -> int:
        return self.original.skip(l)

    def available(self) -> int:
        return self.original.available()

    def mark(self, i: int):
        self.original.mark(i)

    def reset(self):
        self.original.reset()

    def markSupported(self) -> bool:
        return self.original.markSupported()

    def close(self):
        pass

    def unwrap(self) -> InputStream:
        return self.original

    def readAllBytes(self):
        if isinstance(self.original, ByteArrayInputStream):
            return self.original.readAllBytes()

        return self.original.readAllBytes()

    @staticmethod
    def closeableInputStream(inputStream: InputStream) -> InputStream:
        if isinstance(inputStream, UnCloseableInputStream):
            return inputStream.unwrap()
        else:
            return inputStream


class TerminalReaderInterceptor(ReaderInterceptor):
    __lg__ = Logger.getLogger(f'{__name__}.{__qualname__}')

    def __init__(self, phase, workers: 'MessageBodyWorkers'):
        self.workers = workers
        self.translateNce = False
        self.phase = phase

    def aroundReadFrom(self, context: ReaderInterceptorContext) -> object:
        bodyReader: MessageBodyReader = self.workers.getMessageBodyReader(
            context.getType(),
            context.getGenericType(),
            context.getAnnotations(),
            context.getMediaType(),
            self.phase
        )

        entityInput: EntityInputStream = EntityInputStream(context.getInputStream())
        if bodyReader is None:
            if entityInput.isEmpty() and not context.getHeaders().containsKey(HttpHeaders.CONTENT_TYPE):
                return None
            else:
                raise MessageBodyProviderNotFoundException(f'MessageBodyReader not found for media type='
                                                           f'{context.getMediaType()}, '
                                                           f'type={context.getType()}, '
                                                           f'genericType={context.getGenericType()}.')

        entity: object = self.invokeReadFrom(context, bodyReader, entityInput)

        return entity

    def invokeReadFrom(self, context: ReaderInterceptorContext, reader: MessageBodyReader,
                       entityStream: EntityInputStream) -> object:
        stream: UnCloseableInputStream = UnCloseableInputStream(entityStream, reader)
        try:
            return reader.readFrom(context.getType(), context.getGenericType(), context.getAnnotations(),
                                   context.getMediaType(), context.getHeaders(), stream)
        except NoContentException as ex:
            if self.translateNce:
                raise BadRequestException(ex)
            else:
                raise ex


class ResponseReadingPhase(BaseInterceptorContext, ReaderInterceptorContext):

    def __init__(self, rawType: Type, cls: Type,
                 annotations: List[Annotation],
                 mediaType: MediaType,
                 headers: MultivaluedMap[str, str],
                 propertiesDelegate: PropertiesDelegate,
                 inputStream: InputStream,
                 workers: 'MessageBodyWorkers',
                 readerInterceptors: Iterable[ReaderInterceptor],
                 translateNce: bool,
                 binder: Binder):
        super().__init__(rawType, cls, annotations, mediaType, propertiesDelegate)

        self.headers = headers
        self.inputStream = inputStream
        self.workers = workers
        self.translateNce = translateNce
        self.binder = binder
        self.interceptors = list(readerInterceptors)
        self.interceptors.append(TerminalReaderInterceptor(self, workers))

    def proceed(self) -> object:
        if self.interceptors is None or len(self.interceptors) == 0:
            return
        next: ReaderInterceptor = self.interceptors.pop(0)
        try:
            return next.aroundReadFrom(self)
        except Raisable as t:
            raise t

    def getInputStream(self) -> InputStream:
        return self.inputStream

    def setInputStream(self, inputStream: InputStream):
        self.inputStream = inputStream

    def getHeaders(self) -> MultivaluedMap[str, str]:
        return self.headers
