from piggy.base.util.logging import Logger
from typing import Type, List, Iterable, Set

from piggy.base import Raisable
from piggy.base.io import Closeable
from piggy.base.io.inputstream import InputStream
from piggy.base.io.outputstream import OutputStream
from piggy.base.notation import Annotation
from piggy.base.util.map import Map
from piggy.restful.ext.binder import Binder
from piggy.restful.internal.client.requestwritingphase import RequestWritingPhase
from piggy.restful.internal.client.responsereadingphase import ResponseReadingPhase
from piggy.restful.internal.propertiesdelegate import PropertiesDelegate
from ws.rs.core.mediatype import MediaType
from ws.rs.core.multivaluedmap import MultivaluedMap
from ws.rs.ext.messagebodyreader import MessageBodyReader
from ws.rs.ext.messagebodywriter import MessageBodyWriter
from ws.rs.ext.readerinterceptor import ReaderInterceptor
from ws.rs.ext.writerinterceptor import WriterInterceptor


class MessageBodyWorkers:
    __lg__ = Logger.getLogger(f'{__name__}.{__qualname__}')

    def __init__(self, binder: Binder):
        self.binder = binder

    def getMessageBodyWriter(self, cls: Type, genericType: Type, annotations: List[Annotation], mediaType: MediaType,
                             propertiesDelegate: PropertiesDelegate) -> MessageBodyWriter:
        self.__lg__.debug("Requesting MessageBodyWriters\n"
                          "        cls: %s\n"
                          "genericType: %s\n"
                          "annotations: %s\n"
                          "  mediaType: %s\n"
                          " properties: %s",
                          cls, genericType, annotations, mediaType, propertiesDelegate)

        writers: Set[MessageBodyWriter] = self.binder.getByContract(MessageBodyWriter)
        # TODO: Mariano, future functionality
        # cache: Set[MessageBodyWriter] = set()
        for writer in writers:
            if writer.isWriteable(type, genericType, annotations, mediaType):
                self.__lg__.debug("getMessageBodyWriter about to return: %s", writer)
                return writer
        # Easily give up
        return None

    def writeTo(self, entity: object, rawType: Type, genericType: Type, annotations: List[Annotation],
                mediaType: MediaType,
                httpHeaders: MultivaluedMap[str, object],
                propertiesDelegate: PropertiesDelegate,
                entityStream: OutputStream,
                writerInterceptors: Iterable[WriterInterceptor]) -> OutputStream:

        phase: RequestWritingPhase = RequestWritingPhase(
            entity,
            rawType,
            genericType,
            annotations,
            mediaType,
            httpHeaders,
            propertiesDelegate,
            entityStream,
            self,
            writerInterceptors, self.binder)

        try:
            phase.proceed()
        except Raisable as r:
            raise r

        return phase.getOutputStream()

    def writersToString(self, writers: Map[MediaType, List[MessageBodyWriter]]) -> str:
        return self.toString(writers)

    def readFrom(self, rawType: Type, cls:Type, annotations: List[Annotation], mediaType: MediaType,
                 headers: MultivaluedMap[str, str],
                 propertiesDelegate: PropertiesDelegate,
                 entityStream: InputStream,
                 readerInterceptors: Iterable[ReaderInterceptor],
                 translateNce: bool):

        phase: ResponseReadingPhase = ResponseReadingPhase(
            rawType,
            cls,
            annotations,
            mediaType,
            headers,
            propertiesDelegate,
            entityStream,
            self,
            readerInterceptors,
            translateNce, self.binder
        )

        try:
            instance: object = phase.proceed()
            if not isinstance(instance, Closeable): # and not isinstance(instance, Source):
                stream: InputStream = phase.getInputStream()
                if stream is not entityStream and stream is not None:
                    # We only close stream if it differs from the received entity stream,
                    # otherwise we let the caller close the stream.
                    stream.close()  # ReaderWriter.safelyClose(stream);

            return instance
        except Raisable as r:
            raise r

    def getMessageBodyReader(self, cls: Type, genericType: Type, annotations: List[Annotation], mediaType: MediaType,
                             propertiesDelegate: PropertiesDelegate):
        self.__lg__.debug("Requesting MessageBodyReaders\n"
                          "        cls: %s\n"
                          "genericType: %s\n"
                          "annotations: %s\n"
                          "  mediaType: %s\n"
                          " properties: %s",
                          cls, genericType, annotations, mediaType, propertiesDelegate)

        readers: Set[MessageBodyReader] = self.binder.getByContract(MessageBodyReader)
        # TODO: Mariano, future functionality
        # cache: Set[MessageBodyWriter] = set()
        for reader in readers:
            if reader.isReadable(type, genericType, annotations, mediaType):
                self.__lg__.debug("getMessageBodyReader about to return: %s", reader)
                return reader
        # Easily give up
        return None
