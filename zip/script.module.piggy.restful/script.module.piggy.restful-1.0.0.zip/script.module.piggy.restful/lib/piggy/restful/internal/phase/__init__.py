class PhaseContext:
    pass


class Phase:
    def apply(self, context: PhaseContext):
        pass
