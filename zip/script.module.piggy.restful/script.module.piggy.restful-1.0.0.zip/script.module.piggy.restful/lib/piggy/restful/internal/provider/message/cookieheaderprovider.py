from piggy.base import UnsupportedOperationException

from ws.rs.core.cookie import Cookie
from ws.rs.ext.runtimedelegate import RuntimeDelegate, T


class CookieHeaderProvider(RuntimeDelegate.HeaderDelegate[Cookie]):
    def toString(self, value: T) -> str:
        raise UnsupportedOperationException("Not supported yet.")

    def fromString(self, value: str) -> T:
        raise UnsupportedOperationException("Not supported yet.")

