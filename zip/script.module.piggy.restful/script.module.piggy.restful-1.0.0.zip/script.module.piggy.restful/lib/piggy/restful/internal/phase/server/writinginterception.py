from piggy.restful.internal.phase.server import ServerPhaseContext

from piggy.restful.internal.phase import Phase


class WritingInteception(Phase):
    def apply(self, context: ServerPhaseContext):
        # TODO
        pass
