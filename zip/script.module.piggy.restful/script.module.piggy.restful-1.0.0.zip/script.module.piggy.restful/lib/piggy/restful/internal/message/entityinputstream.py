from piggy.base import IllegalStateException
from piggy.base.io import IOException
from piggy.base.io.bytearrayinputstream import ByteArrayInputStream
from piggy.base.io.inputstream import InputStream

from ws.rs.processingexception import ProcessingException


class EntityInputStream(InputStream):

    def __init__(self, inputStream: InputStream):
        self.inputStream = inputStream
        self.closed = False

    @staticmethod
    def create(inputStream: InputStream):
        if isinstance(inputStream, EntityInputStream):
            return inputStream
        return EntityInputStream(inputStream)

    def read(self, b: bytearray = None, off: int = None, length: int = None) -> int:
        return self.inputStream.read(b, off, length)

    def skip(self, n: int) -> int:
        return self.inputStream.skip(n)

    def available(self) -> int:
        return self.inputStream.available()

    def mark(self, readlimit: int):
        self.inputStream.mark(readlimit)

    def markSupported(self) -> bool:
        return self.inputStream.markSupported()

    def reset(self):
        try:
            self.inputStream.reset()
        except IOException as ex:
            raise ProcessingException('Error resetting the buffered message content input stream.', ex)

    def close(self):
        if self.inputStream is None:
            return
        if not self.closed:
            try:
                self.inputStream.close()
            except IOException as ex:
                raise ProcessingException('Error closing message content input stream.', ex)
            finally:
                self.closed = True

    def isEmpty(self) -> bool:
        self.ensureNotClosed()
        if self.inputStream is None:
            return True
        try:
            if self.inputStream.markSupported():
                self.inputStream.mark(1)
                i: int = self.inputStream.read()
                self.inputStream.reset()
                return i == -1
            else:
                try:
                    if self.inputStream.available() > 0:
                        return False
                except IOException as ioe:
                    pass
                b: int = self.inputStream.read()
                if b == -1:
                    return True

                pbis: PushbackInputStream
                if isinstance(self.inputStream, PushbackInputStream):
                    pbis = self.inputStream
                else:
                    pbis = PushbackInputStream(self.inputStream, 1)
                    self.inputStream = pbis

                pbis.unread(b)

                return False

        except IOException as ex:
            raise ProcessingException(ex)

    def ensureNotClosed(self):
        if self.closed:
            raise IllegalStateException('Stream is closed')

    def isClosed(self) -> bool:
        return self.closed

    def getWrappedStream(self) -> InputStream:
        return self.inputStream

    def setWrappedStream(self, wrapped: InputStream):
        self.inputStream = wrapped

    def readAllBytes(self):
        if isinstance(self.inputStream, ByteArrayInputStream):
            return self.inputStream.readAllBytes()

        return self.inputStream.readAllBytes()
