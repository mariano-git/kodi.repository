from typing import Collection, Union, Dict, cast

from piggy.restful.internal.propertiesdelegate import PropertiesDelegate

from piggy.base.util.collections import Collections


class MapPropertiesDelegate(PropertiesDelegate):
    __slots__ = '__store__'

    def __init__(self, store: Union[Dict[str, object], PropertiesDelegate] = None):
        self.__store__:Dict[str, object] = dict()
        if store:
            if isinstance(store, MapPropertiesDelegate):
                self.__store__.update(cast(MapPropertiesDelegate, store).__store__)
            elif isinstance(store, dict):
                self.__store__.update(store)

    def getProperty(self, name: str) -> object:
        return self.__store__.get(name)

    def getPropertyNames(self) -> Collection[str]:
        return Collections.unmodifiableSet(set(self.__store__.keys()))

    def removeProperty(self, name: str):
        del self.__store__[name]

    def setProperty(self, name: str, value: object):
        self.__store__[name] = value
