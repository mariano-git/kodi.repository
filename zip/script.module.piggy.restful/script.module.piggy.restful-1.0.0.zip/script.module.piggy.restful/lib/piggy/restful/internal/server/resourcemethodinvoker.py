import inspect
from typing import Type, Callable, Optional, Set, Dict

from piggy.base import UnsupportedOperationException
from piggy.base.util.logging import Logger
from piggy.restful.internal.server.containerrequest import ContainerRequest
from piggy.restful.utils.annotationutils import AnnotationUtils
from ws.rs.beanparam import BeanParam
from ws.rs.consumes import Consumes
from ws.rs.cookieparam import CookieParam
from ws.rs.core.application import Application
from ws.rs.core.response import Response
from ws.rs.formparam import FormParam
from ws.rs.headerparam import HeaderParam
from ws.rs.httpmethod import HttpMethod
from ws.rs.matrixparam import MatrixParam
from ws.rs.pathparam import PathParam
from ws.rs.produces import Produces
from ws.rs.queryparam import QueryParam


class ResourceMethodInvoker:
    __lg__ = Logger.getLogger(f'{__name__}.{__qualname__}')

    def __init__(self, app: Application, endpoint: Type, fnc: Callable, template: bool):
        self.app = app
        self.endpoint = endpoint
        self.fnc = fnc
        self.template = template

    def resolveQueryParam(self, kwarg, qparam, request, kwargs):
        self.__lg__.debug('resolveQueryParam: %s, %s', kwarg, qparam)
        query = request.getUriRoutingContext().getQueryParameters()
        value = query.get(qparam)
        value = value[0] if len(value) == 1 else value
        if value is not None:
            kwargs[kwarg] = value

    def resolvePathParam(self, kwarg, pparam, request, kwargs):
        self.__lg__.debug('resolvePathParam: %s, %s', kwarg, pparam)
        params = request.getUriRoutingContext().getPathParameters()
        value = params.get(pparam)
        value = value[0] if len(value) == 1 else value
        if value is not None:
            kwargs[kwarg] = value

    def resolveArgument(self, k, v, request: ContainerRequest, kwargs: Dict):

        if v.annotation is not inspect.Parameter.empty:
            if v.annotation is QueryParam or isinstance(v.annotation, QueryParam):
                self.resolveQueryParam(k, AnnotationUtils.getAnnotationValue(v.annotation, QueryParam, k), request,
                                       kwargs)
            elif v.annotation is PathParam or isinstance(v.annotation, PathParam):
                self.resolvePathParam(k, AnnotationUtils.getAnnotationValue(v.annotation, PathParam, k), request,
                                      kwargs)
            elif v.annotation is MatrixParam:
                pass
            elif v.annotation is HeaderParam:
                pass
            elif v.annotation is CookieParam:
                pass
            elif v.annotation is FormParam:
                pass
            elif v.annotation is BeanParam:
                pass

    def invoke(self, request: ContainerRequest) -> Response:

        signature = inspect.signature(self.fnc)
        # response type
        responseType = signature.return_annotation

        # determine httpMethod
        httpMethod = AnnotationUtils.getAnnotationValue(self.fnc, HttpMethod, None)
        if httpMethod is None:
            raise UnsupportedOperationException("Not a resource method.")

        produces: Optional[Set[str]] = AnnotationUtils.getAnnotationValue(self.fnc, Produces, None)
        if produces is None:
            produces = AnnotationUtils.getAnnotationValue(self.endpoint, Produces, None)
        accepts: str = ','.join(produces) if produces else ''

        consumes: Optional[Set[str]] = AnnotationUtils.getAnnotationValue(self.fnc, Consumes, None)
        if consumes is None:
            consumes = AnnotationUtils.getAnnotationValue(self.endpoint, Consumes, None)
        contentType = ','.join(consumes) if consumes else None

        parameters = signature.parameters
        paramSz = len(parameters)
        idx = paramSz - 1  # skip self

        entity: object = None
        entityType: Type = None
        kwargs = {}
        # skip parameters without annotations
        for k, v in reversed(parameters.items()):
            if idx > 0:
                self.resolveArgument(k, v, request, kwargs)
            idx -= 1

        instance = self.endpoint()
        args = tuple()

        ret = self.fnc(instance, *args, **kwargs)
