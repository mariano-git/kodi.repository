from __future__ import annotations

from typing import List, Set, Type, cast, Callable, TypeVar, Optional

from piggy.base import UnsupportedOperationException, Overload, Raisable
from piggy.base.io.outputstream import OutputStream
from piggy.base.net.uri import URI
from piggy.base.notation import Annotation
from piggy.base.util import Objects
from piggy.base.util.collections import Collections
from piggy.base.util.date import Date
from piggy.base.util.locale import Locale
from piggy.base.util.map import Map
from piggy.restful.internal.message.committingoutputstream import CommittingOutputStream
from piggy.restful.internal.message.headervalueexception import HeaderValueException
from piggy.restful.utils.headerutils import HeaderUtils
from piggy.restful.utils.reflectionhelper import ReflectionHelper
from ws.rs.core.configuration import Configuration
from ws.rs.core.entitytag import EntityTag
from ws.rs.core.genericentity import GenericEntity
from ws.rs.core.generictype import GenericType
from ws.rs.core.httpheaders import HttpHeaders
from ws.rs.core.link import Link
from ws.rs.core.mediatype import MediaType
from ws.rs.core.multivaluedmap import MultivaluedMap
from ws.rs.ext.runtimedelegate import RuntimeDelegate
from ws.rs.processingexception import ProcessingException

T = TypeVar('T')


class OutboundMessageContext:
    __slots__ = '__configuration__', '__headers__', '__committingOutputStream__', '__entityStream__', '__entity__', \
                '__entityType__', '__entityAnnotations__'

    # interface
    class StreamProvider:
        # abstract
        def getOutputStream(self, _int: int) -> OutputStream:
            raise UnsupportedOperationException("This method is abstract and must be implemented.")

    # --------------------------------

    @Overload
    def __init__(self, original: OutboundMessageContext):
        self.__headers__ = HeaderUtils.createOutbound()
        if original: self.__headers__.putAll(original.__headers__)
        self.__committingOutputStream__ = CommittingOutputStream()
        self.__entityStream__ = self.__committingOutputStream__

        self.__entity__ = original.__entity__ if original else None
        self.__entityType__: GenericType = original.__entityType__ if original else None
        self.__entityAnnotations__ = original.__entityAnnotations__ if original else None
        self.__configuration__: Configuration = original.__configuration__ if original else None

    @Overload
    def __init__(self, configuration: Configuration):
        self.__configuration__: Configuration = configuration
        self.__headers__ = HeaderUtils.createOutbound()
        self.__committingOutputStream__ = CommittingOutputStream()
        self.__entityStream__ = self.__committingOutputStream__
        self.__entity__ = None
        self.__entityType__: GenericType = None
        self.__entityAnnotations__ = None

    def close(self):
        raise UnsupportedOperationException("Not supported yet.")

    def commitStream(self):
        if not self.__committingOutputStream__.isCommitted():
            self.__entityStream__.flush()
            if not self.__committingOutputStream__.isCommitted():
                self.__committingOutputStream__.commit()
                self.__committingOutputStream__.flush()

    def enableBuffering(self, _configuration: Configuration):
        raise UnsupportedOperationException("Not supported yet.")

    def getAcceptableLanguages(self) -> List:
        raise UnsupportedOperationException("Not supported yet.")

    def getAcceptableMediaTypes(self) -> List:
        raise UnsupportedOperationException("Not supported yet.")

    def getAllowedMethods(self) -> Set:
        raise UnsupportedOperationException("Not supported yet.")

    def setConfiguration(self, configuration: Configuration):
        self.__configuration__ = configuration

    def getConfiguration(self) -> Configuration:
        return self.__configuration__

    def getDate(self) -> Date:
        raise UnsupportedOperationException("Not supported yet.")

    def getEntity(self) -> object:
        return self.__entity__

    def getEntityAnnotations(self) -> List[Annotation]:
        return list(self.__entityAnnotations__)

    def getEntityClass(self) -> Type:
        return self.__entityType__.getRawType() if self.__entityType__ else None

    def getEntityStream(self) -> OutputStream:
        return self.__entityStream__

    def getEntityTag(self) -> EntityTag:
        raise UnsupportedOperationException("Not supported yet.")

    def getEntityType(self) -> Type:
        return self.__entityType__.getType() if self.__entityType__ else None

    def getHeaderString(self, _string: str) -> str:
        raise UnsupportedOperationException("Not supported yet.")

    def getHeaders(self) -> MultivaluedMap[str, object]:
        return self.__headers__

    def getLanguage(self) -> Locale:
        raise UnsupportedOperationException("Not supported yet.")

    def getLastModified(self) -> Date:
        raise UnsupportedOperationException("Not supported yet.")

    def getLength(self) -> int:
        raise UnsupportedOperationException("Not supported yet.")

    def getLengthLong(self) -> int:
        raise UnsupportedOperationException("Not supported yet.")

    def getLink(self, _string: str) -> Link:
        raise UnsupportedOperationException("Not supported yet.")

    def getLinkBuilder(self, _string: str) -> Link.Builder:
        raise UnsupportedOperationException("Not supported yet.")

    def getLinks(self) -> Set:
        raise UnsupportedOperationException("Not supported yet.")

    def getLocation(self) -> URI:
        raise UnsupportedOperationException("Not supported yet.")

    def getMediaType(self) -> MediaType:
        def converter(value: str) -> MediaType:
            return RuntimeDelegate.getInstance().createHeaderDelegate(
                MediaType
            ).fromString(value)

        return self.singleHeader(HttpHeaders.CONTENT_TYPE, MediaType, converter, False)

    def getRequestCookies(self) -> Map:
        raise UnsupportedOperationException("Not supported yet.")

    def getResponseCookies(self) -> Map:
        raise UnsupportedOperationException("Not supported yet.")

    def getStringHeaders(self) -> MultivaluedMap[str, str]:
        return HeaderUtils.asStringHeaders(self.__headers__, self.__configuration__)

    def hasEntity(self) -> bool:
        return self.__entity__ is not None

    def hasLink(self, _string: str) -> bool:
        raise UnsupportedOperationException("Not supported yet.")

    def isCommitted(self) -> bool:
        raise UnsupportedOperationException("Not supported yet.")

    def replaceHeaders(self, headers: MultivaluedMap[str, object]):
        self.getHeaders().clear()
        if headers:
            self.getHeaders().putAll(headers)

    @Overload
    def setEntity(self, entity: object):
        self.setEntity(entity, ReflectionHelper.genericTypeFor(entity))

    @Overload
    def setEntity(self, entity: object, _type: GenericType):
        if isinstance(entity, GenericEntity):
            self.__entity__ = cast(GenericEntity, entity).getEntity()
        else:
            self.__entity__ = entity
        self.__entityType__ = _type

    @Overload
    def setEntity(self, entity: object, annotations: List[Annotation], mediaType: MediaType):
        self.setEntity(entity, annotations)
        self.setMediaType(mediaType)

    @Overload
    def setEntity(self, entity: object, annotations: List[Annotation]):
        self.setEntity(entity, ReflectionHelper.genericTypeFor(entity))
        self.setEntityAnnotations(annotations)

    @Overload
    def setEntity(self, entity: object, _type: Type, annotations: List[Annotation]):
        self.setEntity(entity, GenericType(_type))
        self.setEntityAnnotations(annotations)

    def setEntityAnnotations(self, annotations: List[Annotation]):
        self.__entityAnnotations__ = Collections.emptyList() if annotations is None else annotations

    def setEntityStream(self, outputstream: OutputStream):
        self.__entityStream__ = outputstream

    def setEntityType(self, _type: Type):
        raise UnsupportedOperationException("Not supported yet.")

    def setMediaType(self, mediaType: MediaType):
        self.__headers__.putSingle(HttpHeaders.CONTENT_TYPE, mediaType)

    def setStreamProvider(self, streamProvider: OutboundMessageContext.StreamProvider):
        self.__committingOutputStream__.setStreamProvider(streamProvider)

    def singleHeader(self,
                     name: str,
                     valueType: Type,
                     converter: Callable[[Optional[List[str]]], Optional[T]],
                     convertNull: bool) -> Optional[T]:

        values: List[object] = self.__headers__.get(name)

        if Objects.isEmpty(values):
            return converter(None) if convertNull else None

        if len(values) > 1:
            raise HeaderValueException(
                f'Too many "{name}" header values: "{values}"',
                HeaderValueException.Context.OUTBOUND
            )

        value = values[0]
        if value is None:
            return converter(None) if convertNull else None

        if isinstance(value, valueType):
            return value
        else:
            try:
                return converter(HeaderUtils.asString(value, None))
            except ProcessingException as ex:
                raise self.exception(name, value, ex)

    def exception(self, headerName: str, headerValue: object, e: Raisable) -> HeaderValueException:
        return HeaderValueException(
            f'Unable to parse "{headerName}" header value: "{headerValue}"', e,
            HeaderValueException.Context.OUTBOUND)
