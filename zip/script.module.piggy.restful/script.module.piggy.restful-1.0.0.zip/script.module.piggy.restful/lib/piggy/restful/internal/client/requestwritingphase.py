from typing import Type, List

from piggy.base import Overload, Raisable
from piggy.base.io.outputstream import OutputStream
from piggy.base.notation import Annotation
from piggy.base.util.logging import Logger
from piggy.restful.ext.binder import Binder
from piggy.restful.internal.message.baseinterceptorcontext import BaseInterceptorContext
from piggy.restful.internal.message.messagebodyprovidernotfoundexception import MessageBodyProviderNotFoundException
from piggy.restful.internal.propertiesdelegate import PropertiesDelegate
from ws.rs.core.mediatype import MediaType
from ws.rs.core.multivaluedmap import MultivaluedMap
from ws.rs.ext.messagebodywriter import MessageBodyWriter
from ws.rs.ext.writerinterceptor import WriterInterceptor
from ws.rs.ext.writerinterceptorcontext import WriterInterceptorContext


class UnCloseableOutputStream(OutputStream):
    __lg__ = Logger.getLogger(f'{__name__}.{__qualname__}')

    def __init__(self, original: OutputStream, writer: MessageBodyWriter):
        self.original = original
        self.writer = writer

    @Overload
    def write(self, i: int):
        self.original.write(i)

    @Overload
    def write(self, b: bytes, off: int, length: int):
        self.original.write(b, off, length)

    @Overload
    def write(self, b: bytes):
        self.original.write(b, 0, len(b))

    def flush(self):
        self.original.flush()

    def close(self):
        if self.__lg__.isEnabledFor(Logger.INFO):
            self.__lg__.info('Message body writer (%s) is trying to close the entity output stream. Not closing.',
                             self.writer)


class FinalWriterInterceptor(WriterInterceptor):
    __lg__ = Logger.getLogger(f'{__name__}.{__qualname__}')

    def __init__(self, phase, workers: 'MessageBodyWorkers'):
        self.workers = workers
        self.phase = phase

    def aroundWriteTo(self, context: WriterInterceptorContext):
        try:
            writer: MessageBodyWriter = self.workers.getMessageBodyWriter(
                context.getType(), context.getGenericType(),
                context.getAnnotations(), context.getMediaType(), self.phase
            )

            if writer is None:
                msg = f'MessageBodyWriter not found for media ' \
                      f'type="{context.getMediaType()}", ' \
                      f'type="{context.getType()}", ' \
                      f'genericType="{context.getGenericType()}".'
                self.__lg__.fatal(msg)
                raise MessageBodyProviderNotFoundException(msg)

            self.invokeWriteTo(context, writer)
        except Raisable as t:
            raise t

    def invokeWriteTo(self, context: WriterInterceptorContext, writer: MessageBodyWriter):
        entityStream = UnCloseableOutputStream(context.getOutputStream(), writer)
        try:
            writer.writeTo(context.getEntity(), context.getType(), context.getGenericType(), context.getAnnotations(),
                           context.getMediaType(), context.getHeaders(), entityStream)
        except Raisable as t:
            raise t


class RequestWritingPhase(BaseInterceptorContext, WriterInterceptorContext):

    def __init__(self,
                 entity: object,
                 rawType: Type,
                 genericType: Type,
                 annotations: List[Annotation],
                 mediaType: MediaType,
                 headers: MultivaluedMap[str, object],
                 propertiesDelegate: PropertiesDelegate,
                 entityStream: OutputStream,
                 workers: 'MessageBodyWorkers',
                 writerInterceptors: List[WriterInterceptor],
                 binder: Binder
                 ):
        super().__init__(rawType, genericType, annotations, mediaType, propertiesDelegate)
        self.entity = entity
        self.headers = headers
        self.outputStream = entityStream
        self.binder = binder
        self.interceptors = list(writerInterceptors)
        self.interceptors.append(FinalWriterInterceptor(self, workers))

    def getEntity(self) -> object:
        return self.entity

    def getHeaders(self) -> MultivaluedMap[str, object]:
        return self.headers

    def getOutputStream(self) -> OutputStream:
        return self.outputStream

    def setEntity(self, entity: object):
        self.entity = entity

    def setOutputStream(self, output: OutputStream):
        self.outputStream = output

    def proceed(self):
        if self.interceptors is None or len(self.interceptors) == 0:
            return
        next: WriterInterceptor = self.interceptors.pop(0)
        try:
            next.aroundWriteTo(self)
        except Raisable as t:
            raise t
