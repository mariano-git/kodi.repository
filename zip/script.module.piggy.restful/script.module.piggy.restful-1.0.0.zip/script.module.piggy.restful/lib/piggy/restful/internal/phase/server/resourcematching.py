from piggy.base.util.logging import Logger
from piggy.restful.internal.phase import Phase
from piggy.restful.internal.phase.server import ServerPhaseContext
from piggy.restful.internal.server.resourcemethodinvoker import ResourceMethodInvoker
from ws.rs.notfoundexception import NotFoundException


class ResourceMatching(Phase):
    __lg__ = Logger.getLogger(f'{__name__}.{__qualname__}')

    def apply(self, context: ServerPhaseContext):
        containerRequest = context.getRequestContext()

        path = containerRequest.getPath(False)
        router = context.getRouter()

        route = router.match(path)
        if route is None:
            raise NotFoundException()

        containerRequest.getUriRoutingContext().setResourceMethodInvoker(
            ResourceMethodInvoker(route.app, route.cls, route.fnc, route.template)
        )
