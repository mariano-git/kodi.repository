from typing import Type

from piggy.base.stringbuilder import StringBuilder
from piggy.base.util import Objects
from piggy.base.util.simplemap import SimpleMap
from piggy.restful.internal.provider.message import TokenEventHander, HeaderTokenizer

from ws.rs.core.httpheaders import HttpHeaders
from ws.rs.core.mediatype import MediaType
from ws.rs.ext.runtimedelegate import RuntimeDelegate


class MediaTypeHeaderProvider(RuntimeDelegate.HeaderDelegate[MediaType]):
    @classmethod
    def supportsType(cls, _type_: Type) -> bool:
        return _type_ == MediaType

    @classmethod
    def supportsName(cls, name: str) -> bool:
        if Objects.isEmpty(name):
            return False
        return name.strip().lower() == HttpHeaders.CONTENT_TYPE.lower()

    def toString(self, header: MediaType) -> str:
        Objects.requireNonNull(header, 'Media type is null.')
        b = StringBuilder()
        b.append(header.getType()).append('/').append(header.getSubtype())
        for e in header.getParameters().entrySet():
            b.append(";").append(e.getKey()).append('=').append(e.getValue())
        return b.toString()

    def fromString(self, value: str) -> MediaType:

        class Hander(TokenEventHander):
            EVENTS = {'/': 'type', ';': 'subType', '=': 'propName', 'EOL': 'propValue'}

            def __init__(self):
                self.lastKey = None
                self.parts = {}

            def onToken(self, token, data, start, end):

                if token == '/':
                    self.parts['type'] = Objects.requireNonEmptyElse(data[start:end].strip(), '*')
                elif token == 'EOL' and 'subType' not in self.parts:
                    self.parts['subType'] = Objects.requireNonEmptyElse(data[start:end].strip(), '*')
                elif token == ';':
                    self.parts['subType'] = Objects.requireNonEmptyElse(data[start:end].strip(), '*')
                elif token == '=':
                    key = Objects.requireNonEmptyElse(data[start:end].strip(), None)
                    if key:
                        self.parts[key] = None
                        self.lastKey = key
                elif token == 'EOL':
                    self.parts[self.lastKey] = Objects.requireNonEmptyElse(data[start:end].strip(), None)


        handler = Hander()

        tokenizer = HeaderTokenizer('/;=', handler)
        tokenizer.process(value)

        def getAndRemove(parts, key):
            value = parts.get(key)
            if value:
                del parts[key]
                return value

            return None

        return MediaType(
            getAndRemove(handler.parts, 'type'),
            getAndRemove(handler.parts, 'subType'),
            SimpleMap(handler.parts)
        )
