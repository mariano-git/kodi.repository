import typing

from piggy.base import Overload
from piggy.base.net.uri import URI
from piggy.base.util.objects import Objects
from piggy.restful.client.clientproperties import ClientProperties
from piggy.restful.client.piggyinvocation import PiggyInvocation
from piggy.restful.core.configurablecomponent import ConfigurableComponent
from piggy.restful.core.piggyuribuilder import PiggyUriBuilder, QueryParamStyle
from ws.rs.client.invocation import Invocation
from ws.rs.client.webtarget import WebTarget
from ws.rs.core.mediatype import MediaType
from ws.rs.core.uribuilder import UriBuilder

if typing.TYPE_CHECKING:
    from piggy.restful.client.piggyclient import PiggyClient


class PiggyWebTarget(WebTarget, ConfigurableComponent[WebTarget]):

    def __init__(self, uriBuilder: PiggyUriBuilder, parent: ConfigurableComponent):
        super().__init__(None, parent.getConfiguration())
        self.parent = parent.parent if isinstance(parent, PiggyWebTarget) else parent
        self.uriBuilder: PiggyUriBuilder = uriBuilder

    def getUri(self) -> URI:
        return self.uriBuilder.build()

    def getUriBuilder(self) -> PiggyUriBuilder:
        self.parent.ensureOpen()
        return self.uriBuilder.clone()

    def path(self, path: str) -> WebTarget:
        self.parent.ensureOpen()
        Objects.requireNonNull(path, "path is 'null'.")
        return PiggyWebTarget(self.getUriBuilder().path(path), self)

    def queryParam(self, name: str, *values: object) -> WebTarget:
        self.parent.ensureOpen()
        uriBuilder: PiggyUriBuilder = self.getUriBuilder()
        queryParamStyle = self.getConfiguration().getProperty(ClientProperties.QUERY_PARAM_STYLE)
        if queryParamStyle is not None and isinstance(queryParamStyle, QueryParamStyle):
            uriBuilder.setQueryParamStyle(queryParamStyle)
        if Objects.isEmpty(values):
            return PiggyWebTarget(uriBuilder.replaceQueryParam(name, None), self)

        if len(values) > 1:
            for i in range(0, len(values)):
                Objects.requireNonNull(values[i], f'Null value detected on index: {i} for queryParam: {name}')
        else:
            value = values[0]
            Objects.requireNonNull(value, f'Null value detected for queryParam: {name}')
        return PiggyWebTarget(uriBuilder.queryParam(name, *values), self)

    @Overload
    def request(self) -> Invocation.Builder:
        self.parent.ensureOpen()
        return PiggyInvocation.Builder(self.getUri(), self.getConfiguration())

    @Overload
    def request(self, *acceptedResponseTypes: MediaType) -> Invocation.Builder:
        self.parent.ensureOpen()
        return PiggyInvocation.Builder(self.getUri(), self.getConfiguration()).accept(*acceptedResponseTypes)

    @Overload
    def request(self, *acceptedResponseTypes: str) -> Invocation.Builder:
        self.parent.ensureOpen()
        return PiggyInvocation.Builder(self.getUri(), self.getConfiguration()).accept(*acceptedResponseTypes)
