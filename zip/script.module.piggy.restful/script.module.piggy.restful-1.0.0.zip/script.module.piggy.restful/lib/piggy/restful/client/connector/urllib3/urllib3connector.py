from typing import Dict, Any

import urllib3
from urllib3 import Timeout
from urllib3.exceptions import NewConnectionError

from piggy.base import UnsupportedOperationException
from piggy.base.io.bytearrayinputstream import ByteArrayInputStream
from piggy.base.io.bytearrayoutputstream import ByteArrayOutputStream
from piggy.base.io.outputstream import OutputStream
from piggy.base.net.uri import URI
from piggy.base.util.logging import Logger
from piggy.restful.client.clientproperties import ClientProperties
from piggy.restful.client.clientrequest import ClientRequest
from piggy.restful.client.clientresponse import ClientResponse
from piggy.restful.client.clientresponseprocessingexception import ClientResponseProcessingException
from piggy.restful.client.connector import Connector, ConnectorProvider
from piggy.restful.internal.message.outboundmessagecontext import OutboundMessageContext
from ws.rs.client.client import Client
from ws.rs.core.configuration import Configuration
from ws.rs.core.response import Response


class Urllib3Connector(Connector):
    __lg__ = Logger.getLogger(f'{__name__}.{__qualname__}')

    def __init__(self):
        self.pool = urllib3.PoolManager()

    def getOutBoundHeaders(self, clientRequest):
        outbound = clientRequest.getRequestHeaders()
        headers = {}
        for entry in outbound.entrySet():
            name = entry.getKey()
            values = entry.getValue()
            sz = len(values) if values else 0
            value = None
            if sz > 1:
                value = ','.join(values)
            else:
                value = values[0]
            if name and value:
                headers[name] = value
        return headers

    def getOptions(self, clientRequest: ClientRequest):
        options = {}
        options['redirect'] = clientRequest.resolveProperty(ClientProperties.FOLLOW_REDIRECTS, True)
        connectTimeout = clientRequest.resolveProperty(ClientProperties.CONNECT_TIMEOUT, None)
        readTimeout = clientRequest.resolveProperty(ClientProperties.READ_TIMEOUT, None)

        timeOut = Timeout()
        try:
            timeOut._connect = timeOut._validate_timeout(connectTimeout, "connect")
        except:
            pass
        try:
            timeOut._read = timeOut._validate_timeout(readTimeout, "read")
        except:
            pass
        options['timeout'] = timeOut
        return options

    def buildRequestParams(self, clientRequest: ClientRequest) -> Dict[str, Any]:
        method: str = clientRequest.getMethod()
        entity: object = clientRequest.getEntity()
        entityStream = None
        if entity and method.upper() in ['GET', 'HEAD', 'DELETE']:
            self.__lg__.debug(
                f"Detected non-empty entity on a HTTP {method.upper()} request. "
                "The underlying HTTP transport connector may decide to change the request method to POST."
            )
        params = {
            'method': clientRequest.getMethod(),
            'url': clientRequest.getUri().toString(),
            'headers': self.getOutBoundHeaders(clientRequest)
        }
        entityStream = None
        if entity:
            self.processExtensions(clientRequest)

            class Urllib3StreamProvider(OutboundMessageContext.StreamProvider):
                def __init__(self):
                    self.out: ByteArrayOutputStream = None
                    self.contentLength = None

                def getOutputStream(self, contentLength: int) -> OutputStream:
                    self.out = ByteArrayOutputStream()
                    self.contentLength = contentLength
                    return self.out

                def getParams(self):
                    return {
                        'fields': None,  # {'filefield': None #('example.txt', file_data, 'text/plain'),}
                        'body': self.out.toBytes()
                    }

            entityStream = Urllib3StreamProvider()

            clientRequest.setStreamProvider(entityStream)
            clientRequest.writeEntity()

        if entityStream:
            params.update(entityStream.getParams())
        return params

    def apply(self, clientRequest: ClientRequest) -> ClientResponse:
        requestParams = self.buildRequestParams(clientRequest)
        try:
            response = self.pool.request(**requestParams)

            code = response.status
            # reasonPhrase = results.reason
            status = Response.Status.fromStatusCode(code)
            resolvedRequestedUri = URI.create(requestParams['url'])

            responseContext = ClientResponse(status, clientRequest, resolvedRequestedUri)

            for k, v in response.headers.items():
                responseContext.header(k, v)

            responseContext.setEntityStream(ByteArrayInputStream(response.data))

            return responseContext
        except Exception as e:
            # raise e
            self.handleException(clientRequest, e, requestParams)

    def handleException(self, clientRequest, exception, requestParams):
        # Fuck
        if hasattr(exception, 'reason'):
            exception = exception.reason

        if isinstance(exception, NewConnectionError):
            cause = exception.__context__ if exception.__context__ is not None else exception.__cause__ if exception.__cause__ is not None else None
            if cause is not None:
                code = getattr(cause, 'errno', None)
                reason = getattr(cause, 'strerror', None)
                status = Response.Status.REQUEST_TIMEOUT
                if code is not None:
                    status = Response.Status.fromStatusCode(code)
                    if status is None:
                        status = Response.Status(code, reason)

                resolvedRequestedUri = URI.create(requestParams['url'])

                responseContext = ClientResponse(status, clientRequest, resolvedRequestedUri)
                raise ClientResponseProcessingException(responseContext, cause)

        # FIXME Handle this exception
        raise exception

    def processExtensions(self, clientRequest):
        pass

    def close(self):
        # FIXME
        raise UnsupportedOperationException('#FIXME - close Urllib3connector')

    def getName(self) -> str:
        return f"urllib3/{urllib3.__version__}"


class Urllib3ConnectorProvider(ConnectorProvider):

    def getConnector(self, client: Client, configuration: Configuration) -> Connector:
        return Urllib3Connector()
