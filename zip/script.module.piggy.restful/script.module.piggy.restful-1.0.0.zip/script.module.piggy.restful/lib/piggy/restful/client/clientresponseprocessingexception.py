from piggy.base import Raisable
from piggy.restful.client.clientresponse import ClientResponse
from ws.rs.processingexception import ProcessingException


class ClientResponseProcessingException(ProcessingException):
    __slots__ = '__clientResponse__'

    def __init__(self, clientResponse: ClientResponse, cause: Raisable):
        super().__init__(cause)
        self.__clientResponse__ = clientResponse

    def getClientResponse(self) -> ClientResponse:
        return self.__clientResponse__
