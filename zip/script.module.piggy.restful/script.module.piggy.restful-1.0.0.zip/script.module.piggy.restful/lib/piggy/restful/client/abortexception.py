from piggy.restful.client.clientresponse import ClientResponse
from ws.rs.processingexception import ProcessingException


class AbortException(ProcessingException):
    __slots__ = '__abortResponse__'

    def __init__(self, abortResponse: ClientResponse):
        super().__init__("Request processing has been aborted")
        self.__abortResponse__ = abortResponse

    def getAbortResponse(self) -> ClientResponse:
        return self.__abortResponse__
