from piggy.restful.client.clientresponse import ClientResponse
from ws.rs.core.response import Response


class InboundResponse(Response):
    def __init__(self, context: ClientResponse, scope: 'RequestScope' = None):
        self.context: ClientResponse = context
        self.scope = scope
        self.closed = False

    def getStatusInfo(self) -> Response.StatusType:
        return self.context.getStatusInfo()

    def getStatus(self) -> int:
        return self.context.getStatusInfo().getStatusCode()

    def bufferEntity(self) -> bool:
        return self.context.bufferEntity()
