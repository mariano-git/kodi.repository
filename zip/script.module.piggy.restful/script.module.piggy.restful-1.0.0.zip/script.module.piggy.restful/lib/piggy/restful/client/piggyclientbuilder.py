from piggy.base.util.logging import Logger

from piggy.restful.client.piggyclient import PiggyClient

from piggy.base import IllegalArgumentException
from piggy.base.util.concurrent.timeunit import TimeUnit
from piggy.restful.client.clientproperties import ClientProperties
from piggy.restful.core.configurablecomponent import ConfigurableComponent
from ws.rs.client.client import Client
from ws.rs.client.clientbuilder import ClientBuilder
from ws.rs.core.configuration import Configuration
from ws.rs.runtimetype import RuntimeType


class PiggyClientBuilder(ClientBuilder, ConfigurableComponent[ClientBuilder]):
    __lg__ = Logger.getLogger(f'{__name__}.{__qualname__}')

    def __init__(self):
        self.__lg__.debug('__init__ self: %s', self)
        super().__init__(RuntimeType.CLIENT, None)

    def readTimeout(self, timeout: int, unit: TimeUnit) -> ClientBuilder:
        if timeout < 0:
            raise IllegalArgumentException("Negative timeout.")

        self.property(ClientProperties.READ_TIMEOUT, unit.toSeconds(timeout))
        return self

    def connectTimeout(self, timeout: int, unit: TimeUnit) -> ClientBuilder:
        if timeout < 0:
            raise IllegalArgumentException("Negative timeout.")

        self.property(ClientProperties.CONNECT_TIMEOUT, unit.toSeconds(timeout))
        return self

    def withConfig(self, config: Configuration) -> ClientBuilder:
        if config.getRuntimeType() != RuntimeType.CLIENT:
            raise IllegalArgumentException('Invalid runtime')
        self.merge(config)
        return self

    def build(self) -> Client:
        return PiggyClient(self)
