from typing import Final


class ClientProperties:
    IGNORE_EXCEPTION_RESPONSE = "piggy.restful.config.client.ignore.exception.response"
    READ_TIMEOUT: Final[str] = "piggy.restful.config.client.readTimeout"
    CONNECT_TIMEOUT: Final[str] = "piggy.restful.config.client.connectTimeout"
    HTTP_PROXY_SERVER: Final[str] = "piggy.restful.config.client.proxy.server.uri"
    HTTP_PROXY_SERVER_PORT: Final[str] = "piggy.restful.config.client.proxy.server.port"
    HTTP_AUTOREDIRECT: Final[str] = "piggy.restful.config.client.autoredirect"
    HTTP_MAINTAIN_SESSION: Final[str] = "piggy.restful.config.client.maintain.session"
    HTTP_RESPONSE_AUTOCLOSE: Final[str] = "piggy.restful.config.client.response.stream.auto.close"
    SUPPRESS_HTTP_COMPLIANCE_VALIDATION: Final[str] = "piggy.restful.config.client.request.compliance"

    QUERY_PARAM_STYLE: Final[str] = "piggy.restful.config.client.uri.query.param.style"
    CLIENT_NAME_BINDINGS: Final[str] = "piggy.restful.config.client.name.bindings"

    CONNECTOR_PROVIDER: Final[str] = "piggy.restful.config.client.connector.provider"

    # Some defaults
    DEFAULT_CONNECTOR_PROVIDER: Final[str] = "piggy.restful.config.client.default.connector.provider"


try:
    import urllib3
except ImportError:
    __urllib3__ = False
else:
    __urllib3__ = True


class ClientDefaultProperties:
    if __urllib3__:
        DEFAULT_CONNECTOR_PROVIDER: Final[
            str] = "piggy.restful.client.connector.urllib3.urllib3connector.Urllib3ConnectorProvider"
    else:
        DEFAULT_CONNECTOR_PROVIDER: Final[
            str] = "piggy.restful.client.connector.urllib.urllibconnector.UrllibConnectorProvider"
