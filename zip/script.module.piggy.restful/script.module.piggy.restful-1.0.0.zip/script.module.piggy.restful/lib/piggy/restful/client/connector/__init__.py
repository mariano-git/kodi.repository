from piggy.base import Overload, UnsupportedOperationException, Raisable
from piggy.base.util.concurrent.future import Future
from piggy.restful.client.clientrequest import ClientRequest
from piggy.restful.client.clientresponse import ClientResponse
from ws.rs.client.client import Client
from ws.rs.core.configuration import Configuration


class AsyncConnectorCallback:
    def failure(self, failure: Raisable):
        raise UnsupportedOperationException("Called on interface.")

    def response(self, response: ClientResponse):
        raise UnsupportedOperationException("Called on interface.")


class Connector:
    @Overload
    def apply(self, request: ClientRequest) -> ClientResponse:
        raise UnsupportedOperationException("Called on interface.")

    @Overload
    def apply(self, request: ClientRequest, callback: AsyncConnectorCallback) -> Future:
        raise UnsupportedOperationException("Called on interface.")

    def close(self):
        raise UnsupportedOperationException("Called on interface.")

    def getName(self) -> str:
        raise UnsupportedOperationException("Called on interface.")


class ConnectorProvider:

    def getConnector(self, client: Client, configuration: Configuration) -> Connector:
        raise UnsupportedOperationException("Called on interface.")
