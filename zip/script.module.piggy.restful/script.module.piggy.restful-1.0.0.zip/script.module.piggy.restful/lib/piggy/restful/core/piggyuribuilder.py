import inspect
from enum import Enum
from typing import List, Any, Type, Callable, Dict, Optional, Union
from urllib.parse import parse_qs, quote

from piggy.base import UnsupportedOperationException, Overload, IllegalArgumentException
from piggy.base.net.uri import URI
from piggy.base.notation import AnnotatedFunctionElement
from piggy.base.stringbuilder import StringBuilder
from piggy.base.util import Objects
from piggy.base.util.map import Map
from piggy.restful.utils.annotationutils import AnnotationUtils
from ws.rs.applicationpath import ApplicationPath
from ws.rs.core.multivaluedmap import MultivaluedMap
from ws.rs.core.multivaluesimplemap import MultivaluedSimpleMap
from ws.rs.core.uribuilder import UriBuilder
from ws.rs.path import Path


class QueryParamStyle(Enum):
    MULTI_PAIRS = 0
    COMMA_SEPARATED = 1
    ARRAY_PAIRS = 3


class UriComponent(Enum):
    SCHEME = 0
    SSP = 1
    AUTHORITY = 2
    USER_INFO = 3
    HOST = 4
    PORT = 5
    SEGMENT = 6
    MATRIX = 7
    QUERY = 8
    FRAGMENT = 9


class Holder:
    def __init__(self, value: Any):
        self.value = value

    def __eq__(self, other):
        return isinstance(other, Holder) and self.value == other.value

    def __hash__(self):
        return hash(self.value)

    def isEmpty(self) -> bool:
        val = self.getValue()
        if val:
            return len(val.strip()) == 0
        return True

    def isTemplate(self):
        strValue = self.getValue()

        opent = strValue.find('{')
        closet = strValue.find('}')
        return opent != -1 and closet != -1 and opent < closet

    def getValue(self) -> str:
        if self.value is None:
            return None
        if not isinstance(self.value, str):
            return self.value.toString() if hasattr(self.value, 'toString') else str(self.value)
        else:
            return self.value

    def getEscaped(self) -> str:
        if not self.isEmpty():
            return quote(self.getValue())
        return None


class PiggyUriBuilder(UriBuilder):
    def __init__(self):
        self._queryParamStyle_: QueryParamStyle = QueryParamStyle.MULTI_PAIRS
        self.components: Dict[UriComponent, Optional[Union[Holder, MultivaluedMap[Holder, Holder], List[Holder]]]] = {
            UriComponent.SCHEME: None,
            UriComponent.SSP: None,
            UriComponent.AUTHORITY: None,
            UriComponent.USER_INFO: None,
            UriComponent.HOST: None,
            UriComponent.PORT: None,
            UriComponent.SEGMENT: None,
            UriComponent.MATRIX: None,
            UriComponent.QUERY: MultivaluedSimpleMap(),
            UriComponent.FRAGMENT: None
        }

    def setQueryParamStyle(self, style: QueryParamStyle):
        self._queryParamStyle_ = style

    def scheme(self, scheme: str) -> UriBuilder:
        """
        Set the URI scheme.
        :param scheme: the URI scheme, may contain URI template parameters. A null value will unset the URI scheme,
        but will not unset the any scheme-specific-part components.
        :return: the updated UriBuilder.
        :raises: IllegalArgumentException - if scheme is invalid.
        """
        if scheme and len(scheme.strip()) == 0:
            raise IllegalArgumentException('invalid scheme')
        if scheme is None:
            self.components[UriComponent.SCHEME] = None
            return self
        self.components[UriComponent.SCHEME] = Holder(scheme)
        return self

    def userInfo(self, ui: str) -> UriBuilder:
        raise UnsupportedOperationException("Not supported yet.")

    def host(self, host: str) -> UriBuilder:
        """
        Set the URI host.
        :param host: the URI host, may contain URI template parameters.
        A null value will unset the host component of the URI, but will not unset other authority component
        parts (user info or port).
        :return: the updated UriBuilder.
        :raises: IllegalArgumentException - if host is invalid.
        """
        if host and len(host.strip()) == 0:
            raise IllegalArgumentException('invalid host')
        if host is None:
            self.components[UriComponent.HOST] = None
            return self
        self.components[UriComponent.HOST] = Holder(host)
        return self

    def port(self, port: int) -> UriBuilder:
        """
        Set the URI port.
        :param port: the URI port, a value of -1 will unset an explicit port.
        :return: the updated UriBuilder.
        :raises: IllegalArgumentException - if port is invalid.
        """
        if port:
            try:
                port = int(port)
            except ValueError as ve:
                raise IllegalArgumentException(f'invalid host: {ve}')
        if port == -1:
            self.components[UriComponent.PORT] = None
        else:
            self.components[UriComponent.PORT] = Holder(port)
        return self

    def schemeSpecificPart(self, ssp: str) -> UriBuilder:
        '''
        Set the URI scheme-specific-part (see {@link java.net.URI}). This method will overwrite any existing values for
        authority, user-info, host, port and path.

        :param ssp: the URI scheme-specific-part, may contain URI template parameters.
        :return:  the updated UriBuilder.
        :raises: IllegalArgumentException if ssp cannot be parsed or is {@code null}.
        '''
        Objects.requireNonEmptyElseRaise(ssp, IllegalArgumentException, 'invalid Scheme Specific Part')
        schemeComponent = self.components.get(UriComponent.SCHEME)
        if schemeComponent and not schemeComponent.isEmpty():
            ssp = f'{schemeComponent.getValue()}:{ssp}'
        uri: URI = URI.create(ssp)
        if uri.isOpaque():
            if uri.getSchemeSpecificPart() is not None:
                self.components[UriComponent.AUTHORITY] = None
                self.components[UriComponent.SEGMENT] = None
                self.components[UriComponent.PORT] = None
                self.components[UriComponent.QUERY] = MultivaluedSimpleMap()
                self.components[UriComponent.SSP] = Holder(uri.getSchemeSpecificPart())
            return self
        authority = uri.getAuthority()
        if authority is not None:
            userInfo = uri.getUserInfo()
            host = uri.getHost()
            port = uri.getPort()
            if userInfo is None and host is None and port is None or port == -1:
                self.components[UriComponent.AUTHORITY] = Holder(authority)
                self.components[UriComponent.USER_INFO] = None
                self.components[UriComponent.HOST] = None
                self.components[UriComponent.PORT] = None
            else:
                self.components[UriComponent.AUTHORITY] = None
                if not Objects.isEmpty(userInfo):
                    self.components[UriComponent.USER_INFO] = Holder(userInfo)
                if not Objects.isEmpty(host):
                    self.components[UriComponent.HOST] = Holder(host)
                if not Objects.isEmpty(port) or port != -1:
                    self.components[UriComponent.PORT] = Holder(port)
        path = uri.getPath()
        query = uri.getQuery()
        if not Objects.isEmpty(path):
            self.replacePath(path)
        if not Objects.isEmpty(query):
            self.replaceQuery(query)
        return self

    def _toString(self, encode: bool) -> str:

        scheme: Optional[Holder] = self.components[UriComponent.SCHEME]
        ssp: Optional[Holder] = self.components[UriComponent.SSP]
        authority: Optional[Holder] = self.components[UriComponent.AUTHORITY]
        userInfo: Optional[Holder] = self.components[UriComponent.USER_INFO]
        host: Optional[Holder] = self.components[UriComponent.HOST]
        port: Optional[Holder] = self.components[UriComponent.PORT]
        segments: Optional[List[Holder]] = self.components[UriComponent.SEGMENT]
        matrix = self.components[UriComponent.MATRIX]
        query: MultivaluedMap[Holder, Holder] = self.components[UriComponent.QUERY]
        fragment: Optional[Holder] = self.components[UriComponent.FRAGMENT]
        sb = StringBuilder()

        hasAuthority = False
        if scheme:
            sb.append(scheme.getValue()).append(':')
        if ssp:
            sb.append(ssp.getValue())
        else:

            if userInfo or host or port:
                hasAuthority = True
                sb.append("//")

                if userInfo and not userInfo.isEmpty():
                    sb.append(userInfo.getValue()).append('@')

                if host:
                    # TODO check IPv6 address
                    sb.append(host.getValue())

                if port:
                    sb.append(':').append(port.getValue())

            elif authority:
                hasAuthority = True
                sb.append("//").append(authority.getValue())

        if segments and len(segments) > 0:
            path = '/'.join(map(lambda s: s.getValue(), segments))
            if path[0] != '/':
                sb.append('/')
            if path[:-1] == '/':
                sb.append(path[:-1])
            else:
                sb.append(path)

        elif hasAuthority and not query.isEmpty() or fragment and not fragment.isEmpty():
            # if has authority and query or fragment and no path value, we need to append root '/' to the path
            # see URI RFC 3986 section 3.3
            sb.append("/")

        if not query.isEmpty():
            sb.append('?').append(self._buildQuery(encode))
        if fragment and not fragment.isEmpty():
            sb.append('#').append(fragment.getValue())

        return sb.toString()

    def toTemplate(self) -> str:
        """
        Get the URI template string represented by this URI builder.

        :return: the URI template string for this URI builder.
        :since: 2.0
        """
        return self._toString(False)

    @Overload
    def build(self) -> URI:
        # TODO: Check url escaping
        return URI.create(self._toString(True))

    @Overload
    def build(self, values: List[object], encodeSlashInPath: bool) -> URI:
        raise UnsupportedOperationException("Not supported yet.")

    @Overload
    def build(self, *values: object) -> URI:
        raise UnsupportedOperationException("Not supported yet.")

    def buildFromEncoded(self, *values: object) -> URI:
        raise UnsupportedOperationException("Not supported yet.")

    def buildFromEncodedMap(self, values: Map[str, Any]) -> URI:
        raise UnsupportedOperationException("Not supported yet.")

    @Overload
    def buildFromMap(self, values: Map[str, Any], encodeSlashInPath: bool) -> URI:
        raise UnsupportedOperationException("Not supported yet.")

    @Overload
    def buildFromMap(self, values: Map[str, Any]) -> URI:
        raise UnsupportedOperationException("Not supported yet.")

    def clone(self) -> UriBuilder:
        other = PiggyUriBuilder()

        def clone(v):
            if v is None:
                return None
            if isinstance(v, list):
                return list(v)
            return v

        for k, v in self.components.items():
            if k != UriComponent.QUERY:
                other.components[k] = clone(v)
        query = self.components[UriComponent.QUERY]
        if not query.isEmpty():
            other.components[UriComponent.QUERY] = MultivaluedSimpleMap(query)

        other._queryParamStyle_ = self._queryParamStyle_
        return other

    def fragment(self, fragment: str) -> UriBuilder:
        """
        Set the URI fragment.

        :param fragment: the URI fragment, may contain URI template parameters. A null value will remove any existing fragment.
        :return: the updated UriBuilder.
        """
        if fragment is None:
            self.components[UriComponent.FRAGMENT] = None
            return self
        self.components[UriComponent.FRAGMENT] = Holder(fragment)
        return self

    def path(self, e: Union[str, Type, Callable], method: Optional[str] = None) -> UriBuilder:
        Objects.requireNonEmptyElseRaise(e, IllegalArgumentException, 'resource is Null or blank')
        path = None
        if method is not None:
            if e is None:
                raise IllegalArgumentException('method without resource')
            elif isinstance(e, type):
                member = inspect.getmembers(
                    e, lambda v: isinstance(v, AnnotatedFunctionElement) and v.__func__.__name__ == method
                )
                if member and len(member) == 1:
                    e = member[1]
                else:
                    raise IllegalArgumentException('could not determine resource method')
        if isinstance(e, str):
            path = e
        elif isinstance(e, AnnotatedFunctionElement):
            path = AnnotationUtils.getAnnotationValue(e, Path, None)
        elif isinstance(e, type) and hasattr(e, 'isAnnotationPresent'):
            if e.isAnnotationPresent(ApplicationPath):
                path = AnnotationUtils.getAnnotationValue(e, ApplicationPath, None)
            elif e.isAnnotationPresent(Path):
                path = AnnotationUtils.getAnnotationValue(e, Path, None)
        else:
            raise IllegalArgumentException('could not find annotation')
        if not Objects.isEmpty(path):
            segments = list(filter(lambda p: not Objects.isEmpty(p), path.split('/')))
            if len(segments) == 0:
                # allowed because path is '/'
                return self
            return self.segment(*segments)
        return self

    def replacePath(self, path: str) -> UriBuilder:
        raise UnsupportedOperationException("Not supported yet.")

    def segment(self, *segments: str) -> UriBuilder:
        """
        Append path segments to the existing path.
        When constructing the final path, a '/' separator will be inserted between the existing path and the first
        path segment if necessary and each supplied segment will also be separated by '/'.
        Existing '/' characters are encoded thus a single value can only represent a single URI path segment.

        :param segments: the path segment values, each may contain URI template parameters.
        :return: the updated UriBuilder.
        :raises: IllegalArgumentException - if segments or any element of segments is null.
        """
        Objects.requireNonEmptyElseRaise(segments, IllegalArgumentException, 'segments is Null or blank')
        newHolders: List[Holder] = list()
        for segment in segments:
            Objects.requireNonEmptyElseRaise(segment, IllegalArgumentException, 'segment is Null or blank')
            newHolders.append(Holder(segment))

        if self.components[UriComponent.SEGMENT]:
            self.components[UriComponent.SEGMENT].extend(newHolders)
        else:
            self.components[UriComponent.SEGMENT] = newHolders

        return self

    def matrixParam(self, name: str, *values: object) -> UriBuilder:
        raise UnsupportedOperationException("Not supported yet.")

    def replaceMatrix(self, matrix: str) -> UriBuilder:
        raise UnsupportedOperationException("Not supported yet.")

    def replaceMatrixParam(self, name: str, *values: object) -> UriBuilder:
        raise UnsupportedOperationException("Not supported yet.")

    def replaceQuery(self, query: str) -> UriBuilder:
        """
        Set the URI query string. This method will overwrite any existing query parameters.
        :param query: the URI query string, may contain URI template parameters. A null value will remove all query parameters.
        :return: the updated UriBuilder.
        :raises: IllegalArgumentException - if query cannot be parsed.
        """
        if query is None:
            self.components[UriComponent.QUERY].clear()
            return self
        qs = parse_qs(query)
        if len(qs) > 0:
            for k, v in qs.items():
                self.replaceQueryParam(k, *tuple(v))
        else:
            raise IllegalArgumentException('Unable to parse query')
        return self

    def replaceQueryParam(self, name: str, *values: object) -> UriBuilder:
        """
        Replace the existing value(s) of a query parameter.
        If multiple values are supplied the parameter will be added once per value.
        :param name: the query parameter name, may contain URI template parameters.
        :param values: the query parameter value(s), each object will be converted to a String using its toString() method.
        Stringified values may contain URI template parameters. If values is empty or null then all current values of
        the parameter are removed.
        :return: the updated UriBuilder.
        :raises: IllegalArgumentException - if name is null.
        """
        Objects.requireNonEmptyElseRaise(name, IllegalArgumentException('name is Null or blank'))
        key = Holder(name)
        map: MultivaluedMap[Holder, Holder] = self.components[UriComponent.QUERY]
        map.remove(key)
        if values:
            for value in values:
                map.add(key, Holder(value))
        return self

    def queryParam(self, name: str, *values: object) -> UriBuilder:
        """
        Append a query parameter to the existing set of query parameters.
        If multiple values are supplied the parameter will be added once per value.

        :param name: the query parameter name, may contain URI template parameters.
        :param values: the query parameter value(s), each object will be converted to a String using its toString() method.
        Stringified values may contain URI template parameters.

        :return: the updated UriBuilder.
        :raises: IllegalArgumentException - if name or values is null.
        """
        Objects.requireNonEmptyElseRaise(name, IllegalArgumentException('name is Null or blank'))
        Objects.requireNonEmptyElseRaise(values, IllegalArgumentException('values is Null or blank'))
        key = Holder(name)
        map: MultivaluedMap[Holder, Holder] = self.components[UriComponent.QUERY]
        if values:
            for value in values:
                map.add(key, Holder(value))
        return self

    @Overload
    def resolveTemplate(self, _string: str, _object: object) -> UriBuilder:
        raise UnsupportedOperationException("Not supported yet.")

    @Overload
    def resolveTemplate(self, name: str, value: object, encodeSlashInPath: bool) -> UriBuilder:
        raise UnsupportedOperationException("Not supported yet.")

    @Overload
    def resolveTemplates(self, templateValues: Map[str, object]) -> UriBuilder:
        raise UnsupportedOperationException("Not supported yet.")

    @Overload
    def resolveTemplates(self, templateValues: Map[str, object], encodeSlashInPath: bool) -> UriBuilder:
        raise UnsupportedOperationException("Not supported yet.")

    def resolveTemplateFromEncoded(self, name: str, value: object) -> UriBuilder:
        raise UnsupportedOperationException("Not supported yet.")

    def resolveTemplatesFromEncoded(self, templateValues: Map[str, object]) -> UriBuilder:
        raise UnsupportedOperationException("Not supported yet.")

    @Overload
    def uri(self, uri: URI) -> UriBuilder:
        """
        Copies the non-null components of the supplied URI to the UriBuilder replacing any existing values for those components.
        :param uri: the URI to copy components from.
        :return: the updated UriBuilder.
        :raises: IllegalArgumentException - if the client parameter is null.
        """
        Objects.requireNonNull(uri, IllegalArgumentException('client is Null'))
        self._update(uri)
        return self

    @Overload
    def uri(self, uriTemplate: str) -> UriBuilder:
        """
        Parses the uriTemplate string and copies the parsed components of the supplied URI to the UriBuilder replacing any existing values for those components.
        :param uriTemplate: a URI template that will be used to initialize the UriBuilder, may contain URI parameters.
        :return: the updated UriBuilder.
        :raises IllegalArgumentException - if uriTemplate is not a valid URI template or is null.
        """
        Objects.requireNonNullElseRaise(uriTemplate, IllegalArgumentException, 'uriTemplate is Null')
        try:
            self._update(URI.create(uriTemplate))
            return self
        except Exception as e:
            raise IllegalArgumentException(e)

    def _qsMultiPair(self, qs: List[str], key: Holder, values: List[Holder], encode):
        # foo=v1&amp;foot=v2&amp;foo=v3
        if encode:
            values = list(map(lambda v: v.getEscaped(), values))
            j = f'&{key.getEscaped()}='
        else:
            values = list(map(lambda v: v.getValue(), values))
            j = f'&{key.getValue()}='
        joined = j.join(values)
        qs.append(f'{j[1:]}{joined}')

    def _qsCSV(self, qs: List[str], key: Holder, values: List[object], encode: bool):
        # key=value1,value2,value3.
        j = ','
        if encode:
            vals = list(map(lambda v: v.getEscaped(), values))
            k = key.getEscaped()
        else:
            vals = list(map(lambda v: v.getValue(), values))
            k = key.getValue()

        joined = j.join(vals)
        qs.append(f'{k}={joined}')

    def _qsArrayPair(self, qs: List[str], key: Holder, values: List[object], encode: bool):
        # key[] = value1 & key[] = value2 & key[] = value3
        if encode:
            vals = list(map(lambda v: v.getEscaped(), values))
            j = f'&{key.getEscaped()}[]='
        else:
            vals = list(map(lambda v: v.getValue(), values))
            j = f'&{key.getValue()}[]='
        joined = j.join(vals)
        qs.append(f'{j[1:]}{joined}')

    def _buildQuery(self, encode: bool) -> str:

        qs: List[str] = list()
        for entry in self.components[UriComponent.QUERY].entrySet():
            values = entry.getValue()
            if values is None:
                # special case when query keypair is a template
                qs.append(entry.getKey())
                continue
            elif len(values) > 1:
                if self._queryParamStyle_ == QueryParamStyle.MULTI_PAIRS:
                    self._qsMultiPair(qs, entry.getKey(), entry.getValue(), encode)
                elif self._queryParamStyle_ == QueryParamStyle.COMMA_SEPARATED:
                    self._qsCSV(qs, entry.getKey(), entry.getValue(), encode)
                elif self._queryParamStyle_ == QueryParamStyle.ARRAY_PAIRS:
                    self._qsArrayPair(qs, entry.getKey(), entry.getValue(), encode)
            else:
                v = entry.getValue()[0]
                k = entry.getKey().getEscaped() if encode else entry.getKey().getValue()
                qs.append(f'{k}={v.getEscaped() if encode else v.getValue()}')

        return '&'.join(qs)

    def _update(self, uri: URI):

        if uri.getRawFragment():
            self.fragment(uri.getRawFragment())

        if uri.isOpaque():
            self.scheme(uri.getScheme())
            self.schemeSpecificPart(uri.getRawSchemeSpecificPart())
            return self

        if uri.getScheme() is None:
            if self._ssp_:
                if uri.getRawSchemeSpecificPart():
                    self.schemeSpecificPart(uri.getRawSchemeSpecificPart())
                    return self
        else:
            self.scheme(uri.getScheme())

        self._ssp_ = None
        if uri.getRawAuthority():
            if uri.getRawUserInfo() is None and uri.getHost() is None and uri.getPort() == -1:
                self._authority_ = uri.getRawAuthority()
                self._userInfo_ = None
                self._host_ = None
                self._port_ = None
            else:
                self._authority_ = None
                if uri.getRawUserInfo():
                    self.userInfo(uri.getRawUserInfo())

                if uri.getHost():
                    self.host(uri.getHost())

                if uri.getPort() != -1:
                    self.port(uri.getPort())

        if not Objects.isEmpty(uri.getRawPath()):
            segments = uri.getRawPath().split('/')
            # check first and last we don't need them
            start = 0
            if Objects.isEmpty(segments[0]):
                start = 1
            if Objects.isEmpty(segments[-1]):
                segments.pop()
            self.segment(*tuple(segments[start:]))

        if not Objects.isEmpty(uri.getRawQuery()):
            self.replaceQuery(uri.getRawQuery())
