from typing import Type, Optional

from piggy.base import Overload
from piggy.base.util.map import Map
from piggy.restful.core.componentconfiguration import ComponentConfiguration
from piggy.restful.utils.annotationutils import AnnotationUtils
from piggy.restful.utils.contracts import Contracts
from ws.inject import Priority
from ws.rs.core.configurable import Configurable, C
from ws.rs.core.configuration import Configuration
from ws.rs.core.featurecontext import FeatureContext
from ws.rs.priorities import Priorities
from ws.rs.runtimetype import RuntimeType


class ConfigurableComponent(Configurable[C]):
    def __init__(self, runtimeType: Optional[RuntimeType] = None, configuration: Optional[Configuration] = None):
        self.configuration: ComponentConfiguration = ComponentConfiguration(runtimeType, configuration)

    def merge(self, configuration: Configuration):
        self.configuration.merge(configuration)

    def getConfiguration(self) -> Configuration:
        return self.configuration

    def property(self, name: str, value: object) -> C:
        self.configuration.props.put(name, value)
        return self

    @Overload
    def register(self, provider: object) -> C:
        self.configuration.doRegister(
            provider,
            Contracts.createContractsMap(
                AnnotationUtils.getAnnotationValue(
                    provider, Priority, Priorities.USER
                ), *Contracts.getProviderContracts(
                    provider, self.getConfiguration().getRuntimeType()
                )
            )
        )
        return self

    @Overload
    def register(self, provider: object, priority: int) -> C:
        self.configuration.doRegister(
            provider, Contracts.createContractsMap(
                priority,
                *Contracts.getProviderContracts(
                    provider, self.getConfiguration().getRuntimeType()
                )
            )
        )
        return self

    @Overload
    def register(self, provider: object, *contracts: Type) -> C:
        self.configuration.doRegister(
            provider, Contracts.createContractsMap(
                AnnotationUtils.getAnnotationValue(
                    provider, Priority, Priorities.USER
                ), *contracts
            )
        )
        return self

    @Overload
    def register(self, provider: object, contracts: Map[Type, int]) -> C:
        self.configuration.doRegister(provider, contracts, self)
        return self

    @Overload
    def register(self, provider: Type) -> C:
        self.configuration.doRegister(
            provider,
            Contracts.createContractsMap(
                AnnotationUtils.getAnnotationValue(
                    provider, Priority, Priorities.USER
                ), *Contracts.getProviderContracts(
                    provider, self.getConfiguration().getRuntimeType()
                )
            )
        )
        return self

    @Overload
    def register(self, provider: Type, priority: int) -> C:
        self.configuration.doRegister(
            provider, Contracts.createContractsMap(
                priority,
                *Contracts.getProviderContracts(
                    provider, self.getConfiguration().getRuntimeType()
                )
            )
        )
        return self

    @Overload
    def register(self, provider: Type, *contracts: Type) -> C:
        self.configuration.doRegister(
            provider, Contracts.createContractsMap(
                AnnotationUtils.getAnnotationValue(
                    provider, Priority, Priorities.USER
                ), *contracts
            )
        )
        return self

    @Overload
    def register(self, provider: Type, contracts: Map[Type, int]) -> C:
        self.configuration.doRegister(provider, contracts, self)
        return self


class ConfigurableFeatureContext(FeatureContext, ConfigurableComponent[FeatureContext]):
    def __init__(self, configuration: Configuration):
        super().__init__(None, configuration)
