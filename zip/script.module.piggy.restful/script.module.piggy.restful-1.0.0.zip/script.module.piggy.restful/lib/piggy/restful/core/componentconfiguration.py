import inspect
from typing import Set, Type, Collection, Optional, Union, cast, Dict

from piggy.base import Overload, UnsupportedOperationException, IllegalStateException
from piggy.base.util.collections import Collections
from piggy.base.util.logging import Logger
from piggy.base.util.map import Map
from piggy.base.util.simplemap import SimpleMap
from ws.inject import Priority
from ws.rs.core.configuration import Configuration
from ws.rs.core.feature import Feature
from ws.rs.priorities import Priorities
from ws.rs.runtimetype import RuntimeType

from piggy.restful.ext.clientruntime import ClientRuntime
from piggy.restful.ext.runtime import Runtime
from piggy.restful.ext.serverruntime import ServerRuntime
from piggy.restful.utils.annotationutils import AnnotationUtils
from piggy.restful.utils.contracts import Contracts


class ComponentConfiguration(Configuration):
    __lg__ = Logger.getLogger(f'{__name__}.{__qualname__}')

    def __init__(self, runtimeType: Optional[RuntimeType] = None, configuration: Optional[Configuration] = None):
        self.runtimeType: RuntimeType = None
        self.runtime: Runtime = None
        self.props: Map[str, object] = SimpleMap[str, object]()
        self.features: Dict[Feature, bool] = dict()
        self.providers: Dict[object, Map[Type, int]] = dict()
        if runtimeType and not configuration:
            self.runtimeType = runtimeType
            self.initRuntime()
        elif configuration and not runtimeType:
            self.runtimeType = configuration.getRuntimeType()

        if configuration:
            self.merge(configuration)

    def merge(self, parent: Configuration):
        self.__lg__.debug("Merging configuration: %s", parent)
        if isinstance(parent, ComponentConfiguration):
            self.runtime = parent.runtime

        self.runtimeType = parent.getRuntimeType()
        self.props.putAll(parent.getProperties())

        providers = set(parent.getClasses())
        for o in parent.getInstances():
            if isinstance(o, Feature):
                f: Feature = cast(Feature, o)
                self.features[f] = parent.isEnabled(f)
            else:
                self.registerParentProvider(o, parent)
            providers.remove(o.__class__)

        for cls in providers:
            # eventually all remaining providers shouldn't be instantiated because it could be scoped.
            # but try again...
            self.registerParentProvider(cls, parent)

    def registerParentProvider(self, provider: Union[object, Type], parent: Configuration):
        self.__lg__.debug("Registering parent provider: %s from config: %s", provider, parent)
        if inspect.isclass(provider):
            providerCls = provider
        else:
            providerCls = provider.__class__

        contracts: Map[Type, int] = parent.getContracts(providerCls)
        if contracts.isEmpty():
            contracts = Contracts.createContractsMap(
                AnnotationUtils.getAnnotationValue(
                    provider, Priority, Priorities.USER
                ), *Contracts.getProviderContracts(
                    provider, self.runtimeType
                )
            )

        self.doRegister(provider, contracts)

    def doRegister(self, provider: Union[object, Type], contracts: Map[Type, int]) -> bool:
        self.__lg__.debug("Registering provider: %s with contracts: %s", provider, contracts.toString())
        if not Contracts.isValidConstraint(provider, self.runtimeType):
            return False

        if self.isRegistered(provider):
            Contracts.message('Provider class: "%s" has already been registered', provider)
            return False

        if inspect.isclass(provider):
            provider = self.createProvider(cast(Type, provider))

        isFeature = isinstance(provider, Feature)
        if not isFeature and not Contracts.isValidForContracts(provider, contracts.keySet()):
            return False

        if isFeature:
            from piggy.restful.core.configurablecomponent import ConfigurableFeatureContext
            feature: Feature = cast(Feature, provider)
            enabled = feature.configure(ConfigurableFeatureContext(self))
            self.features[feature] = enabled
            if not enabled:
                Contracts.message('Unable to activate Feature: "%s"', provider)
                return False
            return True

        metadata: Optional[Map[Type, int]] = self.providers.get(provider)
        if metadata is None:
            metadata = SimpleMap()
            self.providers[provider] = metadata
        for entry in contracts.entrySet():
            self.runtime.getBinder().addProvider(provider, entry.getKey(), entry.getValue())
            if issubclass(entry.getKey(), provider.__class__):
                metadata.put(entry.getKey(), entry.getValue())

        return True

    def createProvider(self, component: Type) -> object:
        # TODO: eventually not all providers should be instantiated because it could be scoped. See:@Scope vs @Singleton
        self.__lg__.debug("\n"
                          "**************************************************************\n"
                          f"               WARNING: CHECK Scope {component}\n"
                          "**************************************************************")

        return component()

    def initRuntime(self):
        self.__lg__.debug("initRuntime currentRuntime: %s", self.runtime)
        if self.runtime:
            self.runtime.update(self)
        else:
            if self.getRuntimeType() == RuntimeType.CLIENT:
                self.__lg__.debug("initRuntime creating new ClientRuntime")
                self.runtime = ClientRuntime(self)
            elif self.getRuntimeType() == RuntimeType.SERVER:
                self.__lg__.debug("initRuntime creating new ServerRuntime")
                self.runtime = ServerRuntime(self)
            else:
                raise IllegalStateException('Unable to create a suitable runtime.')

    def getRuntime(self) -> Runtime:
        return self.runtime

    # Configuration --------------------------------------------------------------------
    def getRuntimeType(self) -> RuntimeType:
        return self.runtimeType

    def getProperties(self) -> Map[str, object]:
        return Collections.unmodifiableMap(self.props)

    def getPropertyNames(self) -> Collection[str]:
        return Collections.unmodifiableSet(self.props.keySet())

    def getProperty(self, name: str) -> object:
        return self.props.get(name)

    @Overload
    def isEnabled(self, feature: 'Feature') -> bool:
        raise UnsupportedOperationException("Not supported yet.")

    @Overload
    def isEnabled(self, featureType: Type['Feature']) -> bool:
        raise UnsupportedOperationException("Not supported yet.")

    def getClasses(self) -> Set[Type]:
        classes = set()
        for o in self.getInstances():
            classes.add(o.__class__)
        return Collections.unmodifiableSet(classes)

    @Overload
    def isRegistered(self, provider: object) -> bool:
        current = self.providers.get(provider)
        self.__lg__.debug("Requesting if provider is registered: %s, current: %s", provider, current)
        return current is not None

    @Overload
    def isRegistered(self, provider: Type) -> bool:
        for o in self.getInstances():
            if o.__class__ == provider:
                return True
        return False

    def getContracts(self, providerType: Type) -> Map[type, int]:
        self.__lg__.debug("Requesting contracts for provider: %s", providerType)
        for key, value in self.providers.items():
            if key == providerType:
                return Collections.unmodifiableMap(value)

        return Collections.emptyMap()

    def getInstances(self) -> Set[object]:
        return Collections.unmodifiableSet(set(self.providers.keys()))
