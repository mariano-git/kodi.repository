class JsonFilteringFeature:
    pass