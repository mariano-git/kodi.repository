class FilteringJsonProvider:
    pass