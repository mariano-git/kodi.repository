from typing import Type, List, Set

from piggy.base.io.inputstream import InputStream
from piggy.base.io.outputstream import OutputStream
from piggy.base.notation import Annotation
from piggy.mapper.jsonmapper import JsonMapper
from piggy.restful.ext.spi.json.provider.jsonprovider import JsonProvider
from ws.rs.core.mediatype import MediaType
from ws.rs.core.multivaluedmap import MultivaluedMap
from ws.rs.core.response import Response
from ws.rs.ext.messagebodyreader import MessageBodyReader, T
from ws.rs.ext.messagebodywriter import MessageBodyWriter


class DefaultJsonProvider(JsonProvider, MessageBodyWriter, MessageBodyReader):
    BANNED: Set[Type] = {InputStream, OutputStream, Response}

    def __init__(self):
        self.mapper = JsonMapper()

    def writeTo(self, t: T, cls: Type, genericType: Type, annotations: List[Annotation], mediaType: MediaType,
                httpHeaders: MultivaluedMap[str, object], entityStream: OutputStream):

        # TODO: Mariano: Add more stuff here to configure. See how it goes with a plain execution

        self.mapper.writeValue(entityStream, t)

    def readFrom(self, cls: Type, genericType: Type, annotations: List[Annotation], mediaType: MediaType,
                 httpHeaders: MultivaluedMap[str, str], entityStream: InputStream) -> T:
        # TODO: Mariano: Add more stuff here to configure. See how it goes with a plain execution
        return self.mapper.readValue(entityStream, genericType if genericType is not None else cls)

    def isReadable(self, cls: Type, genericType: Type, annotations: List[Annotation], mediaType: MediaType) -> bool:
        if not self.isManageable(mediaType):
            return False
        if self.isBanned(cls):
            return False

        return True

    def isWriteable(self, cls: Type, genericType: Type, annotations: List[Annotation], mediaType: MediaType) -> bool:

        if not self.isManageable(mediaType):
            return False
        if self.isBanned(cls):
            return False

        return True

    def isManageable(self, mediaType: MediaType):
        subTypes = ['json', '+json', 'javascript', 'x-javascript', 'x-json']
        if mediaType is not None:
            subType = mediaType.getSubtype()
            return subType is not None and subType.lower() in subTypes

        return True

    def isBanned(self, cls):
        # FIXME make it configurable, eventually annotable
        return cls in DefaultJsonProvider.BANNED
