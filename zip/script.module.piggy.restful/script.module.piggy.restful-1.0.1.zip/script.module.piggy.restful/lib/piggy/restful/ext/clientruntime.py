from piggy.base import Raisable, Class, ClassNotFoundException
from piggy.base.util import Objects
from piggy.base.util.conditional import Conditional
from piggy.base.util.logging import Logger
from piggy.restful.client.abortexception import AbortException
from piggy.restful.client.clientproperties import ClientProperties, ClientDefaultProperties
from piggy.restful.client.clientrequest import ClientRequest
from piggy.restful.client.clientresponse import ClientResponse
from piggy.restful.client.clientresponseprocessingexception import ClientResponseProcessingException
from piggy.restful.client.connector import Connector, ConnectorProvider
from piggy.restful.ext.runtime import Runtime
from piggy.restful.internal.client.requestfilterphase import RequestFilterPhase
from piggy.restful.internal.message.messagebodyworkers import MessageBodyWorkers
from piggy.restful.internal.version import Version
from ws.rs.core.configuration import Configuration
from ws.rs.core.httpheaders import HttpHeaders
from ws.rs.core.multivaluedmap import MultivaluedMap
from ws.rs.ext.readerinterceptor import ReaderInterceptor
from ws.rs.ext.writerinterceptor import WriterInterceptor
from ws.rs.processingexception import ProcessingException


class ClientRuntime(Runtime):
    __lg__ = Logger.getLogger(f'{__name__}.{__qualname__}')
    __slots__ = '__connector__', '__config__', '__requestScope__', '__open__'

    def __init__(self, configuration: Configuration):
        super().__init__(configuration)
        self.__connector__: Connector = None
        self.__open__ = False
        self.__requestScope__ = None
        self._checkConnector()

    def setConnector(self, provider: str) -> ConnectorProvider:
        self.__lg__.debug("Setting connector provider: %s", provider)
        try:
            providerCls = Class.forName(provider)
            provider = providerCls()
            self.__connector__ = provider.getConnector(None, self.getConfiguration())
            self.__open__ = True
            self.__lg__.debug("Connector is: %s, isOpen: %s", self.__connector__, self.__open__)
        except ClassNotFoundException as c:
            # big problem....
            print(' big problem here...')

    def _checkConnector(self):
        self.__lg__.debug("Checking connector, current: %s", self.__connector__)
        if self.__connector__ is None:
            conf = self.getConfiguration()

            self.__lg__.debug("Connector is None,ClientProperties.CONNECTOR_PROVIDER: %s",
                              conf.getProperty(ClientProperties.CONNECTOR_PROVIDER))
            self.__lg__.debug("Connector is None,ClientProperties.DEFAULT_CONNECTOR_PROVIDER: %s",
                              ClientDefaultProperties.DEFAULT_CONNECTOR_PROVIDER)

            Conditional.ofNullable(
                conf.getProperty(ClientProperties.CONNECTOR_PROVIDER)
            ).orConditional(
                lambda: ClientDefaultProperties.DEFAULT_CONNECTOR_PROVIDER
            ).ifPresent(self.setConnector)

    def isOpen(self) -> bool:
        return self.__open__

    def close(self):
        self.__open__ = False
        self.__connector__.close()

    def getRequestScope(self) -> 'RequestScope':
        """
        Get the request scope instance configured for the runtime.
        :return: request scope instance.
        """
        # return RequestScope()  # self.__requestScope__
        pass

    def addUserAgent(self, clientRequest: ClientRequest, connectorName: str) -> ClientRequest:
        headers: MultivaluedMap[str, object] = clientRequest.getHeaders()

        if headers.containsKey(HttpHeaders.USER_AGENT):
            # Check for explicitly set null value and if set, then remove the header - see JERSEY-2189
            if clientRequest.getHeaderString(HttpHeaders.USER_AGENT) is None:
                headers.remove(HttpHeaders.USER_AGENT)
        elif not clientRequest.ignoreUserAgent():
            if Objects.isEmpty(connectorName):
                headers.put(
                    HttpHeaders.USER_AGENT,
                    ["PiggyWS/%s" % (Version.getVersion())]
                )
            else:
                headers.put(
                    HttpHeaders.USER_AGENT,
                    ["PiggyWS/%s (%s)" % (Version.getVersion(), connectorName)]
                )
        return clientRequest

    '''
    FIXME This code should change to allow injections and extend async processing

    Client Request Filters
    Client Request Interceptors
    Client Message Body Writer
    
    Client Response Filter
    Client Reader Interceptor
    Client Message Body Reader

    '''

    def beforeRequest(self, request: ClientRequest):
        '''
        execute filters and execute interceptors
        :return:
        '''

        bodyWorkers = MessageBodyWorkers(self.binder)
        request.setWorkers(MessageBodyWorkers(self.binder))
        request.setWriterInterceptors(self.getBinder().getByContract(WriterInterceptor))
        request.setReaderInterceptors(self.getBinder().getByContract(ReaderInterceptor))

        filterphase: RequestFilterPhase = RequestFilterPhase(self.binder)
        filterphase.apply(request)

    def invoke(self, request: ClientRequest) -> ClientResponse:
        self._checkConnector()
        response: ClientResponse = None
        processingException: ProcessingException = None
        try:
            self.beforeRequest(request)

            response = self.__connector__.apply(
                self.addUserAgent(request, self.__connector__.getName())
            )
        except AbortException as aborted:
            response = aborted.getAbortResponse()

        except ClientResponseProcessingException as crpe:
            # processingException = crpe
            response = crpe.getClientResponse()
        except ProcessingException as pe:
            processingException = pe
        except Raisable as t:
            processingException = ProcessingException(t.getMessage(), t)
        except BaseException as unknown:
            processingException = ProcessingException(f'Unknown error: {unknown}', unknown)
        finally:
            if processingException:
                raise processingException
            response = self.afterRequest(request, response, processingException)
            return response

    def afterRequest(self, request, response, processingException):
        return response
