from typing import Type, Dict

from piggy.base import UnsupportedOperationException
from piggy.base.util.date import Date
from piggy.restful.core.piggyuribuilder import PiggyUriBuilder
from piggy.restful.internal.message.outboundmessagecontext import OutboundMessageContext
from piggy.restful.internal.message.outboundresponse import OutboundResponse
from piggy.restful.internal.provider.message.cachecontrolheaderprovider import CacheControlHeaderProvider
from piggy.restful.internal.provider.message.cookieheaderprovider import CookieHeaderProvider
from piggy.restful.internal.provider.message.dateheaderprovider import DateHeaderProvider
from piggy.restful.internal.provider.message.entitytagheaderprovider import EntityTagHeaderProvider
from piggy.restful.internal.provider.message.linkheaderprovider import LinkHeaderProvider
from piggy.restful.internal.provider.message.mediatypeheaderprovider import MediaTypeHeaderProvider
from piggy.restful.internal.provider.message.newcookieheaderprovider import NewCookieHeaderProvider
from ws.rs.core.application import Application
from ws.rs.core.cachecontrol import CacheControl
from ws.rs.core.cookie import Cookie
from ws.rs.core.entitytag import EntityTag
from ws.rs.core.link import Link
from ws.rs.core.mediatype import MediaType
from ws.rs.core.newcookie import NewCookie
from ws.rs.ext.runtimedelegate import RuntimeDelegate


class PiggyRuntimeDelegate(RuntimeDelegate):
    HEADERS_DELEGATES: Dict[Type, RuntimeDelegate.HeaderDelegate] = {
        MediaType: MediaTypeHeaderProvider(),
        CacheControl: CacheControlHeaderProvider(),
        EntityTag: EntityTagHeaderProvider(),
        Cookie: CookieHeaderProvider(),
        NewCookie: NewCookieHeaderProvider(),
        Link: LinkHeaderProvider(),
        Date: DateHeaderProvider()
    }

    def createHeaderDelegate(self, cls: Type) -> RuntimeDelegate.HeaderDelegate:
        return self.HEADERS_DELEGATES[cls]

    def createLinkBuilder(self) -> Link.Builder:
        raise UnsupportedOperationException("Not supported yet.")

    def createResponseBuilder(self) -> OutboundResponse.Builder:
        builder = OutboundResponse.Builder(OutboundMessageContext(None))
        return builder

    def createUriBuilder(self) -> PiggyUriBuilder:
        return PiggyUriBuilder()

    def createVariantListBuilder(self) -> 'PiggyVariantListBuilder':
        raise UnsupportedOperationException("Not supported yet.")

    def createEndpoint(self, application: Application, endpoint: Type) -> object:
        raise UnsupportedOperationException("Not supported yet.")
