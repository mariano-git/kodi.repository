from piggy.base.util.logging import Logger
from typing import List, Set

from piggy.base.util import Objects
from piggy.base.util.collections import Collections
from piggy.base.util.map import Map
from piggy.base.util.simplemap import SimpleMap
from piggy.restful.utils.collection.immutablemultivaluedmap import ImmutableMultivaluedMap
from piggy.restful.utils.collection.keyignorecasemultivaluedmap import KeyIgnoreCaseMultivaluedMap

from ws.rs.core.abstractmultivaluedmap import AbstractMultivaluedMap
from ws.rs.core.configuration import Configuration
from ws.rs.core.multivaluedmap import MultivaluedMap, V
from ws.rs.core.multivaluesimplemap import MultivaluedSimpleMap
from ws.rs.core.newcookie import NewCookie
from ws.rs.ext.runtimedelegate import RuntimeDelegate


class HeaderUtils:
    __LOGGER__ = Logger.getLogger(f'{__name__}.{__qualname__}')

    def __init__(self):
        raise AssertionError('No instance allowed')

    @classmethod
    def createInbound(cls) -> AbstractMultivaluedMap[str, str]:
        return KeyIgnoreCaseMultivaluedMap[str]()

    @classmethod
    def createOutbound(cls) -> AbstractMultivaluedMap[str, object]:
        return KeyIgnoreCaseMultivaluedMap[object]()

    @classmethod
    def empty(cls) -> MultivaluedMap[str, V]:
        return ImmutableMultivaluedMap[str, V].empty()

    @classmethod
    def asString(cls, headerValue: object, rd: RuntimeDelegate) -> str:
        if headerValue is None:
            return None
        if isinstance(headerValue, str):
            return headerValue
        if rd is None:
            rd = RuntimeDelegate.getInstance()
        hp: RuntimeDelegate.HeaderDelegate = rd.createHeaderDelegate(headerValue.__class__)
        return hp.toString(
            headerValue
        ) if hp else headerValue.toString() if hasattr(
            headerValue, 'toString'
        ) else str(headerValue)

    @classmethod
    def asStringList(cls, headerValues: List[object], rd: RuntimeDelegate) -> List[str]:
        if Objects.isEmpty(headerValues):
            return Collections.emptyList()

        return list(map(lambda item: HeaderUtils.asString(item, rd) if item else '[null]', headerValues))

    @classmethod
    def asStringHeaders(cls,
                        headers: MultivaluedMap[str, object],
                        configuration: Configuration) -> MultivaluedMap[str, str]:

        if headers is None:
            return None
        rd = RuntimeDelegate.getInstance()

        map: MultivaluedMap[str, str] = MultivaluedSimpleMap[str, str]()
        for entry in headers.entrySet():
            key: str = entry.getKey()
            values: List[object] = entry.getValue()
            if Objects.isEmpty(values):
                continue
            map.put(key, HeaderUtils.asStringList(values, rd))
        return map

    @classmethod
    def asStringHeadersSingleValue(cls,
                                   headers: MultivaluedMap[str, object],
                                   configuration: Configuration) -> Map[str, str]:
        if headers is None:
            return None
        rd = RuntimeDelegate.getInstance()
        map: Map[str, str] = SimpleMap[str, str]()
        for entry in headers.entrySet():
            key: str = entry.getKey()
            values: List[object] = entry.getValue()
            if Objects.isEmpty(values):
                continue
            map.put(key, HeaderUtils.asHeaderString(values, rd))
        return map

    @classmethod
    def asHeaderString(cls, values: List[object], rd: RuntimeDelegate) -> str:
        if values is None:
            return None
        stringList: List[str] = HeaderUtils.asStringList(values, rd)
        return ','.join(stringList)

    @classmethod
    def checkHeaderChanges(cls, headersSnapshot: Map[str, str],
                           currentHeaders: MultivaluedMap[str, object],
                           connectorName: str):

        if cls.__LOGGER__.isEnabledFor(logging.WARNING):
            rd = RuntimeDelegate.getInstance()
            changedHeaderNames: Set[str] = set()
            for entry in currentHeaders.entrySet():
                if not headersSnapshot.containsKey(entry.getKey()):
                    changedHeaderNames.add(entry.getKey())
                else:
                    prevValue: str = headersSnapshot.get(entry.getKey())
                    newValue: str = HeaderUtils.asHeaderString(currentHeaders.get(entry.getKey()), rd)
                    if prevValue != newValue:
                        changedHeaderNames.add(entry.getKey())

            if len(changedHeaderNames) > 0:
                if cls.__LOGGER__.isEnabledFor(logging.WARNING):
                    msg = "There are some request headers that have not been sent by connector [{0}]. " \
                          "Probably you added those headers in WriterInterceptor or MessageBodyWriter. " \
                          "That feature is not supported by the connector. " \
                          "Please, do not modify headers in WriterInterceptor or MessageBodyWriter." \
                          "* Unsent header changes: {1}"
                    cls.__LOGGER__.warning(msg.format(connectorName, changedHeaderNames))

    @classmethod
    def getPreferredCookie(cls, first: NewCookie, second: NewCookie) -> NewCookie:
        """
        Compare two NewCookies having the same name. See documentation RFC.
        :param first: NewCookie to be compared.
        :param second: NewCookie to be compared.
        :return: the preferred NewCookie according to rules :
                 - the latest maxAge.
                 - if equal, compare the expiry date.
                 - if equal, compare path length.
        """
        if first is None and second is None:
            return None
        if first and second is None:
            return first
        if second and first is None:
            return second

        if first.getMaxAge() > second.getMaxAge():
            return first
        if first.getMaxAge() < second.getMaxAge():
            return second

        if first.getExpiry() > second.getExpiry():
            return first
        if first.getExpiry() < second.getExpiry():
            return second

        if first.getPath() > second.getPath():
            return first
        if first.getPath() < second.getPath():
            return second
