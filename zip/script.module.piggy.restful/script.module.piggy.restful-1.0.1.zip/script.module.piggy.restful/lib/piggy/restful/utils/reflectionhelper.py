from ws.rs.core.genericentity import GenericEntity
from ws.rs.core.generictype import GenericType


class ReflectionHelper:
    @classmethod
    def genericTypeFor(cls, instance: object):
        """
        Create a ws.rs.core.GenericType information for a given object instance.
        If the supplied instance is an instance of ws.rs.core.GenericEntity, the generic type
        information will be computed using the ws.rs.core.GenericEntity#getType()
        information. Otherwise the instance__class__ will be used.

        :param instance: instance for which the {@code GenericType} description should be created.
        :return: {@code GenericType} describing the {@code instance}.
        """

        if isinstance(instance, GenericEntity):
            return GenericType(instance).getType()
        else:
            return None if instance is None else GenericType(instance.__class__)
