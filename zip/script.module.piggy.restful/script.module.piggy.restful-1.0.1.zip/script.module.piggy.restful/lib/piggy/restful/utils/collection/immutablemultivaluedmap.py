from __future__ import annotations

from typing import List, Set, Collection, cast

from piggy.base import NullPointerException, UnsupportedOperationException, Overload
from piggy.base.util.collections import Collections
from piggy.base.util.map import K, Map
from ws.rs.core.multivaluedmap import MultivaluedMap, V
from ws.rs.core.multivaluesimplemap import MultivaluedSimpleMap


class ImmutableMultivaluedMap(MultivaluedMap[K, V]):
    __slots__ = '__delegate__'

    @classmethod
    def empty(cls) -> ImmutableMultivaluedMap[K, V]:
        return ImmutableMultivaluedMap[K, V](MultivaluedSimpleMap[K, V]())

    def __init__(self, delegate: MultivaluedMap[K, V]):
        if delegate is None:
            raise NullPointerException("ImmutableMultivaluedMap delegate must not be 'null'.")
        self.__delegate__ = delegate

    def equalsIgnoreValueOrder(self, otherMap: MultivaluedMap[K, V]) -> bool:
        return self.__delegate__.equalsIgnoreValueOrder(otherMap)

    def putSingle(self, key: K, value: V):
        raise UnsupportedOperationException("This MultivaluedMap implementation is immutable.")

    def add(self, key: K, value: V):
        raise UnsupportedOperationException("This MultivaluedMap implementation is immutable.")

    def getFirst(self, key: K) -> V:
        return self.__delegate__.getFirst(key)

    @Overload
    def addAll(self, key: K, *newValues: V):
        raise UnsupportedOperationException("This MultivaluedMap implementation is immutable.")

    @Overload
    def addAll(self, key: K, valueList: List[V]):
        raise UnsupportedOperationException("This MultivaluedMap implementation is immutable.")

    def addFirst(self, key: K, value: V):
        raise UnsupportedOperationException("This MultivaluedMap implementation is immutable.")

    def size(self) -> int:
        return self.__delegate__.size()

    def isEmpty(self) -> bool:
        return self.__delegate__.isEmpty()

    def containsKey(self, key: object) -> bool:
        return self.__delegate__.containsKey(key)

    def containsValue(self, value: object) -> bool:
        return self.__delegate__.containsValue(value)

    def get(self, key: K) -> List[V]:
        return self.__delegate__.get(key)

    def put(self, key: K, value: List[V]) -> List[V]:
        raise UnsupportedOperationException("This MultivaluedMap implementation is immutable.")

    def remove(self, key: object) -> List[V]:
        raise UnsupportedOperationException("This MultivaluedMap implementation is immutable.")

    def putAll(self, m: Map[K, List[V]]):
        raise UnsupportedOperationException("This MultivaluedMap implementation is immutable.")

    def clear(self):
        raise UnsupportedOperationException("This MultivaluedMap implementation is immutable.")

    def keySet(self) -> Set[K]:
        return Collections.unmodifiableSet(self.__delegate__.keySet())

    def values(self) -> Collection[List[V]]:
        return Collections.unmodifiableCollection(self.__delegate__.values())

    def entrySet(self) -> Set[Map.Entry[K, List[V]]]:
        return Collections.unmodifiableSet(self.__delegate__.entrySet())

    def toString(self) -> str:
        return self.__delegate__.toString()

    def equals(self, o: object) -> bool:
        if self == o:
            return True

        if not isinstance(o, ImmutableMultivaluedMap):
            return False

        that: ImmutableMultivaluedMap = cast(ImmutableMultivaluedMap, o)

        if not (self.__delegate__.equals(that.__delegate__)):
            return False

        return True

    def hashCode(self) -> int:
        return self.__delegate__.hashCode()
