from piggy.restful.core.configurablecomponent import ConfigurableComponent
from ws.rs.runtimetype import RuntimeType


class ClientSetup(ConfigurableComponent['ClientSetup']):
    def __init__(self):
        super().__init__(RuntimeType.CLIENT)