from piggy.base.util.logging import Logger

from piggy.base import Overload, IllegalStateException
from piggy.base.util.objects import Objects
from piggy.restful.client.piggywebtarget import PiggyWebTarget
from piggy.restful.core.configurablecomponent import ConfigurableComponent
from ws.rs.client.client import Client
from ws.rs.client.webtarget import WebTarget
from ws.rs.core.uribuilder import UriBuilder


class PiggyClient(Client, ConfigurableComponent[Client]):
    __lg__ = Logger.getLogger(f'{__name__}.{__qualname__}')

    def __init__(self, parent: ConfigurableComponent):
        super().__init__(None, parent.getConfiguration())

    def close(self):
        self.getConfiguration().getRuntime().close()

    def ensureOpen(self):
        self.__lg__.debug('is open?: %s',self.getConfiguration().getRuntime().isOpen())
        if not self.getConfiguration().getRuntime().isOpen():
            raise IllegalStateException('Client is closed')

    @Overload
    def target(self, uriBuilder: UriBuilder) -> WebTarget:
        Objects.requireNonNull(uriBuilder, 'uriBuilder is null')
        self.ensureOpen()
        return PiggyWebTarget(uriBuilder, self)

    @Overload
    def target(self, uri: str) -> WebTarget:
        Objects.requireNonNull(uri, 'uri is null')
        return self.target(UriBuilder.fromUri(uri))
