from typing import List, Iterable

from piggy.base import Overload
from piggy.base.io import IOException
from piggy.base.io.bytearrayinputstream import ByteArrayInputStream
from piggy.base.io.bytearrayoutputstream import ByteArrayOutputStream
from piggy.base.io.inputstream import InputStream
from piggy.base.io.outputstream import OutputStream
from piggy.base.net.uri import URI
from piggy.base.notation import Annotation
from piggy.restful.client.clientrequest import ClientRequest
from piggy.restful.internal.message.inboundmessagecontext import InboundMessageContext
from piggy.restful.internal.message.outboundresponse import OutboundResponse
from ws.rs.client.clientresponsecontext import ClientResponseContext
from ws.rs.core.generictype import GenericType
from ws.rs.core.response import Response
from ws.rs.ext.readerinterceptor import ReaderInterceptor


class ClientResponse(InboundMessageContext, ClientResponseContext):

    @Overload
    def __init__(self, requestContext: ClientRequest, response: Response):
        self.__init__(response.getStatusInfo(), requestContext, requestContext.getUri())

        self.headers(OutboundResponse.of(
            response, requestContext.getConfiguration()
        ).getContext().getStringHeaders())

        entity: object = response.getEntity()
        if entity is not None:
            class entityStream(InputStream):
                def __init__(self):
                    self.byteArrayInputStream: ByteArrayInputStream = None

                def read(self, b: bytearray = None, off: int = None, length: int = None) -> int:
                    if self.byteArrayInputStream is None:
                        baos: ByteArrayOutputStream = ByteArrayOutputStream()
                        stream: OutputStream = None
                        try:
                            try:
                                stream = requestContext.getWorkers().writeTo(
                                    entity, entity.__class__, None, None, response.getMediaType(),
                                    response.getMetadata(), requestContext.getPropertiesDelegate(), baos,
                                    list())
                            finally:
                                if stream is not None:
                                    stream.close()
                        except IOException as io:
                            print(io)
                        self.byteArrayInputStream = ByteArrayInputStream(baos.toBytes())
                    return self.byteArrayInputStream.read()

            self.setEntityStream(entityStream())

    @Overload
    def __init__(self, status: Response.StatusType, requestContext: ClientRequest, resolvedRequestUri: URI):
        super().__init__(requestContext.getConfiguration())
        self.status = status
        self.resolvedUri = resolvedRequestUri
        self.requestContext = requestContext
        self.setWorkers(requestContext.getWorkers())

    def getStatusInfo(self) -> Response.StatusType:
        return self.status

    def readEntity(self, entityType, annotations: List[Annotation] = None):
        rawType = None
        clsType = None
        if annotations is None:
            annotations = list()

        if isinstance(entityType, GenericType):
            rawType = entityType.getRawType()
            clsType = entityType.getType()
        else:
            rawType = entityType
            clsType = entityType
        return super().readEntity(rawType, clsType, annotations, self.requestContext.getPropertiesDelegate())

    def getReaderInterceptors(self) -> Iterable[ReaderInterceptor]:
        return self.requestContext.getReaderInterceptors()
