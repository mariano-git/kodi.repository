import inspect
from typing import Type, TypeVar, List, Any, Callable, cast, get_origin, Collection, Optional, Set

from piggy.base import Overload, NoSuchElementException, UnsupportedOperationException
from piggy.base.proxy import InvocationHandler, Proxy
from piggy.base.util import Objects
from piggy.restful.client.clientproperties import ClientProperties
from piggy.restful.client.piggywebtarget import PiggyWebTarget
from piggy.restful.utils.annotationutils import AnnotationUtils
from ws.rs.beanparam import BeanParam
from ws.rs.client.client import Client
from ws.rs.client.entity import Entity
from ws.rs.client.invocation import Invocation
from ws.rs.client.webtarget import WebTarget
from ws.rs.consumes import Consumes
from ws.rs.cookieparam import CookieParam
from ws.rs.core.cookie import Cookie
from ws.rs.core.form import Form
from ws.rs.core.genericentity import GenericEntity
from ws.rs.core.generictype import GenericType
from ws.rs.core.httpheaders import HttpHeaders
from ws.rs.core.mediatype import MediaType
from ws.rs.core.multivaluedmap import MultivaluedMap
from ws.rs.core.multivaluesimplemap import MultivaluedSimpleMap
from ws.rs.formparam import FormParam
from ws.rs.headerparam import HeaderParam
from ws.rs.httpmethod import HttpMethod
from ws.rs.matrixparam import MatrixParam
from ws.rs.namebinding import NameBinding
from ws.rs.path import Path
from ws.rs.pathparam import PathParam
from ws.rs.produces import Produces
from ws.rs.queryparam import QueryParam

T = TypeVar('T')


class RequestParameters:
    __slots__ = '__headers__', '__cookies__', '__form__', '__newTarget__'

    def __init__(self, newTarget: WebTarget, headers: MultivaluedMap[str, object], cookies: List[Cookie], form: Form):
        self.__headers__: MultivaluedSimpleMap[str, List[Any]] = MultivaluedSimpleMap()
        self.__headers__.putAll(headers)
        self.__cookies__: List[Cookie] = list()
        self.__cookies__.extend(cookies)
        self.__form__ = Form()
        self.__form__.asMap().putAll(form.asMap())

        self.__newTarget__: WebTarget = newTarget

    def addParameter(self, value: object, annotation: Type):

        if annotation:
            if isinstance(annotation, PathParam):
                self.__newTarget__ = self.__newTarget__.resolveTemplate(annotation.value(), value)
            elif isinstance(annotation, QueryParam):
                # FIXME convert
                if isinstance(value, str) or isinstance(value, int) or isinstance(value, bool):
                    self.__newTarget__ = self.__newTarget__.queryParam(annotation.value(), value)
                else:
                    self.__newTarget__ = self.__newTarget__.queryParam(annotation.value(), value)
                '''    
                if isinstance(value, Collection):
                    self.__newTarget__ = self.__newTarget__.queryParam(annotation.value(), self._convert(value))
                '''

            elif isinstance(annotation, HeaderParam):
                if isinstance(value, Collection):
                    self.__headers__.addAll(annotation.value(), self._convert(value))
                else:
                    self.__headers__.addAll(annotation.value(), value)
            elif isinstance(annotation, CookieParam):
                c: Cookie = None
                name: str = annotation.value()
                if isinstance(value, Collection):
                    for v in value:
                        if not isinstance(v, Cookie):
                            c = Cookie(name, str(v))
                        else:
                            c = cast(Cookie, v)
                            if name != c.getName():
                                # grey area... // is this the right thing to do? or should I fail? or ignore the difference?
                                c = Cookie(name, c.getValue(), c.getPath(), c.getDomain(), c.getVersion())
                        self.__cookies__.append(c)
                else:
                    if not isinstance(value, Cookie):
                        self.__cookies__.append(Cookie(name, str(value)))
                    else:
                        c = cast(Cookie, value)
                        if name != c.getName():
                            # grey area... // is this the right thing to do? or should I fail? or ignore the difference?
                            c = Cookie(name, c.getValue(), c.getPath(), c.getDomain(), c.getVersion())
                    self.__cookies__.append(c)
            elif isinstance(annotation, MatrixParam):
                if isinstance(value, Collection):
                    self.__newTarget__ = self.__newTarget__.matrixParam(annotation.value(), self._convert(value))
                else:
                    self.__newTarget__ = self.__newTarget__.matrixParam(annotation.value(), value)
            elif isinstance(annotation, FormParam):
                if isinstance(value, Collection):
                    for v in value:
                        self.__form__.param(annotation.value(), str(v))
                else:
                    self.__form__.param(annotation.value(), str(value))
            elif isinstance(annotation, BeanParam):
                if isinstance(value, Collection):
                    for v in value:
                        self._addBeanParameter(v)
                else:
                    self._addBeanParameter(value)

    def _addBeanParameter(self, beanParam: object):
        raise UnsupportedOperationException("Not supported yet.")

    @classmethod
    def hasAnyParamAnnotation(cls, annotation: Type):
        return annotation in {PathParam, QueryParam, HeaderParam, CookieParam, MatrixParam, FormParam, BeanParam}

    def getNewTarget(self):
        return self.__newTarget__

    def getHeaders(self) -> MultivaluedSimpleMap[str, object]:
        return self.__headers__

    def getCookies(self) -> List[Cookie]:
        return self.__cookies__

    def getForm(self):
        return self.__form__


class ClientResourceFactory(InvocationHandler):

    @Overload
    @staticmethod
    def newResource(resourceInterface: Type[T], client:Client) -> T:
        return ClientResourceFactory.newResource(
            resourceInterface, None, False, client, MultivaluedSimpleMap(), list(), Form()
        )

    @Overload
    @staticmethod
    def newResource(resourceInterface: Type[T], target: WebTarget) -> T:
        return ClientResourceFactory.newResource(
            resourceInterface, target, False, None, MultivaluedSimpleMap(), list(), Form()
        )

    @Overload
    @classmethod
    def newResource(cls, resourceInterface: Type[T],
                    target: WebTarget,
                    ignoreResourcePath: bool,
                    client:Client,
                    headers: MultivaluedMap[str, object],
                    cookies: List[Cookie],
                    form: Form) -> T:
        return Proxy.newProxyInstance(
            resourceInterface, ClientResourceFactory(
                resourceInterface, cls._addPathFromAnnotation(resourceInterface, target, client), client, headers, cookies, form)
        )

    @classmethod
    def _addPathFromAnnotation(cls, element: Any, target: WebTarget, client:Client) -> WebTarget:
        pathValue = AnnotationUtils.getAnnotationValue(element, Path, None)
        if pathValue:
            if target is None:
                target = client.target(pathValue)
                return target
            target = target.path(pathValue)
        return target

    def getGenericEntityType(self, value: Any) -> Type:
        pass

    def __init__(self, api: Type[T], target: WebTarget, client:Client, headers: MultivaluedMap[str, object], cookies: List[Cookie],
                 form: Form):
        self.__api__ = api
        self.__target__ = target
        self.__client__ = client
        self.__headers__ = headers
        self.__cookies__ = cookies
        self.__form__ = form

    def invoke(self, method: str, *args, **kwargs) -> Any:
        apiCall: Callable[..., Any] = cast(
            Callable[..., Any], Objects.requireNonNullElseRaise(
                getattr(self.__api__, method, None),
                NoSuchElementException,
                f'Unable to reference function: {method} on class: {self.__api__}'
            )
        )
        # check if this apiCall was bound. This is a deviation from the JAX-RS spec because namebindings isn't supported
        # on client side

        namebinding:NameBinding = apiCall.getAnnotation(NameBinding)
        if namebinding is not None:
            # namebinding is a marker annotation and do not have getValue method.
            bindings = namebinding.getAnnotations()
            # inject this bindings to configuration
            self.__target__.property(ClientProperties.CLIENT_NAME_BINDINGS, bindings)


        signature = inspect.signature(apiCall)
        # response type
        responseType = signature.return_annotation

        # determine method name
        httpMethod = AnnotationUtils.getAnnotationValue(apiCall, HttpMethod, None)

        # create a new UriBuilder appending the @Path attached to the method
        newTarget: WebTarget = self._addPathFromAnnotation(apiCall, self.__target__, self.__client__)

        if httpMethod is None:
            if newTarget == self.__target__:
                raise UnsupportedOperationException("Not a resource method.")

        # process method params (build maps of (Path|Form|Cookie|Matrix|Header..)Params
        # and extract entity type
        requestParameters: RequestParameters = RequestParameters(
            newTarget, self.__headers__, self.__cookies__, self.__form__
        )

        parameters = signature.parameters
        paramSz = len(parameters)
        argsLen = len(args)
        allArgs = argsLen + len(kwargs)
        diff = paramSz - allArgs
        if diff > 1:
            defaults = True
        idx = paramSz - 1

        entity: object = None
        entityType: Type = None

        # skip parameters without annotations
        for k, v in reversed(parameters.items()):
            if v.annotation is not inspect.Parameter.empty:
                value = None
                annot = None
                key = None
                if k in kwargs and idx > 0:
                    value = kwargs[k]
                    key = k
                    annot = v.annotation
                elif argsLen >= idx > 0:
                    value = args[idx - 1]
                    key = k
                    annot = v.annotation
                elif idx > 0 and v.default:
                    value = v.default
                    key = k
                    annot = v.annotation

                if RequestParameters.hasAnyParamAnnotation(type(annot)):
                    requestParameters.addParameter(value, annot)
                else:
                    if entity:
                        raise UnsupportedOperationException('Only one entity at time is allowed')
                    entity = value
                    entityType = self.getGenericEntityType(annot)
            idx -= 1

        newTarget = requestParameters.getNewTarget()

        if httpMethod is None:
            # the method is a subresource locator
            return ClientResourceFactory.newResource(responseType, newTarget, True,
                                                     requestParameters.getHeaders(),
                                                     requestParameters.getCookies(),
                                                     requestParameters.getForm())

        produces: Optional[Set[str]] = AnnotationUtils.getAnnotationValue(apiCall, Produces, None)
        if produces is None:
            produces = AnnotationUtils.getAnnotationValue(self.__api__, Produces, None)

        accepts: str = ','.join(produces) if produces else ''

        # determine content type
        contentType: str = None
        if entity:
            contentTypeEntries = requestParameters.getHeaders().get(HttpHeaders.CONTENT_TYPE)
            if Objects.isEmpty(contentTypeEntries):
                consumes: Optional[Set[str]] = AnnotationUtils.getAnnotationValue(apiCall, Consumes, None)
                if consumes is None:
                    consumes = AnnotationUtils.getAnnotationValue(self.__api__, Consumes, None)
                contentType = ','.join(consumes) if consumes else None
            else:
                contentType = ','.join(contentTypeEntries) if contentTypeEntries else None

        builder: Invocation.Builder = newTarget.request().headers(
            requestParameters.getHeaders()  # this resets all headers so do this first
        ).accept(accepts)  # if @Produces is defined, propagate values into Accept header; empty array is NO-OP

        for c in requestParameters.getCookies():
            builder.cookie(c)

        result: object = None

        formMap = requestParameters.getForm().asMap()
        if entity is None and not formMap.isEmpty():
            entity = requestParameters.getForm()
            contentType = MediaType.APPLICATION_FORM_URLENCODED
        else:
            if contentType is None:
                contentType = MediaType.APPLICATION_OCTET_STREAM
            if not formMap.isEmpty():
                if isinstance(entity, Form):
                    entity.asMap().putAll(formMap)
                else:
                    # TODO: should at least log some warning here?
                    pass

        responseGenericType = GenericType(responseType)

        if entity:
            # if issubclass(entityType, Generic):
            if get_origin(entityType):
                entity = GenericEntity(entity, entityType)
            result = builder.method(httpMethod, Entity.entity(entity, contentType), responseGenericType)
        else:
            result = builder.method(httpMethod, responseGenericType)
        return result
