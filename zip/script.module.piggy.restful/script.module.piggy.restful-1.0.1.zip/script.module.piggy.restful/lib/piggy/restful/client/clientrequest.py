from typing import Iterable

from piggy.base import Overload, RuntimeException, IllegalStateException
from piggy.base.io import IOException
from piggy.base.io.outputstream import OutputStream
from piggy.base.net.uri import URI
from piggy.base.util import Objects
from piggy.base.util.locale import Locale
from piggy.base.util.logging import Logger
from piggy.restful.internal.mappropertiesdelegate import MapPropertiesDelegate
from piggy.restful.internal.message.messagebodyworkers import MessageBodyWorkers
from piggy.restful.internal.message.outboundmessagecontext import OutboundMessageContext
from piggy.restful.internal.propertiesdelegate import PropertiesDelegate
from piggy.restful.utils.headerutils import HeaderUtils
from ws.rs.client.clientrequestcontext import ClientRequestContext
from ws.rs.core.configuration import Configuration
from ws.rs.core.generictype import GenericType
from ws.rs.core.httpheaders import HttpHeaders
from ws.rs.core.mediatype import MediaType
from ws.rs.core.multivaluedmap import MultivaluedMap
from ws.rs.core.response import Response
from ws.rs.core.variant import Variant
from ws.rs.ext.writerinterceptor import WriterInterceptor


class ClientRequest(OutboundMessageContext, ClientRequestContext, HttpHeaders):
    __lg__ = Logger.getLogger(f'{__name__}.{__qualname__}')
    __slots__ = '__requestUri__', \
                '__httpMethod__', \
                '__workers__', \
                '__configuration__', \
                '__asynchronous__', \
                '__readerInterceptors__', \
                '__writerInterceptors__', \
                '__propertiesDelegate__', \
                '__ignoreUserAgent__', \
                '__entityWritten__', \
                '__abortResponse__'

    @Overload
    def __init__(self, requestUri: URI, configuration: Configuration, propertiesDelegate: PropertiesDelegate):
        super().__init__(configuration)

        self.__requestUri__ = requestUri
        self.__configuration__ = configuration
        self.__propertiesDelegate__ = propertiesDelegate
        self.__httpMethod__: str = None
        self.__workers__ = None
        self.__asynchronous__ = False
        self.__writerInterceptors__ = None
        self.__readerInterceptors__ = None
        # do not add user-agent header (if not directly set) to the request.
        self.__ignoreUserAgent__ = False
        self.__entityWritten__ = False
        self.__abortResponse__ = None

    @Overload
    def __init__(self, original: 'ClientRequest'):
        super().__init__(original)
        self.__requestUri__ = original.__requestUri__
        self.__httpMethod__ = original.__httpMethod__
        self.__workers__ = original.__workers__
        self.__configuration__ = original.__configuration__
        self.__asynchronous__ = original.isAsynchronous()
        self.__readerInterceptors__ = original.__readerInterceptors__
        self.__writerInterceptors__ = original.__writerInterceptors__
        self.__propertiesDelegate__ = MapPropertiesDelegate(original.__propertiesDelegate__)
        self.__ignoreUserAgent__ = original.__ignoreUserAgent__
        self.__entityWritten__ = original.__entityWritten__
        self.__abortResponse__ = original.__abortResponse__

    def getWorkers(self) -> MessageBodyWorkers:
        return self.__workers__

    def getClientRuntime(self) -> 'ClientRuntime':
        return self.__configuration__.getRuntime()

    def getConfiguration(self) -> Configuration:
        return self.__configuration__

    def abortWith(self, response: Response):
        self.__abortResponse__ = response

    def getAbortResponse(self) -> Response:
        return self.__abortResponse__

    def getPropertiesDelegate(self) -> PropertiesDelegate:
        return self.__propertiesDelegate__

    @Overload
    def accept(self, *types: str):
        self.getHeaders().addAll(HttpHeaders.ACCEPT, *types)

    def encoding(self, encoding: str):
        if encoding is None:
            self.getHeaders().remove(HttpHeaders.CONTENT_ENCODING)
        else:
            self.getHeaders().putSingle(HttpHeaders.CONTENT_ENCODING, encoding)

    def getConfiguration(self) -> Configuration:
        return self.__configuration__

    def getMethod(self) -> str:
        return self.__httpMethod__

    def getProperty(self, name: str) -> object:
        return self.__propertiesDelegate__.getProperty(name)

    def setWriterInterceptors(self, interceptors: Iterable[WriterInterceptor]):
        self.__writerInterceptors__ = interceptors

    def setReaderInterceptors(self, interceptors: Iterable[WriterInterceptor]):
        self.__readerInterceptors__ = interceptors

    def getReaderInterceptors(self):
        return self.__readerInterceptors__

    def getRequestHeaders(self) -> MultivaluedMap[str, str]:
        return HeaderUtils.asStringHeaders(self.getHeaders(), self.getConfiguration())

    def getUri(self) -> URI:
        return self.__requestUri__

    @Overload
    def ignoreUserAgent(self) -> bool:
        return self.__ignoreUserAgent__

    def isAsynchronous(self) -> bool:
        return self.__asynchronous__

    @Overload
    def language(self, language: Locale):
        if language is None:
            self.getHeaders().remove(HttpHeaders.CONTENT_LANGUAGE)
        else:
            self.getHeaders().putSingle(HttpHeaders.CONTENT_LANGUAGE, language)

    @Overload
    def language(self, language: str):
        if language is None:
            self.getHeaders().remove(HttpHeaders.CONTENT_LANGUAGE)
        else:
            self.getHeaders().putSingle(HttpHeaders.CONTENT_LANGUAGE, language)

    def setMethod(self, method: str):
        self.__httpMethod__ = method

    def setWorkers(self, workers: MessageBodyWorkers):
        self.__workers__ = workers

    @Overload
    def mediaType(self, typ: str):
        self.mediaType(MediaType.valueOf(typ) if typ else None)

    @Overload
    def mediaType(self, mediaType: MediaType):
        self.setMediaType(mediaType)

    def variant(self, variant: Variant):
        if variant is None:
            self.mediaType(None)
            self.language(None)
            self.encoding(None)
        else:
            self.mediaType(variant.getMediaType())
            self.language(variant.getLanguage())
            self.encoding(variant.getEncoding())

    def _ensureMediaType(self):
        if self.getMediaType() is None:
            entityType = GenericType(self.getEntityType())
            mediaTypes = self.__workers__.getMessageBodyWriterMediaTypes(
                entityType.getRawType(),
                entityType.getType(),
                self.getEntityAnnotations()
            )

            self.setMediaType(self._getMediaType(mediaTypes))

    def writeEntity(self):
        Objects.checkNonFalseElseRaise(
            not self.__entityWritten__,
            IllegalStateException,
            'The entity was already written in this request. '
            'The entity can be written (serialized into the output stream) only once per request.')
        self.__entityWritten__ = True
        self._ensureMediaType()
        entityType = GenericType(self.getEntityType())
        self.doWriteEntity(self.__workers__, entityType)

    def doWriteEntity(self, workers: MessageBodyWorkers, entityType: GenericType):
        entityStream: OutputStream = None
        connectionFailed = False
        runtimeException = False
        try:
            try:
                entityStream = workers.writeTo(
                    self.getEntity(),
                    entityType.getRawType(),
                    entityType.getType(),
                    self.getEntityAnnotations(),
                    self.getMediaType(),
                    self.getHeaders(),
                    self.getPropertiesDelegate(),
                    self.getEntityStream(),
                    self.__writerInterceptors__
                )
                self.setEntityStream(entityStream)
            except IOException as e:
                # JERSEY-2728 - treat SSLException as connection failure
                connectionFailed = True
                raise e
            except RuntimeException as e:
                runtimeException = True
                raise e

        finally:
            # in case we've seen the ConnectException, we won't try to close/commit stream as this would produce just
            # another instance of ConnectException (which would be logged even if the previously thrown one is
            # propagated) However, if another failure occurred, we still have to try to close and commit the stream -
            # and if we experience another failure, there is a valid reason to log it
            if not connectionFailed:
                if entityStream is not None:
                    try:
                        self.__entityStream__.close()
                    except IOException as e:
                        if not connectionFailed:
                            raise e
                        else:
                            self.__lg__.debug(f'Error closing output stream: {e.getMessage()}')
                    except RuntimeException as e:
                        if not runtimeException:
                            raise e
                        else:
                            self.__lg__.debug(f'Error closing output stream: {e.getMessage()}')

                try:
                    self.commitStream()
                except IOException as e:
                    if not connectionFailed:
                        raise e
                    else:
                        self.__lg__.debug(f'Error closing output stream: {e.getMessage()}')
                except RuntimeException as e:
                    if not runtimeException:
                        raise e
                    else:
                        self.__lg__.debug(f'Error closing output stream: {e.getMessage()}')
