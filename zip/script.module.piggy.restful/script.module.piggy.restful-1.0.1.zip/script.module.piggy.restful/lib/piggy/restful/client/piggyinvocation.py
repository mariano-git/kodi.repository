from enum import Enum
from typing import Dict, Type

from piggy.base import Overload, IllegalArgumentException, IllegalStateException, Raisable
from piggy.base.net.uri import URI
from piggy.base.util import Objects
from piggy.base.util.conditional import Conditional
from piggy.base.util.logging import Logger
from piggy.restful.client.clientproperties import ClientProperties
from piggy.restful.client.clientrequest import ClientRequest
from piggy.restful.client.clientresponse import ClientResponse
from piggy.restful.client.inboundresponse import InboundResponse
from piggy.restful.ext.clientruntime import ClientRuntime
from piggy.restful.internal.mappropertiesdelegate import MapPropertiesDelegate
from piggy.restful.utils.converters import Converters
from ws.rs.badrequestexception import BadRequestException
from ws.rs.client.entity import Entity
from ws.rs.client.invocation import Invocation
from ws.rs.client.responseprocessingexception import ResponseProcessingException
from ws.rs.client.syncinvoker import SyncInvoker
from ws.rs.clienterrorexception import ClientErrorException
from ws.rs.core.configuration import Configuration
from ws.rs.core.generictype import GenericType, T
from ws.rs.core.multivaluedmap import MultivaluedMap
from ws.rs.core.response import Response
from ws.rs.forbiddenexception import ForbiddenException
from ws.rs.internalservererrorexception import InternalServerErrorException
from ws.rs.notacceptableexception import NotAcceptableException
from ws.rs.notallowedexception import NotAllowedException
from ws.rs.notauthorizedexception import NotAuthorizedException
from ws.rs.notfoundexception import NotFoundException
from ws.rs.notsupportedexception import NotSupportedException
from ws.rs.processingexception import ProcessingException
from ws.rs.redirectionexception import RedirectionException
from ws.rs.servererrorexception import ServerErrorException
from ws.rs.serviceunavailableexception import ServiceUnavailableException
from ws.rs.webapplicationexception import WebApplicationException


class PiggyInvocation(Invocation):
    __lg__ = Logger.getLogger(f'{__name__}.{__qualname__}')

    class SyncBuilder(SyncInvoker):
        def __init__(self, uri: URI, config: Configuration):
            self.requestContext = ClientRequest(uri, config, MapPropertiesDelegate())

        def storeEntity(self, entity: Entity):
            if entity:
                self.requestContext.variant(entity.getVariant())
                self.requestContext.setEntity(entity.getEntity())
                self.requestContext.setEntityAnnotations(entity.getAnnotations())

        @Overload
        def method(self, name: str, entity: Entity, responseType: GenericType[T]) -> T:
            Objects.requireNonNullElseRaise(responseType, IllegalArgumentException, "Requested response type is null.")
            self.requestContext.setMethod(name)
            self.storeEntity(entity)
            return PiggyInvocation(self).invoke(responseType)

        @Overload
        def method(self, name: str, responseType: GenericType[T]) -> T:
            self.requestContext.setMethod(name)
            return PiggyInvocation(self).invoke(responseType)

    class Builder(SyncBuilder):
        __lg__ = Logger.getLogger(f'{__name__}.{__qualname__}')

        def __init__(self, uri: URI, config: Configuration):
            self.__lg__.debug('__init__ self: %s, uri: %s, config: %s', self, uri, config)
            super().__init__(uri, config)

        @Overload
        def accept(self, *mediaTypes: str) -> Invocation.Builder:
            self.requestContext.accept(*mediaTypes)
            return self

        def headers(self, headers: MultivaluedMap[str, object]) -> Invocation.Builder:
            self.requestContext.replaceHeaders(headers)
            return self
        # --------------------------------

    class EntityPresence(Enum):
        MUST_BE_NULL = 0
        MUST_BE_PRESENT = 1
        OPTIONAL = 2

    METHODS: Dict[str, EntityPresence] = {
        "DELETE": EntityPresence.MUST_BE_NULL,
        "GET": EntityPresence.MUST_BE_NULL,
        "HEAD": EntityPresence.MUST_BE_NULL,
        "OPTIONS": EntityPresence.OPTIONAL,
        "PATCH": EntityPresence.MUST_BE_PRESENT,
        "POST": EntityPresence.OPTIONAL,  # we allow to post null instead of entity
        "PUT": EntityPresence.MUST_BE_PRESENT,
        "TRACE": EntityPresence.MUST_BE_NULL
    }

    def validateHttpMethodAndEntity(self, request: ClientRequest):

        suppressExceptions: Conditional = Conditional.ofNullable(
            request.getProperty(ClientProperties.SUPPRESS_HTTP_COMPLIANCE_VALIDATION)
        ).orConditional(
            lambda: request.getConfiguration().getProperty(ClientProperties.SUPPRESS_HTTP_COMPLIANCE_VALIDATION)
        ).map(Converters.toBool).orElse(False)

        method = request.getMethod()

        entityPresence = PiggyInvocation.METHODS.get(method.upper())

        if entityPresence == PiggyInvocation.EntityPresence.MUST_BE_NULL and request.hasEntity():
            if suppressExceptions:
                self.__lg__.warning(f'Entity must be null for method: {method}')
            else:
                raise IllegalStateException(f'Entity must be null for method: {method}')

        elif entityPresence == PiggyInvocation.EntityPresence.MUST_BE_PRESENT and not request.hasEntity():
            if suppressExceptions:
                self.__lg__.warning(f'Entity must be not null for method: {method}')
            else:
                raise IllegalStateException(f'Entity must be not null for method: {method}')

    def __init__(self, builder: Builder, copyRequestContext: bool = False):

        self.validateHttpMethodAndEntity(builder.requestContext)

        self.requestContext = ClientRequest(builder.requestContext)
        self.copyRequestContext = copyRequestContext

        self.ignoreResponseException = Conditional.ofNullable(
            builder.requestContext.getConfiguration().getProperty(ClientProperties.IGNORE_EXCEPTION_RESPONSE)
        ).map(Converters.toBool).orElse(False)

    def requestForCall(self) -> ClientRequest:
        return ClientRequest(self.requestContext) if self.copyRequestContext else self.requestContext

    @Overload
    def invoke(self, responseType: GenericType[T]) -> T:
        if responseType is None:
            raise IllegalArgumentException("Response Type is None.")
        runtime: ClientRuntime = self.requestContext.getClientRuntime()

        try:
            response = runtime.invoke(self.requestForCall())
        except ProcessingException as pe:
            raise pe
        try:
            return self.translate(response, responseType)
        except ResponseProcessingException as rpe:
            cause = rpe.getCause()
            if isinstance(cause, WebApplicationException):
                raise cause
            raise rpe

    def createExceptionForFamily(self, response: Response,
                                 statusFamily: Response.Status.Family) -> WebApplicationException:
        f = Response.Status.Family

        if statusFamily == f.REDIRECTION:
            return RedirectionException(response)
        elif statusFamily == f.CLIENT_ERROR:
            return ClientErrorException(response)
        elif statusFamily == f.SERVER_ERROR:
            return ServerErrorException(response)
        else:
            return WebApplicationException(response)

    def convertToException(self, response: Response) -> ProcessingException:
        # Use an empty response if ignoring response in exception
        statusCode: int = response.getStatus()
        finalResponse: Response = Response.status(statusCode).build() if self.ignoreResponseException else response

        try:

            response.bufferEntity()

            webAppException: WebApplicationException
            status: Response.Status = Response.Status.fromStatusCode(statusCode)

            if status is None:
                statusFamily: Response.Status.Family = finalResponse.getStatusInfo().getFamily()
                webAppException = self.createExceptionForFamily(finalResponse, statusFamily)
            else:

                if status == Response.Status.BAD_REQUEST:
                    webAppException = BadRequestException(finalResponse)

                elif status == Response.Status.UNAUTHORIZED:
                    webAppException = NotAuthorizedException(finalResponse)

                elif status == Response.Status.FORBIDDEN:
                    webAppException = ForbiddenException(finalResponse)

                elif status == Response.Status.NOT_FOUND:
                    webAppException = NotFoundException(finalResponse)

                elif status == Response.Status.METHOD_NOT_ALLOWED:
                    webAppException = NotAllowedException(finalResponse)

                elif status == Response.Status.NOT_ACCEPTABLE:
                    webAppException = NotAcceptableException(finalResponse)

                elif status == Response.Status.UNSUPPORTED_MEDIA_TYPE:
                    webAppException = NotSupportedException(finalResponse)

                elif status == Response.Status.INTERNAL_SERVER_ERROR:
                    webAppException = InternalServerErrorException(finalResponse)

                elif status == Response.Status.SERVICE_UNAVAILABLE:
                    webAppException = ServiceUnavailableException(finalResponse)

                else:
                    statusFamily = finalResponse.getStatusInfo().getFamily()
                    webAppException = self.createExceptionForFamily(finalResponse, statusFamily)

            return ResponseProcessingException(finalResponse, webAppException)
        except Raisable as t:
            return ResponseProcessingException(finalResponse,
                                               'Failed to convert a response into an exception.', t)
        except BaseException as t:
            return ResponseProcessingException(finalResponse,
                                               'Failed to convert a response into an exception.', t)

    def translate(self, response: ClientResponse, responseType: Type[T]) -> T:
        if responseType == Response:
            return InboundResponse(response)

        if response.getStatusInfo().getFamily() == Response.Status.Family.SUCCESSFUL:
            try:
                return response.readEntity(responseType)
            except ProcessingException as ex:
                if isinstance(ex, ProcessingException):
                    raise ResponseProcessingException(InboundResponse(response), ex.getCause())
                raise ResponseProcessingException(InboundResponse(response), ex)
            except WebApplicationException as ex:
                raise ResponseProcessingException(InboundResponse(response), ex)
            except Raisable as ex:
                raise ResponseProcessingException(InboundResponse(response),
                                                  'Unexpected error during response processing.', ex)
            except BaseException as be:
                raise ResponseProcessingException(InboundResponse(response),
                                                  'Unexpected error during response processing.', be)
        else:
            raise self.convertToException(InboundResponse(response))
