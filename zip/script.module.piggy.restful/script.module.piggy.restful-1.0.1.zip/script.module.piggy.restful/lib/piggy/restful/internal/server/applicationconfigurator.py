from typing import Type, Union

from piggy.restful.core.componentconfiguration import ComponentConfiguration
from piggy.restful.utils.annotationutils import AnnotationUtils
from piggy.restful.utils.contracts import Contracts
from ws.inject import Priority
from ws.rs.core.application import Application
from ws.rs.priorities import Priorities
from ws.rs.runtimetype import RuntimeType


class ApplicationConfigurator:
    def __init__(self, application: Type[Application]):
        self.configuration = ComponentConfiguration(RuntimeType.SERVER)
        self.application = self.createApplication(application)

    def createApplication(self, application):
        app = application()
        props = app.getProperties()

        self.configuration.props.putAll(props)
        for cls in app.getClasses():
            self.register(application, cls)
        for o in app.getSingletons():
            self.register(application, o)
        return app

    def getContracts(self, component: Union[Type, object]):
        contracts = Contracts.createContractsMap(
            AnnotationUtils.getAnnotationValue(
                component, Priority, Priorities.USER
            ), *Contracts.getProviderContracts(
                component, RuntimeType.SERVER
            )
        )
        if contracts.isEmpty():
            return None
        return contracts

    def register(self, application: Type[Application], component: Union[Type, object]):
        # Try to get contracts
        contracts = self.getContracts(component)
        if contracts:
            self.configuration.doRegister(component, contracts)
        else:
            self.configuration.getRuntime().createEndpoint(application, component)

    def getApplication(self):
        return self.application

    def getRuntime(self):
        return self.configuration.getRuntime()

    def getMessageBodyWorkers(self):
        pass

    def getConfiguration(self):
        return self.configuration
