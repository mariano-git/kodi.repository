from piggy.base.util.logging import Logger

from piggy.base import IllegalStateException, Overload
from piggy.base.io.bytearrayoutputstream import ByteArrayOutputStream
from piggy.base.io.outputstream import OutputStream
from piggy.base.util import Objects


class CommittingOutputStream(OutputStream):
    # slots = 'closed', 'streamProvider'
    lg = Logger.getLogger(f'{__name__}.{__qualname__}')

    DEFAULT_BUFFER_SIZE = 8192

    def __init__(self):
        self.closed = False
        self.streamProvider = None
        self.directWrite = True
        self.adaptedOutput = None
        self.bufferSize = 0
        self.buffer = None
        self.committed = None

    def setStreamProvider(self, streamProvider: 'OutboundMessageContext.StreamProvider'):
        if self.closed:
            raise IllegalStateException('closed')

        Objects.nonNull(streamProvider)
        if self.streamProvider:
            self.lg.warning('Stream provider has already been initialized.')

        self.streamProvider = streamProvider

    def enableBuffering(self, bufferSize: int = DEFAULT_BUFFER_SIZE):

        Objects.checkNonFalseElseRaise(
            not self.isCommitted() and Objects.isNull(self.buffer) or Objects.isEmpty(self.buffer),
            'Cannot setup buffering as bytes have already been written to the output stream. '
            'The entity buffering can be initialized only before first bytes are written to the entity output stream.')
        self.bufferSize = bufferSize
        if bufferSize <= 0:
            self.directWrite = True
            self.buffer = None
        else:
            self.directWrite = False
            self.buffer = ByteArrayOutputStream(bufferSize)

    def isCommitted(self) -> bool:
        return self.committed

    def commitStream(self, currentSize: int = -1):

        if not self.isCommitted():
            Objects.requireNonNull(
                self.streamProvider,
                "Stream provider is not defined. It must be set before writing first bytes to the entity output stream.");
            self.adaptedOutput = self.streamProvider.getOutputStream(currentSize)
            if Objects.isNull(self.adaptedOutput):
                self.adaptedOutput = OutputStream.nullOutputStream()

            self.directWrite = True
            self.committed = True

    @Overload
    def write(self, b: bytes):

        if self.directWrite:
            self.commitStream(len(b))
            self.adaptedOutput.write(b)
        else:
            if len(b) + self.buffer.size() > self.bufferSize:
                self.flushBuffer(False)
                self.adaptedOutput.write(b)
            else:
                self.buffer.write(b)

    @Overload
    def write(self, b: bytes, off: int, length: int):

        if self.directWrite:
            self.commitStream(length)
            self.adaptedOutput.write(b, off, length)
        else:
            if len(b) + self.buffer.size() > self.bufferSize:
                self.flushBuffer(False)
                self.adaptedOutput.write(b, off, length)
            else:
                self.buffer.write(b, off, length)

    def commit(self):
        self.flushBuffer(True)
        self.commitStream()

    def close(self):
        if self.closed:
            return
        self.closed = True
        if Objects.isNull(self.streamProvider):
            self.streamProvider = OutputStream.nullOutputStream()

        self.commit()
        self.adaptedOutput.close()

    def isClosed(self) -> bool:
        return self.closed

    def flush(self):
        if self.isCommitted():
            self.adaptedOutput.flush()

    def flushBuffer(self, endOfStream: bool):
        if not self.directWrite:
            currentSize: int
            if endOfStream:
                currentSize = 0 if Objects.isNull(self.buffer) else self.buffer.size()
            else:
                currentSize = -1
            self.commitStream(currentSize)
            if not Objects.isNull(self.buffer):
                self.buffer.writeTo(self.adaptedOutput)
