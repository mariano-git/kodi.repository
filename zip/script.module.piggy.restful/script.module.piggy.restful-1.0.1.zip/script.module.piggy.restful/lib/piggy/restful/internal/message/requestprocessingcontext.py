class RequestProcessingContext:
    def __init__(self):
        pass
