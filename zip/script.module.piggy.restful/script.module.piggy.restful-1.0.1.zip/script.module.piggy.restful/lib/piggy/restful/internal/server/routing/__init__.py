import inspect
from typing import Optional

from piggy.base.notation import AnnotatedElement, AnnotatedFunctionElement
from piggy.base.util import Objects
from piggy.restful.utils.annotationutils import AnnotationUtils
from ws.rs.core.uribuilder import UriBuilder
from ws.rs.path import Path


class Route:
    def __init__(self, name: str = None, template: bool = False):
        self.app = None
        self.cls = None
        self.fnc = None
        self.template = template
        self.segments = {}
        self.name = name

    def contains(self, c: str):
        return c in self.segments

    def next(self, c: str, template: bool = False):
        r = self.segments.get(c)
        if r is None:
            r = Route(c, template)
            self.segments[c] = r
        return r

    def get(self, c: str):
        return self.segments[c]

    def set(self, app: AnnotatedElement, element: AnnotatedElement, fnc: Optional[AnnotatedFunctionElement] = None):
        self.app = app
        self.cls = element
        self.fnc = fnc


class Router:
    SAFE = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789#$%&'()*+,"
    RESERVED = b"!/:;=?@[]"
    UNRESERVED = b"-_.~"

    def __init__(self):
        self.root = Route()
        
    def isSafe(self, c: int):
        if c in self.SAFE:
            return True
        if c in self.RESERVED:
            return True
        if c in self.UNRESERVED:
            return True
        return False

    def escape(self, c: int, bs: bytearray):
        h = c >> 4 & 0xF
        l = c & 0xF
        b = f'%{h:x}{l:x}'.upper()
        bs.extend(bytes(b, 'utf-8'))

    def encode(self, path: str):
        bts = bytes(path, 'utf-8')
        bs = bytearray()
        for b in bts:
            if not self.isSafe(b):
                self.escape(b, bs)
            else:
                bs.append(b)
        return bs.decode('utf-8')

    def route(self, path: str):
        if path is None or path == '/':
            return self.root
        current = self.root
        # make a simple normalization
        segments = path.split('/')
        for segment in segments:
            if not Objects.isEmpty(segment):
                if segment.startswith('{'):
                    current = current.next(segment, True)
                else:
                    current = current.next(self.encode(segment))
        return current

    def add(self, application, endpoint):

        uriBuilder = UriBuilder.newInstance().path(application).path(endpoint)
        path = uriBuilder.toTemplate()
        route = self.route(path)

        for name, member in inspect.getmembers(endpoint):
            if isinstance(member, AnnotatedFunctionElement):
                path = AnnotationUtils.getAnnotationValue(member, Path, None)
                if path:
                    path = uriBuilder.clone().path(path).toTemplate()
                    route = self.route(path)
                route.set(application, endpoint, member)

    def match(self, path: str):
        segments = path.split('/')
        current = self.root
        for segment in segments:
            if not Objects.isEmpty(segment):
                if current.contains(segment):
                    current = current.get(segment)
                else:
                    for k, r in current.segments.items():
                        if r.template:
                            current = r
                            break
        return current
