import inspect

from piggy.base import Raisable
from piggy.restful.internal.phase.server import ServerPhaseContext

from piggy.restful.internal.phase import Phase
from ws.rs.core.response import Response


class MethodProcessing(Phase):
    def apply(self, context: ServerPhaseContext):
        containerRequest = context.getRequestContext()
        routingContext = containerRequest.getUriRoutingContext()
        methodInvoker = routingContext.getResourceMethodInvoker()
        try:
            response:Response = methodInvoker.invoke(containerRequest)
        except Raisable as raisable:
            responder.process(raisable)