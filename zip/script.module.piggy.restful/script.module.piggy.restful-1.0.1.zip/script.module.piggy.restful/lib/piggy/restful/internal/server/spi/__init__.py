from typing import Type, TypeVar

from ws.rs.constrainedto import ConstrainedTo
from ws.rs.core.application import Application
from ws.rs.core.configuration import Configuration
from ws.rs.runtimetype import RuntimeType

from piggy.restful.internal.server.applicationhandler import ApplicationHandler


@ConstrainedTo(RuntimeType.SERVER)
class Container:
    def getConfiguration(self) -> Configuration:
        pass

    def getApplicationHandler(self) -> ApplicationHandler:
        pass

    def reload(self, configuration: Configuration):
        pass


CONTAINER_TYPE = TypeVar('CONTAINER_TYPE')


@ConstrainedTo(RuntimeType.SERVER)
class ContainerProvider:

    def createContainer(self, containerCls: Type[CONTAINER_TYPE], application: Application) -> CONTAINER_TYPE:
        pass
