from typing import Type

from ws.rs.core.application import Application
from ws.rs.core.configuration import Configuration

from piggy.restful.ext.serverruntime import ServerRuntime
from piggy.restful.internal.message.messagebodyworkers import MessageBodyWorkers
from piggy.restful.internal.server.applicationconfigurator import ApplicationConfigurator
from piggy.restful.internal.server.containerrequest import ContainerRequest


class ApplicationHandler:
    def __init__(self, application: Type[Application]):
        self.msgBodyWorkers: MessageBodyWorkers = None
        self.runtime: ServerRuntime = None
        self.application: Application = None
        self.configuration:Configuration = None
        self.initialize(ApplicationConfigurator(application))

    def initialize(self, configurator: ApplicationConfigurator):
        self.application = configurator.getApplication()
        self.runtime = configurator.getRuntime()
        self.configuration = configurator.getConfiguration()
        self.msgBodyWorkers = configurator.getMessageBodyWorkers()

    def handle(self, request: ContainerRequest):
        request.setWorkers(self.msgBodyWorkers)
        self.runtime.process(request)

    def getConfiguration(self):
        return self.configuration
