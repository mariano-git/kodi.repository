from enum import Enum

from ws.rs.processingexception import ProcessingException


class HeaderValueException(ProcessingException):
    class Context(Enum):
        INBOUND = 0
        OUTBOUND = 1

    def __init__(self, context: Context, *args):
        super().__init__(*args)
        self.context = context

    def getContext(self) -> Context:
        return self.context
