from typing import Set

from piggy.base import Raisable
from piggy.base.util.logging import Logger
from ws.rs.container.containerrequestfilter import ContainerRequestFilter
from ws.rs.container.prematching import PreMatching
from ws.rs.core.response import Response
from ws.rs.processingexception import ProcessingException

from piggy.restful.internal.phase import Phase
from piggy.restful.internal.phase.server import ServerPhaseContext


class PreMatchingRequestFiltering(Phase):
    __lg__ = Logger.getLogger(f'{__name__}.{__qualname__}')

    def apply(self, context: ServerPhaseContext):
        filters: Set[ContainerRequestFilter] = context.getBinder().getByContract(
            ContainerRequestFilter, lambda filter: filter.isAnnotationPresent(PreMatching)
        )
        for requestFilter in filters:
            self.__lg__.debug("Applying PreMatching filter: %s", requestFilter)
            requestContext = context.getRequestContext()
            try:
                requestFilter.filter(context.getRequestContext())
            except Raisable as raisable:
                raise ProcessingException(raisable)
            abortResponse: Response = requestContext.getAbortResponse()
            if abortResponse:
                context.setAbortResponse(abortResponse)
