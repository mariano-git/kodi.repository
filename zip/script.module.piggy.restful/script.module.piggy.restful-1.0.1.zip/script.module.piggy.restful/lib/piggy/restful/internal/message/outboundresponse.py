from typing import cast, Union, Type, List, Set

from piggy.base import IllegalStateException, UnsupportedOperationException, Overload, IllegalArgumentException
from piggy.base.io import IOException
from piggy.base.io.bytearrayoutputstream import ByteArrayOutputStream
from piggy.base.io.inputstream import InputStream
from piggy.base.net.uri import URI
from piggy.base.notation import Annotation
from piggy.base.util.date import Date
from piggy.base.util.locale import Locale
from piggy.base.util.map import Map
from piggy.restful.internal.message.outboundmessagecontext import OutboundMessageContext
from ws.rs.core.cachecontrol import CacheControl
from ws.rs.core.configuration import Configuration
from ws.rs.core.entitytag import EntityTag
from ws.rs.core.generictype import GenericType, T
from ws.rs.core.httpheaders import HttpHeaders
from ws.rs.core.link import Link
from ws.rs.core.mediatype import MediaType
from ws.rs.core.multivaluedmap import MultivaluedMap
from ws.rs.core.newcookie import NewCookie
from ws.rs.core.response import Response
from ws.rs.core.variant import Variant
from ws.rs.processingexception import ProcessingException


class OutboundResponse(Response):

    def __init__(self, status: Response.StatusType, context: OutboundMessageContext):
        self.__status__: Response.StatusType = status
        self.__context__: OutboundMessageContext = context
        self.__closed__: bool = False
        self.__buffered__: bool = False

    @staticmethod
    def of(response: Response, configuration: Configuration) -> 'OutboundResponse':
        if isinstance(response, OutboundResponse):
            outresp: OutboundResponse = cast(OutboundResponse, response)
            outresp.__context__.setConfiguration(configuration)
            return outresp
        else:
            status: Response.StatusType = response.getStatusInfo()
            context: OutboundMessageContext = OutboundMessageContext(configuration)
            context.getHeaders().putAll(response.getMetadata())
            context.setEntity(response.getEntity())
            return OutboundResponse(status, context)

    def getContext(self) -> OutboundMessageContext:
        return self.__context__

    def getStatus(self) -> int:
        return self.__status__.getStatusCode()

    def getStatusInfo(self) -> Response.StatusType:
        return self.__status__

    def getEntity(self) -> object:
        if self.__closed__:
            raise IllegalStateException('Already closed')
        return self.__context__.getEntity()

    def readEntity(self, entityType: Union[Type[T], GenericType[T]], annotations: List[Annotation] = None):
        raise IllegalStateException("Method not supported on an outbound message..")

    def hasEntity(self) -> bool:
        if self.__closed__:
            raise IllegalStateException('Already closed')
        return self.__context__.hasEntity()

    def bufferEntity(self) -> bool:
        if self.__closed__:
            raise IllegalStateException('Already closed')
        if not self.__context__.hasEntity() or not isinstance(self.__context__, InputStream):
            return False
        if self.__buffered__:
            return True

        entityStream: InputStream = self.__context__.getEntity()
        out: ByteArrayOutputStream = ByteArrayOutputStream()
        entityStream.transferTo(out)
        entityStream.close()
        self.__context__.setEntity(ByteArrayOutputStream(out.toBytes()))
        self.__buffered__ = True
        return True

    def close(self):
        self.__closed__ = True
        self.__context__.close()
        if self.__buffered__:
            self.__context__.setEntity(None)
        elif self.__context__.hasEntity() and issubclass(self.__context__.getEntityClass(), InputStream):
            try:
                self.__context__.close()
            except IOException as ex:
                raise ProcessingException(ex)

    def getStringHeaders(self) -> MultivaluedMap[str, str]:
        return self.__context__.getStringHeaders()

    def getHeaderString(self, name: str) -> str:
        return self.__context__.getHeaderString(name)

    def getMediaType(self) -> MediaType:
        return self.__context__.getMediaType()

    def getLanguage(self) -> Locale:
        return self.__context__.getLanguage()

    def getLength(self) -> int:
        return self.__context__.getLength()

    def getCookies(self) -> Map[str, NewCookie]:
        return self.__context__.getResponseCookies()

    def getEntityTag(self) -> EntityTag:
        return self.__context__.getEntityTag()

    def getEntityTag(self) -> EntityTag:
        return self.__context__.getEntityTag()

    def getDate(self) -> Date:
        return self.__context__.getDate()

    def getLastModified(self) -> Date:
        return self.__context__.getLastModified()

    def getAllowedMethods(self) -> Set[str]:
        return self.__context__.getAllowedMethods()

    def getLocation(self) -> URI:
        return self.__context__.getLocation()

    def getLinks(self) -> Set[Link]:
        return self.__context__.getLinks()

    def hasLink(self, relation: str) -> bool:
        return self.__context__.hasLink(relation)

    def getLink(self, relation: str) -> Link:
        return self.__context__.getLink(relation)

    def getLinkBuilder(self, relation: str) -> Link.Builder:
        return self.__context__.getLinkBuilder(relation)

    def getMetadata(self) -> MultivaluedMap[str, object]:
        return self.__context__.getHeaders()

    def toString(self) -> str:
        return f'OutboundResponse[' \
               f'status="{self.__status__.getStatusCode()}", ' \
               f'reason="{self.__status__.getReasonPhrase()}", ' \
               f'hasEntity="{self.__context__.hasEntity()}", ' \
               f'closed="{self.__closed__}", ' \
               f'buffered="{self.__buffered__}"]'

    class Builder(Response.ResponseBuilder):

        def __init__(self, context: OutboundMessageContext):
            self.__context__ = context

        @Overload
        def link(self, uri: str, rel: str) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("Not supported yet.")

        @Overload
        def link(self, uri: URI, rel: str) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("Not supported yet.")

        def language(self, language: Union[str, Locale]) -> Response.ResponseBuilder:
            self.headerSingle(HttpHeaders.CONTENT_LANGUAGE, language)
            return self

        def variant(self, variant: Variant) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("Not supported yet.")

        @Overload
        def tag(self, tag: str) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("Not supported yet.")

        @Overload
        def tag(self, tag: EntityTag) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("Not supported yet.")

        @Overload
        def variants(self, variants: List[Variant]) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("Not supported yet.")

        @Overload
        def variants(self, *variants: Variant) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("Not supported yet.")

        def type(self, mediaType: Union[MediaType, str]) -> Response.ResponseBuilder:
            if mediaType is None:
                return None
            if isinstance(mediaType, str):
                mediaType = MediaType.valueOf(mediaType)

            self.__context__.setMediaType(mediaType)
            return self

        def clone(self) -> Response.ResponseBuilder:
            return OutboundResponse.Builder(OutboundMessageContext(self.__context__)).status(self.__status__)

        def replaceAll(self, headers: MultivaluedMap[str, object]) -> Response.ResponseBuilder:
            self.__context__.replaceHeaders(headers)
            return self

        def status(self, *args) -> Response.ResponseBuilder:
            status = None
            code = None
            reason = None
            for arg in args:
                if isinstance(arg, int):
                    code = arg
                elif isinstance(arg, Response.StatusType) or isinstance(arg, Response.Status):
                    status = arg
                elif isinstance(arg, str):
                    reason = arg

            if code is not None:
                if code < 100 or code > 599:
                    raise IllegalArgumentException("Response status must not be less than '100' or greater than '599'")
            if code is not None and reason is not None:
                self.__status__ = Response.Status(code, reason)
                return self
            if code is not None and reason is None:
                self.__status__ = Response.Status.fromStatusCode(code)
                return self
            self.__status__ = status
            return self

        def encoding(self, encoding: str) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("Not supported yet.")

        def location(self, location: URI) -> Response.ResponseBuilder:
            locationUri: URI = location
            if location is not None and not location.isAbsolute():
                baseUri: URI = self.getBaseUri()
                if baseUri is not None:
                    locationUri = baseUri.resolve(location)

            self.headerSingle(HttpHeaders.LOCATION, locationUri)
            return self

        def build(self) -> Response:
            stat = self.__status__
            if stat is None:
                stat = Response.Status.OK if self.__context__.hasEntity() else Response.Status.NO_CONTENT
            return OutboundResponse(stat, OutboundMessageContext(self.__context__))

        def lastModified(self, lastModified: Date) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("Not supported yet.")

        def entity(self, entity: object, annotations: List[Annotation] = None) -> Response.ResponseBuilder:
            self.__context__.setEntity(entity, annotations)
            return self

        def header(self, name: str, value: object) -> Response.ResponseBuilder:
            return self._header_(name, value, False)

        def headerSingle(self, name: str, value: object) -> Response.ResponseBuilder:
            return self._header_(name, value, True)

        def _header_(self, name: str, value: object, single: bool) -> Response.ResponseBuilder:
            if value is not None:
                if single:
                    self.__context__.getHeaders().putSingle(name, value)
                else:
                    self.__context__.getHeaders().add(name, value)
            else:
                self.__context__.getHeaders().remove(name)
            return self

        @Overload
        def allow(self, *methods: str) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("Not supported yet.")

        @Overload
        def allow(self, methods: Set[str]) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("Not supported yet.")

        def cacheControl(self, cacheControl: CacheControl) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("Not supported yet.")

        def contentLocation(self, location: URI) -> Response.ResponseBuilder:
            raise UnsupportedOperationException("Not supported yet.")

        def cookie(self, *cookies: NewCookie) -> Response.ResponseBuilder:
            if cookies is not None:
                for cookie in cookies:
                    self.header(HttpHeaders.SET_COOKIE, cookie)
            else:
                self.header(HttpHeaders.SET_COOKIE, None)
            return self

        def expires(self, expires: Date) -> Response.ResponseBuilder:
            self.headerSingle(HttpHeaders.EXPIRES, expires)
            return self

        def links(self, *links: Link) -> Response.ResponseBuilder:
            if links is not None:
                for link in links:
                    self.header(HttpHeaders.LINK, link)
            else:
                self.header(HttpHeaders.LINK, None)
            return self
