from typing import Collection

from piggy.base import UnsupportedOperationException


class PropertiesDelegate:
    def getProperty(self, name: str) -> object:
        raise UnsupportedOperationException("Called on interface.")

    def getPropertyNames(self) -> Collection:
        raise UnsupportedOperationException("Called on interface.")

    def removeProperty(self, name: str):
        raise UnsupportedOperationException("Called on interface.")

    def setProperty(self, name: str, value: object):
        raise UnsupportedOperationException("Called on interface.")
