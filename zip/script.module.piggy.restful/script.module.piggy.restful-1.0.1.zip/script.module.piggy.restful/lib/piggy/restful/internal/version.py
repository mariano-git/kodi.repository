from piggy.restful import __version__, __build__


class Version:

    @staticmethod
    def getBuildId() -> int:
        return __build__

    @staticmethod
    def getVersion() -> str:
        return __version__