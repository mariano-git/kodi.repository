from ws.rs.processingexception import ProcessingException


class MessageBodyProviderNotFoundException(ProcessingException):
    pass
