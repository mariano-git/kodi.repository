class MediaType:
    APPLICATION_JSON = 'application/json'
    TEXT_PLAIN = 'text/plain'


class Response:
    def __init__(self, response):
        self.response = response
