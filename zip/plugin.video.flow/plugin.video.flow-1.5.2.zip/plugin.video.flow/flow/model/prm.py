class ConcurrencyRequest:
    pass


class ConcurrencyResponse:
    pass


class ContentSourceResponse:
    pass


class RegisterRequest:
    pass


class RegisterResponse:
    pass
