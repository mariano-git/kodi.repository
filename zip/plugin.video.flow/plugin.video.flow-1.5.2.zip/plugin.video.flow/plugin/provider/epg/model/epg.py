from piggy.restful.utils import SafeObject


class EpgResource(SafeObject):
    pass