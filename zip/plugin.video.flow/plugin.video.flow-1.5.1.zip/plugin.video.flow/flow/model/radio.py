from piggy.restful.utils import SafeObject


class RadioStations(SafeObject):
    pass


class RadioConfig(SafeObject):
    pass


class RadioStation(SafeObject):
    pass


class RadioPrograms(SafeObject):
    pass
