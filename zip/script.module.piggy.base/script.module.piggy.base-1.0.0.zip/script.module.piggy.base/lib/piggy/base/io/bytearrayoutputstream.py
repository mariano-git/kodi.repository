from typing import Union, cast

from piggy.base.io.outputstream import OutputStream
from piggy.base.util import Objects


class ByteArrayOutputStream(OutputStream):
    __MAX_BUFFER_SIZE__ = 0xFFFFFFFF

    def __init__(self):
        self.buffer: bytearray = bytearray()

    def write(self, bs: Union[int, bytes], off: int = None, length: int = None):
        if isinstance(bs, int) and off is None and length is None:
            self.buffer.append(bs)
            return

        buffer = memoryview(cast(bytes, bs))
        if off is None and length is None:
            off = 0
            length = len(buffer)
        Objects.checkFromIndexSize(off, length, len(buffer))
        self.buffer.extend(buffer[off:length])

    def writeBytes(self, b: bytes):
        self.write(b, 0, len(b))

    def writeTo(self, out: OutputStream):
        out.write(self.buffer, 0, len(self.buffer))

    def reset(self):
        self.buffer = bytearray()

    def toBytes(self) -> bytes:
        return bytes(self.buffer)

    def size(self) -> int:
        return len(self.buffer)

    def toString(self, charset: str = 'utf-8') -> str:
        return self.buffer.decode(charset)

    def close(self):
        pass
