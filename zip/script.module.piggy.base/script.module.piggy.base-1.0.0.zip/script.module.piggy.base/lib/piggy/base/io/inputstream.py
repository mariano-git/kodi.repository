from typing import Final

from piggy.base import UnsupportedOperationException, Overload, IllegalArgumentException
from piggy.base.io import Closeable, IOException
from piggy.base.io.outputstream import OutputStream
from piggy.base.util import Objects
from piggy.base.util.logging import Logger


class InputStream(Closeable):
    __lg__ = Logger.getLogger(f'{__name__}.{__qualname__}')
    MAX_SKIP_BUFFER_SIZE: Final[int] = 2048
    DEFAULT_BUFFER_SIZE: Final[int] = 8192
    MAX_BUFFER_SIZE: Final[int] = 0xFFFFFFFF

    def read(self, b: bytearray = None, off: int = None, length: int = None) -> int:
        if b is None and off is None and length is None:
            raise UnsupportedOperationException("This method is abstract and must be overridden.")
        if b is not None and off is None and length is None:
            off = 0
            length = len(b)
        if length == 0:
            return 0

        Objects.checkFromIndexSize(off, length, len(b))

        c: int = self.read()
        if c == -1:
            return -1
        b[off] = c
        i: int = 1
        try:
            while i < length:
                c = self.read()
                if c == -1:
                    break
                b[off + i] = c
                i += 1
        except IOException as ee:
            pass

        return i

    def readAllBytes(self):
        return self.readNBytes(InputStream.MAX_BUFFER_SIZE)

    @Overload
    def readNBytes(self, length: int) -> bytes:
        if length < 0:
            raise IllegalArgumentException("length < 0")
        remaining: int = length
        capacity = self.DEFAULT_BUFFER_SIZE * 2
        buffer = bytearray(capacity)
        read: int = 0
        do = read >= 0
        index: int = 0
        size = capacity

        while do:
            read = self.read(buffer, index, size)
            do = read > 0

            if do:
                remaining -= read
                index += read
                grow = index + size
                if grow >= capacity:
                    buffer.extend(bytearray(min(remaining, capacity << 1)))
                    capacity = len(buffer)
                if remaining <= 0:
                    do = False

        return bytes(buffer[0:index + read + 1])

    @Overload
    def readNBytes(self, b: bytearray, off: int, length: int) -> int:
        Objects.checkFromIndexSize(off, length, len(b))

        n: int = 0
        while n < length:
            count: int = self.read(b, off + n, length - n)
            if count < 0:
                break
            n += count

        return n

    def skip(self, n: int):
        remaining: int = n
        nr: int
        if n <= 0:
            return 0
        size: int = min(InputStream.MAX_SKIP_BUFFER_SIZE, remaining)
        skipBuffer: bytearray = bytearray(size)
        while remaining > 0:
            nr = self.read(skipBuffer, 0, min(size, remaining))
            if nr < 0:
                break
        return n - remaining

    def available(self):
        return 0

    def close(self):
        pass

    def mark(self, readLimit: int):
        pass

    def reset(self):
        raise IOException("mark/reset not supported")

    def markSupported(self) -> bool:
        return False

    def transferTo(self, out: OutputStream) -> int:
        Objects.requireNonNull(out, "out")
        transferred: int = 0
        buffer: bytearray = bytearray(InputStream.DEFAULT_BUFFER_SIZE)
        read: int = 0
        do = read >= 0
        while do:
            read = self.read(buffer, 0, InputStream.DEFAULT_BUFFER_SIZE)
            do = read >= 0
            if do:
                transferred += read

        return transferred

    @classmethod
    def nullInputStream(cls) -> 'InputStream':
        class NullInputStream(InputStream):
            def __init__(self):
                self.closed = False

            def ensureOpen(self):
                if self.closed:
                    raise IOException("Stream closed")

            def available(self):
                self.ensureOpen()
                return 0

            @Overload
            def read(self) -> int:
                self.ensureOpen()
                return -1

            @Overload
            def read(self, b: bytearray) -> int:
                return self.read(b, 0, len(b))

            @Overload
            def read(self, b: bytearray, off: int, lenght: int):
                Objects.checkFromIndexSize(off, lenght, len(b))
                if lenght == 0:
                    return 0
                self.ensureOpen()
                return -1

            def readAllBytes(self) -> bytes:
                self.ensureOpen()
                return bytes()

            @Overload
            def readNBytes(self, b: bytearray, off, int, length: int) -> int:
                Objects.checkFromIndexSize(off, length, len(b))
                self.ensureOpen()
                return 0

            @Overload
            def readNBytes(self, length: int) -> bytes:
                if length < 0:
                    raise IllegalArgumentException("len < 0")

                self.ensureOpen()
                return bytes()

            def skip(self, n: int) -> int:
                self.ensureOpen()
                return 0

            def transferTo(self, out: OutputStream) -> int:
                Objects.requireNonNull(out)
                self.ensureOpen()
                return 0

            def close(self):
                self.closed = True

        return NullInputStream()
