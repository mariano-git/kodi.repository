from typing import Union, cast

from piggy.base import UnsupportedOperationException
from piggy.base.io import Closeable, Flushable, IOException
from piggy.base.util import Objects


class OutputStream(Closeable, Flushable):
    def close(self):
        pass

    def flush(self):
        pass

    def write(self, bs: Union[int, bytes], off: int = None, length: int = None):
        if isinstance(bs, int) and off is None and length is None:
            raise UnsupportedOperationException("This method is abstract and must be overridden.")
        buffer = cast(bytes, bs)
        if off is None and length is None:
            self.write(buffer, 0, len(buffer))
        Objects.checkFromIndexSize(off, length, len(buffer))
        for i in range(off, length):
            self.write(buffer[off + i])

    @staticmethod
    def nullOutputStream() -> 'OutputStream':
        class NullOutputStream(OutputStream):
            def __init__(self):
                self.__closed__ = False

            def _ensureOpen(self):
                if self.__closed__:
                    raise IOException('Stream closed')

            def write(self, b: Union[int, bytes], off: int = None, length: int = None):
                self._ensureOpen()
                if isinstance(b, int):
                    pass
                buffer = cast(bytes, b)
                if off is None and length is None:
                    off = 0
                    length = len(buffer)
                Objects.checkFromIndexSize(off, length, len(buffer))

            def close(self):
                self.__closed__ = True

        return NullOutputStream()
