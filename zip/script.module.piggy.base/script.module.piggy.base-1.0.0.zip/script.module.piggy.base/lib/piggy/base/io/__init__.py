from piggy.base import UnsupportedOperationException, Raisable, raisable


class AutoCloseable:
    def close(self):
        raise UnsupportedOperationException("Called on interface.")


class Closeable(AutoCloseable):
    def close(self):
        raise UnsupportedOperationException("Called on interface.")


class Flushable:
    def flush(self):
        raise UnsupportedOperationException("Called on interface.")


@raisable
class IOException(Raisable):
    pass
