import sys
from types import TracebackType


class Raisable(BaseException):
    def __init__(self, *args):
        super().__init__(*args)
        self.__message__ = None
        for arg in args:
            if isinstance(arg, str):
                self.__message__ = arg
                continue
            if isinstance(arg, Raisable) and self.__cause__ is None:
                self.__cause__ = arg
                continue
            if isinstance(arg, BaseException) and self.__cause__ is None:
                self.__cause__ = arg
                continue
            if isinstance(arg, TracebackType):
                self.__traceback__ = arg
        if self.__message__ is None:
            self.__message__ = self.__cause__.getMessage() if self.__cause__ and isinstance(
                self.__cause__, Raisable) else str(self.__context__)

    def getCause(self) -> 'Raisable':
        return self.__cause__ if self.__cause__ else self.__context__

    def getMessage(self) -> str:
        return self.__message__

    def toString(self) -> str:
        return f'{self.getMessage()} - {self.__class__}'


def raisable(cls):
    def init(self, *args):
        frame = sys._getframe().f_back
        f = False
        for arg in args:
            if isinstance(arg, TracebackType):
                f = True
                break
        if not f:
            a = list(args)
            a.append(frame)
            args = tuple(a)
        super().__init__(*args)

    members = {}
    className = cls.__name__
    skip = ['__bases__', '__mro__', '__base__', '__class__', '__slots__']
    slots = getattr(cls, '__slots__', None)
    if slots:
        skip.extend(slots)

    for key in dir(cls):
        if key not in skip:
            value = getattr(cls, key, None)
            members[key] = value
    clsBases = getattr(cls, '__bases__', [])

    delegate = type(className, tuple(clsBases), members)
    if '__init__' not in members:
        delegate.__init__ = init
    return delegate


@raisable
class NullPointerException(Raisable):
    pass


@raisable
class ClassNotFoundException(Raisable):
    pass


@raisable
class RuntimeException(Raisable):
    pass


@raisable
class IllegalArgumentException(RuntimeException):
    pass


@raisable
class IllegalStateException(RuntimeException):
    pass


@raisable
class IndexOutOfBoundsException(RuntimeException):
    __slots__ = '__idx__'

    def getIndex(self) -> int:
        return self.__idx__


@raisable
class NoSuchElementException(RuntimeException):
    pass


@raisable
class UnsupportedOperationException(RuntimeException):
    pass


@raisable
class InterruptedException(RuntimeException):
    pass


@raisable
class ParseException(RuntimeException):
    __slots__ = '__offset__'

    def __custom__(self, offset: int):
        return f'Parse error on offset: {offset}',

    def getErrorOffset(self) -> int:
        return self.__offset__
