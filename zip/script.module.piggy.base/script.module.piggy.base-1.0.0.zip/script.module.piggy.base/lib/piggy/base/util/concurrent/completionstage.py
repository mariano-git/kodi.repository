from typing import Generic, TypeVar

V= TypeVar('V')
class CompletionStage(Generic[V]):
    pass