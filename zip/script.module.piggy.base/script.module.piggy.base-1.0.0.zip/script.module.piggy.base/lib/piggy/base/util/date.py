import datetime
from typing import Optional


class Date:
    def __init__(self, millis: Optional[int] = None):
        self.millis = millis if millis is not None else int(datetime.datetime.now().timestamp() * 1000)

    def getTime(self) -> int:
        return self.millis

    def setTime(self, millis):
        self.millis = millis

    def before(self, when: 'Date') -> bool:
        return self.getTime() < when.getTime()

    def after(self, when: 'Date') -> bool:
        return self.getTime() > when.getTime()
