from __future__ import annotations

from typing import Callable, Any

from piggy.base.util import Objects


class Conditional:
    EMPTY: Conditional = None

    def __init__(self, value: Any = None):
        self.value = None
        if value:
            self.value = value

    @staticmethod
    def empty():
        return Conditional.EMPTY

    @staticmethod
    def of(value) -> Conditional:
        return Conditional(value)

    @staticmethod
    def ofNullable(value) -> Conditional:
        return Conditional.empty() if value is None else Conditional.of(value)

    def get(self) -> Any:
        Objects.requireNonNull(self.value, 'No value present')
        return self.value

    def isPresent(self) -> bool:
        return self.value is not None

    def isEmpty(self) -> bool:
        return self.value is None

    def ifPresent(self, action: Callable):
        if self.isPresent():
            action(self.value)

    def ifPresentRaise(self, exception: Exception) -> Conditional:
        if self.isPresent():
            raise exception
        return self

    def ifPresentOrElse(self, ifPresent: Callable, ifEmpty: Callable):
        if self.value:
            ifPresent(self.value)
        else:
            ifEmpty()

    # Callable[[arg, ...], result]
    def filter(self, predicate: Callable[[...], bool]):
        Objects.requireNonNull(predicate)
        if not self.isPresent():
            return self
        else:
            return self if predicate(self.value) else self.empty

    def map(self, mapper: Callable) -> Conditional:
        Objects.requireNonNull(mapper)
        if not self.isPresent():
            return Conditional.EMPTY
        return Conditional.ofNullable(mapper(self.value))

    def flatMap(self, mapper: Callable) -> Conditional:
        Objects.requireNonNull(mapper)
        if not self.isPresent():
            return Conditional.EMPTY
        optional = mapper(self.value)  # this should return a provided Conditional
        return Objects.requireNonNull(optional)

    def orElse(self, other: Any) -> Any:
        return self.value if self.value else other

    def orElseSupply(self, supplier: Callable) -> Any:
        return self.value if self.value else Objects.requireNonNull(supplier())

    def orConditional(self, supplier: Callable) -> Conditional:
        if self.isPresent():
            return self
        return Conditional.ofNullable(supplier())

    def orElseRaise(self, supplier: Callable[[], Exception]):
        if self.isPresent():
            return self.value
        raise supplier()


Conditional.EMPTY = Conditional()
