from __future__ import annotations

import sys

from piggy.base import IllegalArgumentException


class TimeUnit:
    MAX_VALUE = sys.maxsize
    MIN_VALUE = -sys.maxsize - 1
    NANO_SCALE: int = 1
    MICRO_SCALE: int = 1000 * NANO_SCALE
    MILLI_SCALE: int = 1000 * MICRO_SCALE
    SECOND_SCALE: int = 1000 * MILLI_SCALE
    MINUTE_SCALE: int = 60 * SECOND_SCALE
    HOUR_SCALE: int = 60 * MINUTE_SCALE
    DAY_SCALE: int = 24 * HOUR_SCALE

    NANOSECONDS: TimeUnit
    MICROSECONDS: TimeUnit
    MILLISECONDS: TimeUnit
    SECONDS: TimeUnit
    MINUTES: TimeUnit
    HOURS: TimeUnit
    DAYS: TimeUnit

    def __init__(self, s: int, name: str):
        self._name_ = name
        self.scale = s
        self.maxNanos = TimeUnit.MAX_VALUE / s
        # ur: int = (s >= TimeUnit.MICRO_SCALE) ? (s / TimeUnit.MICRO_SCALE): (TimeUnit.MICRO_SCALE / s)
        ur: int = int((s / TimeUnit.MICRO_SCALE) if (s >= TimeUnit.MICRO_SCALE) else (TimeUnit.MICRO_SCALE / s))
        self.microRatio = ur
        self.maxMicros = TimeUnit.MAX_VALUE / ur
        # mr: int = (s >= TimeUnit.MILLI_SCALE) ? (s / TimeUnit.MILLI_SCALE): (TimeUnit.MILLI_SCALE / s)
        mr: int = int((s / TimeUnit.MILLI_SCALE) if (s >= TimeUnit.MILLI_SCALE) else (TimeUnit.MILLI_SCALE / s))
        self.milliRatio = mr
        self.maxMillis = TimeUnit.MAX_VALUE / mr
        # sr: int = (s >= TimeUnit.SECOND_SCALE) ? (s / TimeUnit.SECOND_SCALE): (TimeUnit.SECOND_SCALE / s)
        sr: int = int((s / TimeUnit.SECOND_SCALE) if (s >= TimeUnit.SECOND_SCALE) else (TimeUnit.SECOND_SCALE / s))
        self.secRatio = sr
        self.maxSecs = TimeUnit.MAX_VALUE / sr

    @staticmethod
    def cvt(d: int, dst: int, src: int):
        r: int
        m: int
        if src == dst:
            return d
        elif src < dst:
            return d / (dst / src)
        r = int(src / dst)
        m = TimeUnit.MAX_VALUE
        if d > (m / r):
            return TimeUnit.MAX_VALUE

        elif d < -m:
            return TimeUnit.MIN_VALUE
        else:
            return d * r

    def toNanos(self, duration: int):
        s = self.scale
        m = self.maxNanos
        if s == TimeUnit.NANO_SCALE:
            return duration
        elif duration > m:
            return TimeUnit.MAX_VALUE

        elif duration < -m:
            return TimeUnit.MIN_VALUE
        else:
            return duration * s

    def toMicros(self, duration: int):
        s = self.scale
        m = self.maxMicros
        if s <= TimeUnit.MICRO_SCALE:
            return duration if s == TimeUnit.MICRO_SCALE else duration / self.microRatio
        elif duration > m:
            return TimeUnit.MAX_VALUE
        elif duration < -m:
            return TimeUnit.MIN_VALUE
        else:
            return duration * self.microRatio

    def toMillis(self, duration: int):
        s = self.scale
        m = self.maxMillis
        if s <= TimeUnit.MILLI_SCALE:
            return duration if s == TimeUnit.MILLI_SCALE else duration / self.milliRatio
        elif duration > m:
            return TimeUnit.MAX_VALUE
        elif duration < -m:
            return TimeUnit.MIN_VALUE
        else:
            return duration * self.milliRatio

    def toSeconds(self, duration: int):
        s = self.scale
        m = self.maxSecs
        if s <= TimeUnit.SECOND_SCALE:
            return duration if s == TimeUnit.SECOND_SCALE else duration / self.secRatio
        elif duration > m:
            return TimeUnit.MAX_VALUE
        elif duration < -m:
            return TimeUnit.MIN_VALUE
        else:
            return duration * self.secRatio

    def toMinutes(self, duration: int):
        return TimeUnit.cvt(duration, TimeUnit.MINUTE_SCALE, self.scale)

    def toHours(self, duration: int):
        return TimeUnit.cvt(duration, TimeUnit.HOUR_SCALE, self.scale)

    def toDays(self, duration: int):
        return TimeUnit.cvt(duration, TimeUnit.DAY_SCALE, self.scale)

    def convert(self, sourceDuration: int, sourceUnit: TimeUnit):
        if self == TimeUnit.NANOSECONDS: return sourceUnit.toNanos(sourceDuration)
        if self == TimeUnit.MICROSECONDS: return sourceUnit.toMicros(sourceDuration)
        if self == TimeUnit.MILLISECONDS: return sourceUnit.toMillis(sourceDuration)
        if self == TimeUnit.SECONDS:      return sourceUnit.toSeconds(sourceDuration)
        return self.cvt(sourceDuration, self.scale, sourceUnit.scale)

    def name(self):
        return self._name_

    @staticmethod
    def valueOf(name: str) -> TimeUnit:
        if name == 'NANOSECONDS': return TimeUnit.NANOSECONDS
        if name == 'MICROSECONDS': return TimeUnit.MICROSECONDS
        if name == 'MILLISECONDS': return TimeUnit.MILLISECONDS
        if name == 'SECONDS': return TimeUnit.SECONDS
        if name == 'MINUTES': return TimeUnit.MINUTES
        if name == 'HOURS': return TimeUnit.HOURS
        if name == 'DAYS': return TimeUnit.DAYS

        raise IllegalArgumentException(f'no constant: {name}')

    @classmethod
    def values(cls):
        return frozenset({TimeUnit.NANOSECONDS,
                          TimeUnit.MICROSECONDS,
                          TimeUnit.MILLISECONDS,
                          TimeUnit.SECONDS,
                          TimeUnit.MINUTES,
                          TimeUnit.HOURS,
                          TimeUnit.DAYS})


TimeUnit.NANOSECONDS = TimeUnit(TimeUnit.NANO_SCALE, 'NANOSECONDS')
TimeUnit.MICROSECONDS = TimeUnit(TimeUnit.MICRO_SCALE, 'MICROSECONDS')
TimeUnit.MILLISECONDS = TimeUnit(TimeUnit.MILLI_SCALE, 'MILLISECONDS')
TimeUnit.SECONDS = TimeUnit(TimeUnit.SECOND_SCALE, 'SECONDS')
TimeUnit.MINUTES = TimeUnit(TimeUnit.MINUTE_SCALE, 'MINUTES')
TimeUnit.HOURS = TimeUnit(TimeUnit.HOUR_SCALE, 'HOURS')
TimeUnit.DAYS = TimeUnit(TimeUnit.DAY_SCALE, 'DAYS')
