from types import MappingProxyType
from typing import Set, List, Dict

from piggy.base.util.map import Map
from piggy.base.util.simplemap import SimpleMap


class Collections:

    @classmethod
    def unmodifiableMap(cls, map):
        # FIXME This isn't a real inmutable
        return map

    @classmethod
    def unmodifiableSet(cls, theSet: Set):
        # FIXME This is immutable but it cost a lot
        return frozenset(theSet)

    @classmethod
    def unmodifiableList(cls, theList: List):
        # FIXME This is immutable but it cost a lot
        return tuple(theList)

    @classmethod
    def emptyList(cls):
        # FIXME This is immutable but it cost a lot
        return cls.unmodifiableList(list())

    @classmethod
    def emptySet(cls):
        # FIXME This is immutable but it cost a lot
        return cls.unmodifiableSet(set())

    @classmethod
    def unmodifiableDict(cls, theDict: Dict):
        # finally a real wrapper...
        return MappingProxyType(theDict)

    @classmethod
    def emptyDict(cls):
        return cls.unmodifiableDict(dict())

    @classmethod
    def emptyMap(cls):
        return SimpleMap()
