from datetime import datetime as DateTime

from piggy.base.util.date import Date


class SimpleDateFormat:
    def __init__(self, strFormat: str):
        self.dateFormat = strFormat

    def format(self, date: Date):
        dt = DateTime.fromtimestamp(float(date.getTime() / 1000)).astimezone()
        return dt.strftime(self.dateFormat)
