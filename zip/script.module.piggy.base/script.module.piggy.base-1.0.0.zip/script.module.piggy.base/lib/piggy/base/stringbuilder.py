from __future__ import annotations

from typing import Optional, Union

from piggy.base import Overload


class StringBuilder:
    __slots__ = '__buff__'

    def __init__(self, value: Optional[Union[int, str]] = None):
        if value:
            if isinstance(value, str):
                self.__buff__ = bytearray(value, 'UTF-8')
            else:
                self.__buff__ = bytearray(value)
        else:
            self.__buff__ = bytearray()

    @Overload
    def append(self, string: str) -> StringBuilder:
        if string:
            self.__buff__ += string.encode('UTF-8')
        else:
            self.__buff__ += 'None'.encode('UTF-8')
        return self

    @Overload
    def append(self, sb: StringBuilder) -> StringBuilder:
        self.append(sb.toString())
        return self

    @Overload
    def append(self, s: str, start: int, end: int) -> StringBuilder:
        self.append(s[start:end])
        return self

    @Overload
    def append(self, b: bool) -> StringBuilder:
        self.append(str(b))
        return self

    @Overload
    def append(self, i: int) -> StringBuilder:
        self.append(str(i))
        return self

    @Overload
    def append(self, f: float) -> StringBuilder:
        self.append(str(f))
        return self

    @Overload
    def append(self, obj: object) -> StringBuilder:
        return self.append(obj.toString() if hasattr(obj, 'toString') else str(obj))

    def charAt(self, index: int) -> str:
        string = self.toString()

        return string[index]

    def length(self):
        return len(self.__buff__)

    def toString(self):
        return self.__buff__.decode('utf-8')
