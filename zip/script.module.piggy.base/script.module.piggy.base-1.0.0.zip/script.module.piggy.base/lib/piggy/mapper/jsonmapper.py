import inspect
import json
import typing
from io import StringIO, TextIOWrapper
from typing import Any, Union, _GenericAlias

from piggy.base import UnsupportedOperationException
from piggy.base.io.inputstream import InputStream
from piggy.base.io.outputstream import OutputStream
from piggy.restful.utils import SafeObject

T = typing.TypeVar('T')


class JsonMapper:
    """
    Really basic and silly JsonMapper ala Jackson style...
    """

    # FIXME Make JsonMapper use a configurable crutch Object?
    class Object(SafeObject):
        pass

    class WriterMapper:
        def _convertComplex(self, value):
            simple = dict()
            members = inspect.getmembers(value)
            for name, member in members:
                if not name.startswith('_'):  # avoid anything starting with protected private patterns
                    if inspect.ismethod(member) or inspect.isfunction(member):
                        # TODO: honors only "get" and "is" pattern eventually add annotations
                        if name.startswith('get_'):
                            name = name.replace('get_', '', 1)
                        elif name.startswith('is_'):
                            name = name.replace('is_', '', 1)
                        elif name.startswith('is'):
                            tmp = name.replace('is', '', 1)
                            name = tmp[:1].lower() + tmp[1:]
                        elif name.startswith('get'):
                            tmp = name.replace('get', '', 1)
                            name = tmp[:1].lower() + tmp[1:]
                        try:
                            v = member()
                        except BaseException as be:
                            # ignore for now
                            raise be
                    else:
                        v = member
                    simple[name] = self._convert(v)

            return simple

        def _convertStructured(self, value):
            if isinstance(value, dict):
                simple = dict()
                for k, v in value.items():
                    simple[self._convert(k)] = self._convert(v)
                return simple
            if isinstance(value, list) or \
                    isinstance(value, set) or \
                    isinstance(value, tuple) or isinstance(value, range):
                simple = list()
                for v in value:
                    simple.append(self._convert(v))
                return simple
            return self._convertComplex(value)

        def _convertBin(self, value):
            # Binary Types:	bytes, bytearray, memoryview
            if isinstance(value, bytes) or isinstance(value, bytearray):
                return value.decode("utf-8")
            if isinstance(value, memoryview):
                return value.tobytes().decode("utf-8")
            return self._convertStructured(value)

        def _convertSimple(self, value):
            '''
            Numeric Types:	int, float, complex
            Boolean Type:	bool
            None Type:	NoneType
            '''
            if isinstance(value, type(None)) or \
                    isinstance(value, str) or \
                    isinstance(value, int) or \
                    isinstance(value, float) or \
                    isinstance(value, complex) or \
                    isinstance(value, bool):
                return value
            else:
                return self._convertBin(value)

        def _convert(self, value):
            objDict = getattr(value, 'to_dict', None)
            if objDict is not None:
                return objDict

            objDict = getattr(value, 'toDict', None)
            if hasattr(value, 'to_dict'):
                if objDict is not None:
                    return objDict
            return self._convertSimple(value)

        def write(self, out, value):
            theJson = self._convert(value)
            # Can we export json without json?
            if isinstance(out, TextIOWrapper):
                out.write(str(theJson).replace("'", '"'))
            else:
                out.write(str(str(theJson)).replace("'", '"').encode('utf-8'))

    class ReaderMapper:
        def readIterable(self, data, cls, args):

            elements = cls()

            for value in data:
                value = self.read(value, args[0]) if args else self.read(value, type(value))
                elements.add(value) if cls is set else elements.append(value)
            return elements

        def readComplex(self, cls, data):

            # WARNING this could be disabled
            hints = typing.get_type_hints(cls)

            if not hints:
                # Going low level just in case and return an empty dict
                hints = getattr(cls, '__annotations__', {})

            instance = object.__new__(cls)
            for k, v in data.items():
                hint = hints.get(k)
                setattr(instance, k, self.read(v, hint if hint else type(v)))
            return instance

        def readDict(self, data, args):
            dct = dict()
            kCls = None
            vCls = None
            if args is not None:
                kCls = args[0]
                vCls = args[1]
            for k, v in data.items():
                key, value = None, None
                if kCls is not None:
                    key = self.read(k, kCls)
                else:
                    key = self.read(k, type(k))
                if vCls is not None:
                    value = self.read(v, vCls)
                else:
                    value = self.read(v, type(v))
                dct[key] = value
            return dct

        def readObject(self, data):
            # FIXME Make JsonMapper use a configurable crutch Object
            class crutch(SafeObject):
                def isEmpty(self) -> bool:
                    return not self.__dict__

            o = crutch()
            for k, v in data.items():
                value = self.read(v, type(v))
                setattr(o, k, value)

            return o

        def read(self, data: object, cls: Any, args=None, fromOrigin=False) -> Any:

            if isinstance(cls, _GenericAlias):
                origin = typing.get_origin(cls)
                args = typing.get_args(cls)
                # json only works with list, but typing could tell us to work with a set
                if (origin is set or origin is list and isinstance(data, list)) or isinstance(data, origin):
                    return self.read(data, origin, args, True)
                else:
                    return self.read(data, origin, args, False)
            if cls is list or cls is set and isinstance(data, list) or isinstance(data, set):
                return self.readIterable(data, cls, args)
            # return dict only and just only if we're requested to do it "very" explicitly
            if cls is dict and isinstance(data, dict) and fromOrigin:
                return self.readDict(data, args)
            if cls is dict and isinstance(data, dict) and not fromOrigin:
                return self.readObject(data)
            if cls is str and isinstance(data, str):
                return data
            if cls is int and isinstance(data, int):
                return data
            if cls is float and isinstance(data, float):
                return data
            if cls is complex and isinstance(data, complex):
                return data
            if cls is bool and isinstance(data, bool):
                return data
            if cls is bytes and isinstance(data, bytes) or cls is bytearray and isinstance(data, bytearray):
                # FIXME check this
                return data.decode("utf-8")
            try:
                if issubclass(cls, object) and isinstance(data, dict):
                    return self.readComplex(cls, data)
            except TypeError as t:
                raise UnsupportedOperationException(f"Operation not supported:{cls} for data: {data}", t)
            if cls is type(None) and data is None:
                return None
            raise UnsupportedOperationException(f"Type not supported:{cls} for data: {data}")

    def readValue(self, data: Union[dict, str, typing.TextIO, InputStream], cls) -> Any:
        reader = JsonMapper.ReaderMapper()

        if isinstance(data, TextIOWrapper):
            v = json.load(data)
            return reader.read(v, cls)
        if isinstance(data, str):
            v = json.loads(data)
            return reader.read(v, cls)
        if isinstance(data, dict):
            return reader.read(data, cls)
        else:
            # FIXME: Improve this...
            class StrIo(StringIO):
                def __init__(self, data: InputStream):
                    self.data = data

                def read(self, *args, **kwargs):
                    test = self.data.readAllBytes()

                    return test

            v = json.load(StrIo(data))
            return reader.read(v, cls)

    def readValues(self, cls: typing.Type[T], **kwargs) -> T:
        reader = JsonMapper.ReaderMapper()
        return reader.read(kwargs, cls)

    def writeValue(self, out: Union[typing.TextIO, OutputStream], value: object):
        writer = JsonMapper.WriterMapper()
        writer.write(out, value)
