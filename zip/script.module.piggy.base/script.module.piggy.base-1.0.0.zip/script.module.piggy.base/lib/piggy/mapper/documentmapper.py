import typing
from types import FunctionType
from typing import Union, Any, _GenericAlias
from xml.etree import ElementTree as Document
from xml.etree.ElementTree import Element

from piggy.base.io.inputstream import InputStream

'''
Very, very hacky class or just a very early WIP
'''


class DocumentMapper:
    class ReaderMapper:
        def readElement(self, element, cls):
            # WARNING this could be disabled
            hints = typing.get_type_hints(cls)

            if not hints:
                # Going low level just in case and return an empty dict
                hints = getattr(cls, '__annotations__', {})

            instance = object.__new__(cls)

            # hints of type list or set maps elements with same name in the same level
            # hints of any other type maps elements or attributes. (To define)
            # text element to attribute text
            attrElem = dict()
            for name, hint in hints.items():
                if isinstance(hint, _GenericAlias):
                    origin = typing.get_origin(hint)
                    args = typing.get_args(hint)
                    if len(args) == 1:
                        collection = None
                        if origin is set:
                            collection = set()
                            action = collection.add
                        elif origin is list:
                            collection = list()
                            action = collection.append
                        setattr(instance, name, collection)
                        clsName = args[0].__name__
                        attrElem[clsName.lower()] = (action, args[0])
                        # element tag and class must have the same name.
                        # extends with annotations but for now this is enough
                # Big Big hack. This is because Python is problematic with names containing minus sign,
                # Eg: display-name is unmappable conventionally
                elif isinstance(hint, FunctionType) and getattr(hint, '__supertype__', None) is not None:
                    sp = hint.__supertype__
                    clsName = sp.__name__
                    attrElem[hint.__name__.lower()] = (name, sp)
                else:
                    # plain class
                    clsName = hint.__name__
                    attrElem[clsName.lower()] = (name, hint)

            for child in element:
                assign = attrElem.get(child.tag.lower())
                if assign:
                    action, cls = assign
                    if isinstance(action, str):
                        setattr(instance, action, self.read(child, cls))
                    else:
                        action(self.read(child, cls))
                else:
                    # FIXME: Do we need this?
                    pass

            for k, v in element.attrib.items():
                setattr(instance, k, v)

            # finally text element, to attribute text
            # Eventually we could map it using the same hack for unmappable names?
            text = element.text if element.text is not None and len(element.text.strip()) > 0 else None
            setattr(instance, 'text', text)

            return instance

        def read(self, v, cls):

            if isinstance(v, Document.ElementTree):
                root = v.getroot()
                return self.read(root, cls)
            if isinstance(v, Element):
                return self.readElement(v, cls)

    def readDocument(self, data: Union[str, InputStream], cls, elements: typing.Optional[str] = None) -> Any:
        reader = DocumentMapper.ReaderMapper()
        document = None
        if isinstance(data, str):
            document = Document.parse(data)
        return reader.read(document, cls)
