import inspect
from enum import Enum
from types import FunctionType
from typing import Type, List, Any, Callable, Set

# FIXME Evaluate if it's better to convert all elements with metadata
from piggy.base.util.logging import Logger


class PiggyMetadata:
    __lg__ = Logger.getLogger(f'{__name__}.{__qualname__}')
    ARG_INFO = 'annotation.argument.information'
    TARGET = 'annotation.target'
    TARGET_ON_NEW = 'annotation.target.on.new'

    @staticmethod
    def of(element: Any):
        PiggyMetadata.__lg__.debug('of (element: %s)', element)
        metadata = getattr(element, 'piggy.metadata', None)
        if metadata is None:
            metadata = PiggyMetadata()
            setattr(element, 'piggy.metadata', metadata)
        return metadata

    def get(self, key: str):
        PiggyMetadata.__lg__.debug('get (self: %s, key: %s)', self, key)
        return getattr(self, key, None)

    def set(self, key: str, value: Any):
        PiggyMetadata.__lg__.debug('set (self: %s, key: %s, value: %s)', self, key, value)
        setattr(self, key, value)


class ElementType(Enum):
    TYPE = 0
    FIELD = 1
    METHOD = 2
    PARAMETER = 3
    CONSTRUCTOR = 4
    LOCAL_VARIABLE = 5
    ANNOTATION_TYPE = 6
    PACKAGE = 7
    TYPE_PARAMETER = 8
    TYPE_USE = 9
    MODULE = 10


class AnnotationType:
    # TODO Evaluate if I should keep it...Temporal?
    pass


class Annotation:
    """
    A normal annotation specifies the name of an annotation interface and optionally a list of comma-separated
    element-value pairs.
    Each pair contains an element value that is associated with an element of the annotation interface
    """
    __lg__ = Logger.getLogger(f'{__name__}.{__qualname__}')

    def __setitem__(self, key, value):
        self.__lg__.debug('__setitem__(self: %s, key: %s, value: %s)', self, key, value)
        self.__dict__[key] = value


class MarkerAnnotation(Annotation):
    """
    An annotation interface with no elements is called a marker annotation interface.
    It is legal to use marker annotations for annotation interfaces with elements,
    so long as all the elements have default values
    """
    pass


class SingleElementAnnotation(Annotation):
    """
    An annotation interface with one element is called a single-element annotation interface.
    By convention, the name of the sole element in a single-element annotation interface is value.
    Linguistic support for this convention is provided by single-element annotations
    It is legal to use single-element annotations for annotation interfaces with multiple elements,
    so long as one element is named value and all other elements have default values
    """
    pass


class Argument:
    def __init__(self, name, value, typ):
        self.name = name
        self.private = f'__{name}__'
        self.value = value
        self.typ = typ


class AnnotatedElement:

    def isAnnotationPresent(self, annotationType: Type[Annotation]) -> bool:
        return self.getAnnotation(annotationType) is not None

    def getAnnotation(self, annotationType: Type[Annotation]) -> Annotation:
        return PiggyMetadata.of(self).get(annotationType.__name__)

    def getAnnotations(self) -> List[Annotation]:
        metadata = PiggyMetadata.of(self)
        annots = []
        if metadata:
            for value in metadata.__dict__.values():
                if isinstance(value, Annotation):
                    annots.append(value)
        return annots


class AnnotatedFunctionElement(AnnotatedElement, Callable):
    __lg__ = Logger.getLogger(f'{__name__}.{__qualname__}')

    def __init__(self, fnc):
        AnnotatedFunctionElement.__lg__.debug('__init__ (self: %s, function: %s)', self, fnc)
        self.__func__ = fnc
        self.__signature__ = inspect.signature(fnc)
        self.__instance__ = None
        self.__owner__ = None

    def __call__(self, *args, **kwargs):
        AnnotatedFunctionElement.__lg__.debug('__call__ (self: %s, args: %s, kwargs: %s)', self, args, kwargs)
        # Re-structure call if __get__ wasn't called
        if self.__instance__ is None:
            self.__instance__ = args[0]
            args = tuple()
        ret = self.__func__(self.__instance__, *args, **kwargs)
        self.__instance__ = None
        return ret

    def __get__(self, instance, owner):
        AnnotatedFunctionElement.__lg__.debug(
            '__get__ (self: %s, func: %s, instance: %s, owner: %s)',
            self, self.__func__, instance, owner
        )
        self.__instance__ = instance
        self.__owner__ = owner
        return self


class AnnotationHandler:
    __lg__ = Logger.getLogger(f'{__name__}.{__qualname__}')
    ALLOWED_ELEMENTS = {
        FunctionType: {ElementType.METHOD},
        type: {ElementType.TYPE},
        AnnotationType: {ElementType.ANNOTATION_TYPE},
        AnnotatedFunctionElement: {ElementType.METHOD}
    }

    @staticmethod
    def extendClass(target: Type):
        members = {}
        className = target.__name__
        skip = ['__bases__', '__mro__', '__base__', '__class__']
        slots = getattr(target, '__slots__', None)
        if slots:
            skip.extend(slots)

        for key in dir(target):
            if key not in skip:
                value = getattr(target, key, None)
                members[key] = value

        bases = list(getattr(target, '__bases__', []))
        if object in bases:
            bases.remove(object)
        if AnnotatedElement not in bases:
            bases.append(AnnotatedElement)
        # overwrite AnnotatedElement methods as classmethods
        overwrite = inspect.getmembers(AnnotatedElement, inspect.isfunction)

        for name, method in overwrite:
            members[name] = classmethod(method)

        delegate = type(className, tuple(bases), members)
        return delegate

    @staticmethod
    def convert(cls, argument):
        AnnotationHandler.__lg__.debug('convert (cls: %s, argument: %s)', cls, argument)
        if inspect.isfunction(argument):
            return AnnotatedFunctionElement(argument)
        elif inspect.isclass(argument):
            if not issubclass(argument, AnnotatedElement):
                return AnnotationHandler.extendClass(argument)
        elif isinstance(argument, AnnotatedElement):
            # safe to return argument as it is
            return argument

        raise ValueError(f'Do not known how to convert {argument}')

    @staticmethod
    def acceptValue(instance):
        if isinstance(instance, SingleElementAnnotation):
            fields = instance.__fields__
            value = fields.get('__value__')
            # TODO check return type
            return True if value is not None and value[0] is None else False
        return False

    @staticmethod
    def isOneArgument(*args):
        return args and len(args) == 1

    @staticmethod
    def accepts(cls, argument):
        def isAssignable(arg, cls):
            if inspect.isclass(arg):
                if cls == type:
                    return isinstance(arg, cls)
                else:
                    return issubclass(arg, cls) or arg == cls
            elif inspect.isfunction(arg):
                return True
            else:
                # should be an instance
                return isinstance(arg, cls)

        allowedElements = cls.__target__.value()
        if not isinstance(allowedElements, set):
            raise ValueError(f'Target elements must be set(). Current: {allowedElements}')
        for t, s in AnnotationHandler.ALLOWED_ELEMENTS.items():
            # function are not classes in Python
            assignable = isAssignable(argument, t)
            common = allowedElements & s
            if assignable and common:
                return True

        return False

    @staticmethod
    def checkAndGetKwargs(instance, **kwargs):
        # only worry by fields with Null value
        fields = {}
        for key, argument in instance.__fields__.items():
            if key not in kwargs and argument.value is None:
                # this is an error
                raise ValueError(f'Required argument: {key} missing for: {instance.__class__.__name__}')
            elif argument.value is not None and key not in kwargs:
                fields[argument.private] = argument.value
            elif key in kwargs:
                fields[argument.private] = kwargs[key]
        return fields

    @staticmethod
    def checkField(cls, name):
        return name in cls.__fields__

    def __new__(cls, *args, **kwargs):
        AnnotationHandler.__lg__.debug('__new__ (cls: %s, args: %s, kwargs: %s)', cls, args, kwargs)
        if cls == Target:
            return object.__new__(cls)
        if not args and kwargs:
            return object.__new__(cls)

        if AnnotationHandler.isOneArgument(*args) and AnnotationHandler.accepts(cls, args[0]):
            argument = AnnotationHandler.convert(cls, args[0])
            instance = object.__new__(cls)
            metadata = PiggyMetadata.of(argument)
            metadata.set(cls.__name__, instance)
            if isinstance(instance, AnnotatedElement):
                nested = instance.getAnnotations()
                for annot in nested:
                    metadata.set(annot.__class__.__name__, annot)
            return argument
        if AnnotationHandler.isOneArgument(*args) and AnnotationHandler.checkField(cls, 'value'):
            return object.__new__(cls)
        # Blindly allow new instances of Marker annotations - Check it...
        if issubclass(cls, MarkerAnnotation):
            return object.__new__(cls)
        # FIXME - Verify what to return for edge cases
        raise ValueError('Edge case - Must return something...')

    def __init__(self, *args, **kwargs):
        AnnotationHandler.__lg__.debug('__init__ (self: %s, args: %s, kwargs: %s)', self, args, kwargs)
        singleArgument = AnnotationHandler.isOneArgument(*args)
        if singleArgument and not kwargs:
            argument = args[0]
            # Initialize Target
            if isinstance(self, Target):
                self.__setitem__('__value__', argument)
                return
            # per convention single argument should be assigned to value, unless self is a MarkerAnnotation?
            valueField = self.__fields__.get('value')
            if valueField:
                self.__setitem__(valueField.private, argument)
                return
            elif isinstance(self, MarkerAnnotation):
                # FIXME Some kind of markers do not get a __call__ and the argument is never instanciated
                # improve this in the future
                self.__setitem__('marking', argument)
                PiggyMetadata.of(self).set(argument.__name__, object.__new__(argument))
            else:
                raise ValueError('Per convention single argument should be assigned to value or be MarkerAnnotation')
        elif kwargs and not singleArgument:
            fields = AnnotationHandler.checkAndGetKwargs(self, **kwargs)
            for key, value in fields.items():
                self.__setitem__(key, value)

    def __call__(self, *args, **kwargs):
        AnnotationHandler.__lg__.debug('__call__ (self: %s, args: %s, kwargs: %s)', self, args, kwargs)
        if isinstance(self, Target):
            arg = args[0]
            cls = AnnotationFactory.create(arg, self)
            return cls
        cls = self.__class__
        if AnnotationHandler.isOneArgument(*args) and AnnotationHandler.accepts(cls, args[0]):
            argument = AnnotationHandler.convert(cls, args[0])
            PiggyMetadata.of(argument).set(cls.__name__, self)
            return argument
        # if self.__class__ is a Marker annotation then is legal to convert it if the annotation is accepted
        if issubclass(cls, MarkerAnnotation):  # and AnnotationHandler.accepts(cls, args[0]):
            argument = AnnotationHandler.convert(cls, args[0])
            PiggyMetadata.of(argument).set(cls.__name__, self)
            # mark inverse too?
            # PiggyMetadata.of(self).set(argument.__name__, argument)
            return argument

        # FIXME - Verify what to return for edge cases
        raise ValueError('Edge case - Must return something...')


class AnnotationFactory:
    __lg__ = Logger.getLogger(f'{__name__}.{__qualname__}')

    @staticmethod
    def wrapFunction(members, name, method):
        AnnotationFactory.__lg__.debug('wrapFunction (name: %s, method: %s)', name, method)
        fields = members.get('__fields__')
        signature = inspect.signature(method)
        # Is legal only to get default values from instance methods don't needing arguments any other is None
        defaultValue = None
        AnnotationFactory.__lg__.debug('\tparameters: %s', signature.parameters)
        if len(signature.parameters) == 1:
            defaultValue = method(object())
            key = f'__{name}__'

            fields[name] = Argument(name, defaultValue, signature.return_annotation)

            def wrap(self, k=key, m=method):
                value = self.__dict__.get(k)
                return value if value else m(self)

            members[name] = wrap

    @staticmethod
    def create(cls, target=None):
        AnnotationFactory.__lg__.debug('create (cls: %s)', cls)

        members = {
            '__fields__': dict(),
            '__name__': cls.__name__,
            '__qualname__': cls.__qualname__,
            '__module__': cls.__module__,
            '__new__': AnnotationHandler.__new__,
            '__init__': AnnotationHandler.__init__,
            '__call__': AnnotationHandler.__call__,
        }

        annotations = getattr(cls, '__annotations__', None)
        if annotations:
            members['__annotations__'] = cls.__annotations__

        skip = dict(inspect.getmembers(AnnotatedElement, inspect.isfunction))
        clsMembers = inspect.getmembers(cls)

        for name, method in clsMembers:
            if not name.startswith('__') and name not in skip:
                if inspect.isfunction(method):
                    AnnotationFactory.wrapFunction(members, name, method)
                else:
                    members[name] = method

        fields = members.get('__fields__')
        marker = True
        single = False

        if fields is not None:
            for key, val in fields.items():
                if key == 'value' and val.value is None:
                    single = True
                    marker = False
                    continue

                if val.value is None and marker:
                    marker = False
                    continue
                if val.value is None and single:
                    single = False

        base = [Annotation]
        if marker:

            base = [MarkerAnnotation]
            # Some markers already are AnnotatedElements so be careful
            if AnnotatedElement not in cls.__bases__:
                base.append(AnnotatedElement)
            AnnotationFactory.__lg__.debug('MarkerAnnotation cls: %s, current bases: %s', cls, cls.__bases__)
        elif single:
            base = [SingleElementAnnotation]
        if target:
            members['__target__'] = target

        bases = base
        bases.extend(cls.__bases__)
        className = cls.__name__

        delegate = type(className, tuple(bases), members)
        return delegate


class Notation:
    __lg__ = Logger.getLogger(f'{__name__}.{__qualname__}')

    def __new__(cls, *args, **kwargs):
        Notation.__lg__.debug('__new__ (cls: %s, args: %s, kwargs: %s)', cls, args, kwargs)
        delegate = AnnotationFactory.create(args[0])
        return delegate


@Notation
class Target(AnnotationType):
    def value(self) -> Set[ElementType]:
        pass
