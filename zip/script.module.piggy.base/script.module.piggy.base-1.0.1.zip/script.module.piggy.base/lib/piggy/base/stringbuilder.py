from __future__ import annotations

from typing import Optional, Union, overload


class StringBuilder:
    __slots__ = '__buff__'

    def __init__(self, value: Optional[Union[int, str]] = None):
        if value:
            if isinstance(value, str):
                self.__buff__ = bytearray(value, 'UTF-8')
            else:
                self.__buff__ = bytearray(value)
        else:
            self.__buff__ = bytearray()

    @overload
    def append(self, sb: StringBuilder) -> StringBuilder:
        pass

    @overload
    def append(self, b: bool) -> StringBuilder:
        pass

    @overload
    def append(self, i: int) -> StringBuilder:
        pass

    @overload
    def append(self, f: float) -> StringBuilder:
        pass

    @overload
    def append(self, obj: object) -> StringBuilder:
        pass

    def append(self, data, start: int = None, end: int = None) -> StringBuilder:
        if isinstance(data, int) or isinstance(data, float) or isinstance(data, bool):
            return self.__append__(str(data))
        elif isinstance(data, str):
            return self.__append__(data)
        elif isinstance(data, StringBuilder):
            return self.__append__(data.toString())
        elif start is not None and end is not None:
            return self.__append__(data[start:end])
        else:
            return self.__append__(data.toString() if hasattr(data, 'toString') else str(data))

    def __append__(self, string: str) -> StringBuilder:
        if string:
            self.__buff__ += string.encode('UTF-8')
        else:
            self.__buff__ += 'None'.encode('UTF-8')
        return self

    def charAt(self, index: int) -> str:
        string = self.toString()

        return string[index]

    def length(self):
        return len(self.__buff__)

    def toString(self):
        return self.__buff__.decode('utf-8')
