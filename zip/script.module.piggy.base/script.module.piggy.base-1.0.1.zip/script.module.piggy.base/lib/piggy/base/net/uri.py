from __future__ import annotations

from urllib.parse import urlparse, unquote, quote

from piggy.base import Overload, UnsupportedOperationException, Raisable
from piggy.base.stringbuilder import StringBuilder
from piggy.base.util import Objects


class URISyntaxException(Raisable):
    pass


class URI:
    __slots__ = 'scheme', 'fragment', 'authority', 'userInfo', 'host', 'port', 'path', 'query', \
                'schemeSpecificPart', 'decodedUserInfo', 'decodedAuthority', 'decodedPath', \
                'decodedQuery', 'decodedFragment', 'decodedSchemeSpecificPart', 'stringUri'

    def _checkPath(self, s: str, scheme: str, path: str):
        if scheme:
            if path and not len(path) == 0 and path[0] != '/':
                raise URISyntaxException(s, "Relative path in absolute URI")

    def _safeGet(self, component, key, defaults=None):
        value = getattr(component, key, defaults)
        # weird things happens sometime...
        if Objects.isEmpty(value):
            return defaults
        return value

    def _parse(self, string: str):
        components = urlparse(string)
        self.scheme = self._safeGet(components, 'scheme')
        self.path = self._safeGet(components, 'path')
        self.query = self._safeGet(components, 'query')
        self.fragment = self._safeGet(components, 'fragment')
        self.userInfo = self._safeGet(components, 'username')
        self.host = self._safeGet(components, 'hostname')
        self.port = self._safeGet(components, 'port', -1)
        self.authority = self._safeGet(components, 'netloc')
        self.schemeSpecificPart = None
        self.decodedUserInfo = None
        self.decodedAuthority = None
        self.decodedPath = None
        self.decodedQuery = None
        self.decodedFragment = None
        self.decodedSchemeSpecificPart = None
        self.stringUri = self._toString(
            self.scheme, None, self.authority, self.userInfo, self.host, self.port, self.path, self.query, self.fragment
        )

    def _decode(self, value, param=None):
        return unquote(value)

    def _encode(self, value, safe='/'):
        # try to evaluate if should encode or not
        if value.find('%') > -1:
            # should be ready
            return value
        return quote(value, safe)

    def _appendSchemeSpecificPart(self, sb: StringBuilder,
                                  opaquePart: str,
                                  authority: str,
                                  userInfo: str,
                                  host: str,
                                  port: int,
                                  path: str,
                                  query: str):

        if opaquePart:
            # check if SSP begins with an IPv6 address
            # because we must not quote a literal IPv6 address

            if opaquePart.startswith("//["):
                end: int = opaquePart.find(']')
                if end != -1 and opaquePart.find(':') != -1:
                    if end == len(opaquePart):
                        dontquote = opaquePart
                        doquote = ""
                    else:
                        dontquote = opaquePart[0:end + 1]
                        doquote = opaquePart[end + 1:]
                    sb.append(dontquote).append(self._encode(doquote))
            else:
                sb.append(self._encode(opaquePart))
        else:
            self._appendAuthority(sb, authority, userInfo, host, port)
            if path:
                sb.append(self._encode(path))
            if query:
                sb.append('?').append(self._encode(query, '?=&'))

    def _appendAuthority(self, sb: StringBuilder, authority: str, userInfo: str, host: str, port: int):

        if host:
            sb.append("//")
            if userInfo:
                sb.append(self._encode(userInfo)).append('@')

            needBrackets: bool = ((host.find(':') >= 0)
                                  and not host.startswith("[")
                                  and not host.endswith("]"))
            if needBrackets: sb.append('[')
            sb.append(host)
            if needBrackets: sb.append(']')
            if port != -1:
                sb.append(':')
                sb.append(port)

        elif authority:
            sb.append("//")
            if authority.startswith("["):
                # authority should (but may not) contain an embedded IPv6 address
                end: int = authority.find(']')
                doquote = authority
                dontquote = ""
                if end != -1 and authority.find(':') != -1:
                    # the authority contains an IPv6 address
                    if end == len(authority):
                        dontquote = authority
                        doquote = ""
                    else:
                        dontquote = authority[0: end + 1]
                        doquote = authority[end + 1:]

                sb.append(dontquote)
                sb.append(self._encode(doquote))
            else:
                sb.append(self._encode(authority))

    def _appendFragment(self, sb: StringBuilder, fragment: str):
        if fragment:
            sb.append('#').append(self._encode(fragment))

    def _toString(self, scheme: str,
                  opaquePart: str,
                  authority: str,
                  userInfo: str,
                  host: str,
                  port: int,
                  path: str,
                  query: str,
                  fragment: str):
        sb: StringBuilder = StringBuilder()
        if scheme:
            sb.append(scheme).append(':')
        self._appendSchemeSpecificPart(sb, opaquePart, authority, userInfo, host, port, path, query)
        self._appendFragment(sb, fragment)
        return sb.toString()

    @Overload
    def __init__(self, string: str):
        self._parse(string)

    @Overload
    def __init__(self, scheme: str, userInfo: str, host: str, port: int, path: str, query: str, fragment: str):

        s: str = self._toString(scheme, None, None, userInfo, host, port, path, query, fragment)
        self._checkPath(s, scheme, path)
        self._parse(s)

    @Overload
    def __init__(self, scheme: str, authority: str, path: str, query: str, fragment: str):

        s: str = self._toString(scheme, None, authority, None, None, -1, path, query, fragment)
        self._checkPath(s, scheme, path)
        self._parse(s)

    @Overload
    def __init__(self, scheme: str, host: str, path: str, fragment: str):

        s: str = self._toString(scheme, None, None, None, host, -1, path, None, fragment)
        self._checkPath(s, scheme, path)
        self._parse(s)

    @Overload
    def __init__(self, scheme: str, ssp: str, fragment: str):
        s: str = self._toString(scheme, ssp, None, None, None, -1, None, None, fragment)
        self._parse(s)

    @classmethod
    def create(cls, uri: str) -> URI:
        return URI(uri)

    def compareTo(self, obj: object) -> int:
        raise UnsupportedOperationException("Not supported yet.")

    def equals(self, obj: object) -> bool:
        raise UnsupportedOperationException("Not supported yet.")

    def getFragment(self) -> str:
        if self.decodedFragment is None and self.fragment:
            self.decodedFragment = self._decode(self.fragment, False)
        return self.decodedFragment

    def getRawFragment(self) -> str:
        return self.fragment

    def getPath(self) -> str:
        if self.decodedPath is None and self.path:
            self.decodedPath = self._decode(self.path)
        return self.decodedPath

    def getRawPath(self) -> str:
        return self.path

    def getHost(self) -> str:
        return self.host

    def getPort(self) -> int:
        return self.port

    def getQuery(self) -> str:
        if self.decodedQuery is None and self.query:
            self.decodedQuery = self._decode(self.query, False)
        return self.decodedQuery

    def getRawQuery(self) -> str:
        return self.query

    def getAuthority(self) -> str:
        if self.decodedAuthority is None and self.authority:
            self.decodedAuthority = self._decode(self.authority)
        return self.decodedAuthority

    def getRawAuthority(self) -> str:
        return self.authority

    def getScheme(self) -> str:
        return self.scheme

    def getSchemeSpecificPart(self) -> str:
        if self.decodedSchemeSpecificPart is None:
            self.decodedSchemeSpecificPart = self._decode(self.getRawSchemeSpecificPart())
        return self.decodedSchemeSpecificPart

    def getRawSchemeSpecificPart(self) -> str:

        part: str = self.schemeSpecificPart
        if part:
            return part

        s: str = self.stringUri
        if s:
            # if string is defined, components will have been parsed
            start: int = 0
            end: int = len(s)
            if self.scheme:
                start = len(self.scheme) + 1

            if self.fragment:
                end -= len(self.fragment) + 1

            if self.path and len(self.path) == end - start:
                part = self.path
            else:
                part = s[start: end]

        else:
            sb = StringBuilder()
            self._appendSchemeSpecificPart(sb, None, self.getAuthority(), self.getUserInfo(),
                                           self.host, self.port, self.getPath(), self.getQuery())
            part = sb.toString()
        self.schemeSpecificPart = part
        return self.schemeSpecificPart

    def getUserInfo(self) -> str:
        if self.decodedUserInfo is None and self.userInfo:
            self.decodedUserInfo = self._decode(self.userInfo)
        return self.decodedUserInfo

    def getRawUserInfo(self) -> str:
        return self.userInfo

    def hashCode(self) -> int:
        raise UnsupportedOperationException("Not supported yet.")

    def isAbsolute(self) -> bool:
        raise UnsupportedOperationException("Not supported yet.")

    def isOpaque(self) -> bool:
        """
        A URI is opaque if, and only if, it is absolute and its
        scheme-specific part does not begin with a slash character ('/').
        An opaque URI has a scheme, a scheme-specific part, and possibly
        a fragment; all other components are undefined.

        :return: True if, and only if, this URI is opaque
        """
        return self.path is None

    def normalizePath(self, path):
        segments = path.split('/')

        ns = list()
        remove = list()
        for idx in range(0, len(segments)):
            if Objects.isEmpty(segments[idx]) or segments[idx] == '.':
                remove.append(idx)
            if segments[idx] == '..' and idx > 0:
                remove.append(idx - 1)
                remove.append(idx)

        if not Objects.isEmpty(remove):
            for idx in range(0, len(segments)):
                if idx not in remove:
                    ns.append(segments[idx])
        ns.insert(0, '')
        return '/'.join(ns)

    def normalize(self) -> URI:

        if self.isOpaque() or Objects.isEmpty(self.path):
            return self
        path = self.normalizePath(self.path)
        if path == self.path:
            return self
        # def __init__(self, scheme: str, userInfo: str, host: str, port: int, path: str, query: str, fragment: str):
        nu = URI(self.scheme, self.userInfo, self.host, self.port, path, self.query, self.fragment)
        if not Objects.isEmpty(self.authority):
            nu.authority = self.authority
        return nu

    def parseServerAuthority(self) -> URI:
        raise UnsupportedOperationException("Not supported yet.")

    def relativize(self, uri: URI) -> URI:
        raise UnsupportedOperationException("Not supported yet.")

    @Overload
    def resolve(self, uri: URI) -> URI:
        raise UnsupportedOperationException("Not supported yet.")

    @Overload
    def resolve(self, string: str) -> URI:
        raise UnsupportedOperationException("Not supported yet.")

    def toASCIIString(self) -> str:
        raise UnsupportedOperationException("Not supported yet.")

    def defineString(self) -> str:
        sb = StringBuilder()
        if self.scheme is not None:
            sb.append(self.scheme)
            sb.append(':')

        if self.isOpaque():
            sb.append(self.getSchemeSpecificPart())
        else:
            if self.host is not None:
                sb.append("//")
                if self.userInfo is not None:
                    sb.append(self.userInfo)
                    sb.append('@')

                needBrackets = (
                        (self.host.find(':') >= 0) and not self.host.startsWith("[") and not self.host.endsWith("]")
                )
                if needBrackets: sb.append('[')
                sb.append(self.host)
                if needBrackets: sb.append(']')
                if self.port != -1:
                    sb.append(':')
                    sb.append(self.port)

            elif self.authority is not None:
                sb.append("//")
                sb.append(self.authority)

            if self.path is not None:
                sb.append(self.path)
            if self.query is not None:
                sb.append('?')
                sb.append(self.query)

        if self.fragment is not None:
            sb.append('#')
            sb.append(self.fragment)

        self.stringUri = sb.toString()
        return self.stringUri

    def toString(self) -> str:
        #  scheme, netloc, url, params, query, fragment
        if self.stringUri:
            return self.stringUri
        else:
            return self._toString(
                self.getScheme(),
                None,
                self.getAuthority(),
                self.getUserInfo(),
                self.getHost(),
                self.getPort(),
                self.getPath(),
                self.getQuery(),
                self.getFragment()
            )
