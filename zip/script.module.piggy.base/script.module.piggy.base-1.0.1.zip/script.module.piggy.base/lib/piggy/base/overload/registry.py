import inspect
from piggy.base.util.logging import Logger
from collections import Callable
from typing import Type

from piggy.base.overload import FunctionType, OverloadException, _dbg_
from piggy.base.overload.invocables import Invocable, Invocables


class Registry:
    __lg__ = Logger.getLogger(f'{__name__}.{__qualname__}')

    def __init__(self):
        self.functions = dict()

    def register(self, function: Callable):
        _dbg_(self.__lg__, f'register\n'
                          f'\tfunction: "{function}"')
        fncType = FunctionType.UNKNOWN
        if isinstance(function, staticmethod):
            fncType = FunctionType.STATIC
            function = getattr(function, '__func__', None)
        elif isinstance(function, classmethod):
            fncType = FunctionType.CLASS
            function = getattr(function, '__func__', None)

        module = getattr(function, '__module__', None)
        name = getattr(function, '__name__', None)
        qualname = getattr(function, '__qualname__', None)

        signature = inspect.signature(function)

        first = True
        toRemove = None
        parameters = dict(signature.parameters)
        for name, parameter in parameters.items():
            if first:  # Try to remove first parameter since usually is the instance or class and may have arbitrary name
                if parameter.annotation == parameter.empty:
                    if not fncType == FunctionType.CLASS:
                        fncType = FunctionType.METHOD
                    toRemove = name
                first = False
        if toRemove:
            del parameters[toRemove]

        if fncType == FunctionType.UNKNOWN:
            code = getattr(function, '__code__', None)
            if not code:
                raise OverloadException('Could not get function code')
            co_name = code.co_name

            if co_name == name and name == qualname:
                fncType = FunctionType.MODULE

        key = f'{module}.{qualname}'

        _dbg_(self.__lg__, f'Registry key: {key}')
        invocable: Invocable = Invocable(function, fncType, parameters)

        if key not in self.functions:
            self.functions[key] = Invocables(invocable)
        else:
            self.functions[key].add(invocable)
        return key

    def setOwner(self, key: str, owner: Type):
        _dbg_(self.__lg__, f'setOwner\n'
                          f'\towner: "{owner}"')
        self.functions[key].bind(owner)

    def get(self, key: str) -> Invocables:
        return self.functions[key]
