import inspect
import sys
import typing
from typing import Union, Type, Set, Any

from piggy.base.overload import OverloadException, _dbg_
from piggy.base.util.logging import Logger


class Assignable:
    def isAssignable(self, annotation: Set[type], argument: Any):
        pass


class TypingAssignable(Assignable):
    __lg__ = Logger.getLogger(f'{__name__}.{__qualname__}')
    MODULE = 'typing'
    __cache__ = dict()

    def isAssignable(self, candidates: Set[type], argument: Any):
        for annotation in candidates:
            argumentType = type(argument)
            origin = typing.get_origin(annotation)
            if origin and origin == argumentType or origin and issubclass(argumentType, origin):
                self.__cache__[annotation] = origin
                _dbg_(self.__lg__,
                      f'\t MATCH typing annotation == argument ({annotation} == {argumentType}) origin == argument {origin == argumentType}')
                return True
            if isinstance(annotation, typing.TypeVar):
                bound = getattr(annotation, '__bound__', None)
                constraints = getattr(annotation, '__constraints__', None)
                contravariant = getattr(annotation, '__contravariant__', None)
                covariant = getattr(annotation, '__covariant__', None)
                name = getattr(annotation, '__name__', None)
                _dbg_(self.__lg__, f'TypeVar \n'
                                   f'        bound: {bound}\n'
                                   f'  constraints: {constraints}\n'
                                   f'contravariant: {contravariant}\n'
                                   f'    covariant: {covariant}\n'
                                   f'         name: {name}\n'
                      )
                if bound == typing.Any:
                    _dbg_(self.__lg__,
                          f'\t MATCH TypeVar bound to Any ({annotation} == {argumentType}) annotation.bound:{bound}')
                    return True
                if isinstance(argument, bound):
                    _dbg_(self.__lg__,
                          f'\t MATCH TypeVar argument:"{argument} is a bound instance :"{bound}"')
                    return True

            _dbg_(self.__lg__, 'Return False')
            return False


class ClassEqualAssignable(Assignable):
    __lg__ = Logger.getLogger(f'{__name__}.{__qualname__}')

    @classmethod
    def _dbg(cls, msg, *args, **kwargs):
        _dbg_(cls.__lg__, msg, *args, **kwargs)

    def isAssignable(self, candidates: Set[type], argument: Any):
        argumentType = type(argument)
        _dbg_(self.__lg__,
              f'Evaluating annotation candidates: "{candidates}", argument: "{argument}" {type(argument)}')
        if argumentType == type(None):
            _dbg_(self.__lg__,
                  f'Return True - argument Type is None: "{argument}" {type(argument)}')
            return True

        _dbg_(self.__lg__, f'Got candidates: "{candidates} for argument: "{argument}"')
        for candidate in candidates:
            _dbg_(self.__lg__, f'Checking candidate: "{candidate} with argument: "{argument}"')
            # if candidate is object
            try:
                if isinstance(argument, candidate):
                    _dbg_(self.__lg__, f'isinstance return True')
                    return True
                # Special case bytes and bytearray
                if candidate == bytes and isinstance(argument, bytearray):
                    _dbg_(self.__lg__, f'special case isinstance return True')
                    return True

            except TypeError as e:
                _dbg_(self.__lg__, f'Error: "{e} with annotation: "{candidate} with argument: "{argument}"')
        _dbg_(self.__lg__, 'Return False')
        return False


class StringAnnotationHelper:
    __lg__ = Logger.getLogger(f'{__name__}.{__qualname__}')
    __cache__: typing.Dict[str, Set[Type]] = dict()

    @classmethod
    def searchInside(cls, candidates, objs, value):
        for v in value:
            for n, o in objs:
                if v == n:
                    origin = typing.get_origin(o)
                    if inspect.isclass(o) or origin:
                        candidates.add(o)

    @classmethod
    def search(cls, value: str) -> Set[Type]:
        _dbg_(cls.__lg__, "*** Searching candidates START: %s", value)
        value = value.replace("'", "").replace('"', '')
        value = value.split('.')

        modules = set(sys.modules.values())
        candidates = set()
        for module in modules:
            members = set(inspect.getmembers(module, inspect.isclass))
            for name, obj in members:
                # _dbg_(cls.__lg__, 'Searching candidates value: "%s", name: "%s", obj: "%s"', value, name, obj)
                if len(value) == 1:
                    if name == value[0]:
                        _dbg_(cls.__lg__, 'Found candidate with same name - value: "%s", name: "%s"', value, name)
                        origin = typing.get_origin(obj)
                        if inspect.isclass(obj) or origin:
                            candidates.add(obj)
                elif len(value) > 1 and name == value[0]:
                    _dbg_(cls.__lg__,
                          'First level candidate with same name - value: "%s", name: "%s", obj: "%s" on module: "%s"',
                          value, name, obj, module)
                    cls.searchInside(candidates, inspect.getmembers(obj, inspect.isclass), value[1:])
        return candidates

    @classmethod
    def getTypeCandidates(cls, annotation: str) -> Set[Type]:
        toSearch = annotation
        replace = annotation.find('[')
        if replace > -1:
            toSearch = annotation[0:replace]
        cached = cls.__cache__.get(annotation)
        if cached:
            _dbg_(cls.__lg__,
                  f'Return cached candidates: "{cached}" for "{annotation}"')
            return cached
        candidates = cls.search(toSearch)
        _dbg_(cls.__lg__,
              f'\t annotation search found candidates: "{candidates}" for "{annotation}"')
        if len(candidates) == 0:
            raise OverloadException(f'Could not find any candidate for string annotation: {annotation}')
        cls.__cache__[annotation] = candidates
        return candidates


class Assignables:
    __lg__ = Logger.getLogger(f'{__name__}.{__qualname__}')
    __assignables__: Set[Assignable] = set()

    @classmethod
    def isAssignable(cls, annotation: Union[str, Type], argument: Any):
        candidates: Set[Type] = None
        if isinstance(annotation, str):
            candidates = StringAnnotationHelper.getTypeCandidates(annotation)
        else:
            candidates = {annotation}

        for assignable in cls.__assignables__:
            if assignable.isAssignable(candidates, argument):
                _dbg_(cls.__lg__, f'Return True')
                return True
        _dbg_(cls.__lg__, f'Return False')
        return False

    @classmethod
    def add(cls, assignable: Assignable):
        if isinstance(assignable, Assignable):
            cls.__assignables__.add(assignable)
        else:
            raise OverloadException('Is not an Assignable instance')


Assignables.add(TypingAssignable())
Assignables.add(ClassEqualAssignable())
