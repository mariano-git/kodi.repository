from typing import Callable

from piggy.base.overload import OverloadException, _dbg_
from piggy.base.overload.invocables import Invocables
from piggy.base.overload.registry import Registry
from piggy.base.util.logging import Logger


class Overload:
    __lg__ = Logger.getLogger(f'{__name__}.{__qualname__}')
    registry: Registry = Registry()

    def __init__(self, function: Callable):
        if self.__lg__.isEnabledFor(Logger.DEBUG):
            _dbg_(self.__lg__, 'instance: %s __init__(%s)', self, function)

        self.__function__ = function
        self.invocables = None
        self.instance = None
        self.owner = None
        self.key = Overload.registry.register(function)

    def __set_name__(self, owner, name):
        if self.__lg__.isEnabledFor(Logger.DEBUG):
            _dbg_(self.__lg__, f'__set_name__\n'
                               f'\t  key: "{self.key}"\n'
                               f'\towner: "{owner}"\n'
                               f'\t name: "{name}"')

        self.registry.setOwner(self.key, owner)

    def getInvocables(self) -> Invocables:
        if self.invocables:
            invocables: Invocables = self.invocables
        elif self.key:
            invocables: Invocables = self.registry.get(self.key)
        else:
            raise OverloadException('Could not get invocables to call')
        return invocables

    def __get__(self, instance, owner):
        _dbg_(self.__lg__, f'__get__\n'
                           f'\t      key: "{self.key}"\n'
                           f'\t instance: "{instance}"\n'
                           f'\t    owner: "{owner}"')
        self.instance = instance
        self.owner = owner
        invocables = self.getInvocables()
        invocables.prepare(instance, owner)
        return self

    def __call__(self, *args, **kwargs):
        _dbg_(self.__lg__, f'__call__\n'
                           f'\t    key: "{self.key}"\n'
                           f'\t   args: {args}\n'
                           f'\t kwargs: {kwargs}')
        try:
            invocables = self.getInvocables()
            return invocables.invoke(*args, **kwargs)
        except OverloadException as oe:
            raise oe
        except BaseException as e:
            raise e

    @classmethod
    def register(cls, param):
        Assignables.add(param)
