from enum import Enum

from piggy.base import raisable, RuntimeException


@raisable
class OverloadException(RuntimeException):
    pass


_DEBUG_ = False


def _dbg_(log, msg, *args, **kwargs):
    if _DEBUG_:
        log.debug(msg, *args, **kwargs)


class FunctionType(Enum):
    UNKNOWN = 0
    STATIC = 1
    CLASS = 2
    METHOD = 3
    MODULE = 4
