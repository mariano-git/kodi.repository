import inspect
from piggy.base.util.logging import Logger
import pprint
import typing
from io import StringIO
from types import MappingProxyType
from typing import Callable, Dict, Type, Any

from piggy.base.overload import OverloadException, FunctionType, _dbg_
from piggy.base.overload.assignables import Assignables


class Invocable:
    __lg__ = Logger.getLogger(f'{__name__}.{__qualname__}')

    def __init__(self, function: Callable, fncType: FunctionType, parameters: Dict[str, inspect.Parameter]):
        _dbg_(self.__lg__, f'__init__\n'
                          f'\t  function: {function}\n'
                          f'\t      type: {fncType}\n'
                          f'\tparameters: {parameters}')
        self.function = function
        self.fncType = fncType
        self.parameters = MappingProxyType(parameters)  # freeze
        self.idxparams = list()
        self.parameterNames = list(self.parameters.keys())

        self.cls = None

        self.ready: bool = False

        self.paramCount = len(parameters)

        self.defaults = list()
        self.defaultsIdx = list()
        self.defaultsNames = list()
        self.defaultsCount = 0
        self.posOnly = 0
        self.posKey = 0
        self.varPos = 0
        self.keyOnly = 0
        self.varKey = 0
        self.typeKey = None

        self.computeParameters()

        _dbg_(self.__lg__, f'fnckey:{self.typeKey}')

    def o(self):
        return f'\t          cls:{self.cls}\n' \
               f'\t        ready:{self.ready}\n' \
               f'\t   parameters:{self.parameters}\n' \
               f'\t   paramCount:{self.paramCount}\n' \
               f'\t      fncType:{self.fncType}\n' \
               f'\t     function:{self.function}\n' \
               f'\t     defaults:{self.defaults}\n' \
               f'\tdefaultsCount:{self.defaultsCount}\n' \
               f'\t      posOnly:{self.posOnly}\n' \
               f'\t       posKey:{self.posKey}\n' \
               f'\t       varPos:{self.varPos}\n' \
               f'\t      keyOnly:{self.keyOnly}\n' \
               f'\t       varKey:{self.varKey}\n' \
               f'\t      typeKey:{self.typeKey}\n'

    def computeParameters(self):
        annotations = list()
        # for idx in range(len(self.parameterNames)):
        #    parameter = self.parameters[self.parameterNames[idx]]
        idx = 0
        variadic = -1
        for parameter in self.parameters.values():
            modifier = ''
            self.idxparams.append(parameter)

            if parameter.default != inspect.Parameter.empty:
                # self.defaultsIdx.append(idx)
                self.defaultsNames.append(parameter.name)
                self.defaultsCount += 1
            if parameter.kind == inspect.Parameter.POSITIONAL_ONLY:
                self.posOnly += 1
            if parameter.kind == inspect.Parameter.POSITIONAL_OR_KEYWORD:
                self.posKey += 1
            if parameter.kind == inspect.Parameter.VAR_POSITIONAL:
                variadic = idx
                self.varPos += 1
                modifier = '*'
            if parameter.kind == inspect.Parameter.KEYWORD_ONLY:
                self.keyOnly += 1
            if parameter.kind == inspect.Parameter.VAR_KEYWORD:
                self.varKey += 1
            annotation = parameter.annotation
            if annotation:
                # FIXME To find the correct class is necessary to eager load all modules if the annotation is str
                # This impacts directly in the key creation of the function
                if isinstance(annotation, str):
                    name = annotation
                else:
                    module = getattr(annotation, '__module__', '')
                    name = getattr(annotation, '__name__', None)
                    origin = typing.get_origin(annotation)
                    if name and module:
                        name = f'{module}.{name}'
                    elif origin:
                        name = f'{getattr(origin, "__module__", "")}.{getattr(origin, "__name__", None)}'
            else:
                name = 'None'
            annotations.append(f'{modifier}{name}')
            idx += 1
        if variadic > 0:
            # all parameters before a variadic must be POSITIONAL_ONLY and not POSITIONAL_OR_KEYWORD
            for i in range(0, variadic):
                self.idxparams[i]._kind = inspect.Parameter.POSITIONAL_ONLY
        self.typeKey = f"({','.join(annotations)})"

    def add(self, *args):
        pass

    def bind(self, cls: Type):
        _dbg_(self.__lg__, f'bind\n'
                          f'\tclass: "{cls}"')
        self.cls = cls

    def getKey(self):
        return f'{self.function.__module__}.{self.function.__qualname__}{self.typeKey}'

    def getFunctionName(self):
        return f'{self.function.__module__}.{self.function.__qualname__}'

    def accept(self, *args, **kwargs) -> bool:
        _dbg_(self.__lg__, f'accept \n'
                          f'\t     function: {self.function}\n'
                          f'\tparameters: {self.parameters}\n'
                          f'\t      args: {args}\n'
                          f'\t    kwargs: {kwargs}')
        _dbg_(self.__lg__, 'start')

        argsCount = len(args)
        kwargsCount = len(kwargs)
        # allow search only if arguments > parameters and not default params
        if self.defaultsCount == 0 and self.paramCount > (argsCount + kwargsCount):
            _dbg_(self.__lg__, '--------------------------- ACCEPT RESULTS SHORT------------------------------')
            _dbg_(self.__lg__, 
                f'   should exit: {self.defaultsCount == 0 and self.paramCount > (argsCount + kwargsCount)} \n'
                f'    parameters: {self.parameters}\n'
                f'    paramCount: {self.paramCount}\n'
                f'parameters len: {len(self.parameters)} \n'
                f' defaultsCount: {self.defaultsCount}\n'
                f'    total args: {(argsCount + kwargsCount)}\n'
                f'     argsCount: {argsCount}\n'
                f'   kwargsCount: {kwargsCount}')
            _dbg_(self.__lg__, f'---------------------------------------------------------------------------')
            return False

        idx = 0
        match = list()
        parameters = list()

        consumed = 0
        defaults = 0
        # for name, parameter in self.parameters.items():
        for idx in range(len(self.parameters)):
            parameter = self.idxparams[idx]
            name = parameter.name
            parameters.append(parameter)
            _dbg_(self.__lg__, f'accept: {parameter} - {parameter.kind}')
            if parameter.kind == inspect.Parameter.POSITIONAL_ONLY:
                _dbg_(self.__lg__, f'\tPOSITIONAL_ONLY: {parameter}')
                if args and len(args) > idx:
                    if Assignables.isAssignable(parameter.annotation, args[idx]):
                        match.append(parameter)
                        consumed += 1
                        continue
            if parameter.kind == inspect.Parameter.VAR_POSITIONAL:
                _dbg_(self.__lg__, f'\tVAR_POSITIONAL: {parameter}')
                # all arguments must be of the same type and this will consume all args available
                if args and len(args) > idx:
                    remaining = args[idx:]
                    types = set(map(lambda arg: type(arg), remaining))
                    typesCount = len(types)
                    if typesCount > 1:
                        # can't continue
                        _dbg_(self.__lg__, f'\treturn false')
                        return False
                    elif typesCount == 1:
                        if Assignables.isAssignable(parameter.annotation, remaining[0]):
                            match.append(parameter)
                            consumed = consumed + len(remaining)
                            continue
            if parameter.kind == inspect.Parameter.POSITIONAL_OR_KEYWORD:
                _dbg_(self.__lg__, f'\tPOSITIONAL_OR_KEYWORD: {parameter}')
                if args and len(args) > idx:
                    if Assignables.isAssignable(parameter.annotation, args[idx]):
                        match.append(parameter)
                        consumed += 1
                        continue

                if kwargs and name in kwargs:
                    if Assignables.isAssignable(parameter.annotation, kwargs[name]):
                        match.append(parameter)
                        consumed += 1
                        continue
            if parameter.kind == inspect.Parameter.VAR_KEYWORD:
                raise OverloadException('Not Implemented yet')
            if parameter.kind == inspect.Parameter.KEYWORD_ONLY:
                _dbg_(self.__lg__, f'\tKEYWORD_ONLY: {parameter}')
                if kwargs:
                    if name in kwargs:
                        if Assignables.isAssignable(parameter.annotation, kwargs[name]):
                            match.append(parameter)
                            consumed += 1
                            continue

            if parameter.default is not parameter.empty:
                match.append(parameter)
                defaults += 1
                continue
        _dbg_(self.__lg__, '--------------------------- ACCEPT RESULTS ------------------------------')
        _dbg_(self.__lg__, 
            f'  match params: {match == parameters} \n'
            f'    parameters: {self.parameters}\n'
            f'      consumed: {consumed}\n'
            f'parameters len: {len(self.parameters)} \n'
            f'  consumed len: {consumed}\n'
            f'      defaults: {defaults}\n'
            f'     argsCount: {argsCount}\n'
            f'   kwargsCount: {kwargsCount}')
        _dbg_(self.__lg__, f'RETURNS: {match == parameters and consumed == argsCount + kwargsCount}')
        _dbg_(self.__lg__, f'---------------------------------------------------------------------------')
        return match == parameters and consumed == argsCount + kwargsCount

    def invoke(self, owner: Type, instance: object, *args, **kwargs) -> Any:

        _dbg_(self.__lg__, f'invoke \n'
                          f'\t  instance: {instance}\n'
                          f'\t     owner: {owner}\n'
                          f'\t     ready: {self.ready}\n'
                          f'\t  function: {self.function}\n'
                          f'\tparameters: {self.parameters}\n'
                          f'\t      args: {args}\n'
                          f'\t    kwargs: {kwargs}')
        e: Exception = None
        results: Any = None
        if instance and self.fncType == FunctionType.METHOD:
            try:
                results = self.function(instance, *args, **kwargs)
            except BaseException as be:
                e = be
        elif owner and self.fncType == FunctionType.CLASS:
            try:
                results = self.function(owner, *args, **kwargs)
            except BaseException as be:
                e = be
        elif owner and self.fncType == FunctionType.STATIC:
            try:
                results = self.function(*args, **kwargs)
            except BaseException as be:
                e = be
        else:
            raise OverloadException(f'Being ready, I do not know how invoke {self.function}')
        if e:
            raise e
        return results


class Invocables:
    __lg__ = Logger.getLogger(f'{__name__}.{__qualname__}')

    def __init__(self, invocable: Invocable):
        self.store = dict()
        self.cls = None
        self.ready = False
        self.instance = None
        self.owner = None
        self.functionKey = None
        self.add(invocable)

    def add(self, invocable: Invocable):
        self.functionKey = invocable.getFunctionName()
        key = invocable.getKey().lower()
        if key not in self.store:
            _dbg_(self.__lg__, f'add \n'
                              f'\tinvocable: {invocable} \n'
                              f'\t      key: {key}')
            self.store[key] = invocable
        else:
            raise OverloadException(f'already registered: {key}')

    def bind(self, cls: Type):
        _dbg_(self.__lg__, f'bind\n'
                          f'\tclass: "{cls}"')
        self.cls = cls

    def prepare(self, instance: object, owner: Type):
        self.instance = instance
        self.owner = owner
        self.ready = True

    def reset(self):
        self.instance = None
        self.owner = None
        self.ready = False

    def findInvocable(self, *args, **kwargs) -> Invocable:
        arguments = list()
        for arg in args:
            # arguments.append(str(type(arg)))
            arguments.append(f'{type(arg).__module__}.{type(arg).__name__}')

        paramKey = f"({','.join(arguments)})"
        key = f'{self.functionKey}{paramKey}'.lower()

        _dbg_(self.__lg__, f'findInvocable key: {key}')

        invocable = self.store.get(key)
        _dbg_(self.__lg__, f'findInvocable found: {invocable}')
        if invocable and invocable.accept(*args, **kwargs):
            return invocable
        for invocable in self.store.values():
            _dbg_(self.__lg__, f'trying invocable: {invocable}')
            if invocable.accept(*args, **kwargs):
                return invocable
        return None

    def invoke(self, *args, **kwargs) -> Any:

        s = StringIO()
        pprint.pprint(self.store, s)

        _dbg_(self.__lg__, f'invoke \n'
                          f'\t    store: \n{s.getvalue()} \n'
                          f'\t instance: {self.instance}\n'
                          f'\t    owner: {self.owner}\n'
                          f'\t      cls: {self.cls}\n'
                          f'\t    ready: {self.ready}\n'
                          f'\t     args: {args}\n'
                          f'\t   kwargs: {kwargs}')

        invocable: Invocable = self.findInvocable(*args, **kwargs)

        if self.ready and invocable:
            try:
                ret = invocable.invoke(self.owner, self.instance, *args, **kwargs)
            except OverloadException as oe:
                raise oe
            except BaseException as be:
                self.__lg__.exception('Error processing overloading', exc_info=be)
                # raise OverloadException(f'Could not invoke {invocable.function}', be)
                raise be
            finally:
                self.reset()
            return ret

        raise OverloadException(f'Could not find a function to invoke for args:{args} and kwargs:{kwargs}')
