from typing import Type, Optional, Any

from piggy.base import UnsupportedOperationException
from piggy.base.util import Objects


class InvocationHandler:

    def invoke(self, method: str, *args, **kwargs) -> Any:
        raise UnsupportedOperationException("Called on interface")


class Proxy:

    @staticmethod
    def newProxyInstance(cls: Type, handler: Optional[InvocationHandler] = None):
        handler = Objects.requireNonNull(handler, "handler can't be null/None")

        class instance:
            def __init__(self, cls, handler):
                self.cls = cls
                self.handler = handler

            def __getattr__(self, item):
                if self.handler:
                    handler = self.handler

                    def invoke(*args, **kwargs):
                        return handler.invoke(item, *args, **kwargs)

                    return invoke

        proxyName = cls.__name__
        members = {
            '__name__': cls.__name__,
            '__qualname__': cls.__qualname__
        }
        classes = (instance,)
        delegate = type(proxyName, classes, members)
        instance = object.__new__(delegate)
        instance.__init__(cls, handler)
        return instance
