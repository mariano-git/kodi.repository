from piggy.base.exceptions import *
from piggy.base.overload.overload import Overload


class Class(type):
    # There's nothing wrong to have a class called Class
    @staticmethod
    def forName(className: str):
        module_name, _, class_name = className.rpartition('.')
        try:
            if module_name == '':
                raise ValueError('Class name must contain module part.')
            return getattr(
                __import__(module_name, globals(), locals(), [class_name], 0),
                class_name)
        except AttributeError as e:
            raise ClassNotFoundException(f'{e}')
