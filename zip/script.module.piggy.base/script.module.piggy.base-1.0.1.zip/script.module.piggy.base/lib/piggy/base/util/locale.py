class Locale:
    pass
