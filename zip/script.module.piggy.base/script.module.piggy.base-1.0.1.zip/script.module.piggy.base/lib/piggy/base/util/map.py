from __future__ import annotations

from typing import Generic, TypeVar, Set, Collection

from piggy.base import UnsupportedOperationException

K = TypeVar('K')
V = TypeVar('V')


# interface
class Map(Generic[K, V]):
    class Entry(Generic[K, V]):
        def getKey(self) -> K:
            raise UnsupportedOperationException("Called on interface.")

        def getValue(self) -> V:
            raise UnsupportedOperationException("Called on interface.")

        def setValue(self, value: V) -> V:
            raise UnsupportedOperationException("Called on interface.")

        def equals(self, o: object):
            raise UnsupportedOperationException("Called on interface.")

        def hashCode(self) -> int:
            raise UnsupportedOperationException("Called on interface.")

    def size(self) -> int:
        raise UnsupportedOperationException("Called on interface.")

    def isEmpty(self) -> bool:
        raise UnsupportedOperationException("Called on interface.")

    def containsKey(self, key: K) -> bool:
        raise UnsupportedOperationException("Called on interface.")

    def containsValue(self, value: V) -> bool:
        raise UnsupportedOperationException("Called on interface.")

    def get(self, key: K) -> V:
        raise UnsupportedOperationException("Called on interface.")

    def put(self, key: K, value: V) -> V:
        raise UnsupportedOperationException("Called on interface.")

    def remove(self, key: K) -> V:
        raise UnsupportedOperationException("Called on interface.")

    def putAll(self, src: Map[K, V]):
        raise UnsupportedOperationException("Called on interface.")

    def clear(self):
        raise UnsupportedOperationException("Called on interface.")

    def keySet(self) -> Set[K]:
        raise UnsupportedOperationException("Called on interface.")

    def values(self) -> Collection[V]:
        raise UnsupportedOperationException("Called on interface.")

    def entrySet(self) -> Set[Map.Entry[K, V]]:
        raise UnsupportedOperationException("Called on interface.")

    def equals(self, o: object):
        raise UnsupportedOperationException("Called on interface.")

    def hashCode(self) -> int:
        raise UnsupportedOperationException("Called on interface.")

    def getOrDefault(self, key: K, defaultValue: V) -> V:
        v = self.get(key)
        return defaultValue if v is None else v

    def toString(self) -> str:
        raise UnsupportedOperationException("Called on interface.")
