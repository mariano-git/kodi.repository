import datetime
from typing import Optional


class Date:
    def __init__(self, millis: Optional[int] = None):
        self.millis = millis if millis is not None else int(datetime.datetime.now().timestamp() * 1000)

    def getTime(self) -> int:
        return self.millis

    def setTime(self, millis):
        self.millis = millis

    def before(self, when: 'Date') -> bool:
        '''
        Returns if this Date is before when date
        :param when: Date to compare with this current Date
        :return: True or False if this date is before when Date
        '''
        return self.getTime() < when.getTime()

    def after(self, when: 'Date') -> bool:
        '''
        Returns if this Date is after when date
        :param when: Date to compare with this current Date
        :return: True or False if this date is after when Date
        '''
        return self.getTime() > when.getTime()
