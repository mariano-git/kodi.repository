from typing import Generic, TypeVar

V=TypeVar('V')
class Future(Generic[V]):
    pass
