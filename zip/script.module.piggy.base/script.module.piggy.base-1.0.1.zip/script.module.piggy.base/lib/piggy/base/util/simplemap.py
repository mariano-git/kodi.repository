from typing import Set, Collection, Dict

from piggy.base import UnsupportedOperationException
from piggy.base.stringbuilder import StringBuilder
from piggy.base.util.map import Map, K, V


class SimpleMap(Map[K, V]):
    __slots__ = '__store__'

    class SimpleEntry(Map.Entry[K, V]):
        def __init__(self, key: K, value: V, owner: Map[K, V]):
            self.__k__ = key
            self.__v__ = value
            self.__owner__ = owner

        def getKey(self) -> K:
            return self.__k__

        def getValue(self) -> V:
            return self.__v__

        def setValue(self, value: V) -> V:
            self.__v__ = value

        def equals(self, o: object):
            raise UnsupportedOperationException("Not supported yet.")

        def hashCode(self) -> int:
            raise UnsupportedOperationException("Not supported yet.")

    def __init__(self, store: Dict[K, V] = None):
        self.__store__: Dict[K, V] = dict()
        if store:
            for k, v in store.items():
                self.put(k, v)

    def size(self) -> int:
        return len(self.__store__)

    def isEmpty(self) -> bool:
        return len(self.__store__) == 0

    def containsKey(self, key: K) -> bool:
        return key in self.__store__

    def containsValue(self, value: V) -> bool:
        for entry in self.__store__.values():
            if hasattr(entry.getValue(), 'equals') and entry.getValue().equals(value):
                return True
            elif entry.getValue() == value:
                return True
        return False

    def get(self, key: K) -> V:
        entry: SimpleMap.SimpleEntry[K, V] = self.__store__.get(key)
        return None if entry is None else entry.getValue()

    def put(self, key: K, value: V) -> V:
        self.__store__[key] = SimpleMap.SimpleEntry(key, value, self)
        return value

    def remove(self, key: K) -> V:
        value: V = None
        if key in self.__store__:
            value = self.__store__[key].getValue()
            del self.__store__[key]
        return value

    def putAll(self, src: Map[K, V]):
        if isinstance(src, SimpleMap):
            self.__store__ = {**self.__store__, **src.__store__}
        if isinstance(src, dict):
            self.__store__ = {**self.__store__, **src}

    def clear(self):
        self.__store__.clear()

    def keySet(self) -> Set[K]:
        return frozenset(self.__store__.keys())

    def values(self) -> Collection[V]:
        return list(map(lambda e: e.getValue(), self.__store__.values()))

    def entrySet(self) -> Set[Map.Entry[K, V]]:
        return frozenset(self.__store__.values())

    def equals(self, o: object):
        raise UnsupportedOperationException("Not supported yet.")

    def hashCode(self) -> int:
        raise UnsupportedOperationException("Not supported yet.")

    def getOrDefault(self, key: K, defaultValue: V) -> V:
        entry: SimpleMap.SimpleEntry[K, V] = self.get(key)
        return defaultValue if entry is None else entry.getValue()

    def toString(self) -> str:
        sb = StringBuilder()
        sb.append('{')
        for entry in self.entrySet():
            sb.append(entry.getKey()).append(' = ').append(entry.getValue()).append(', ')
        sb.append('}')
        return sb.toString()
