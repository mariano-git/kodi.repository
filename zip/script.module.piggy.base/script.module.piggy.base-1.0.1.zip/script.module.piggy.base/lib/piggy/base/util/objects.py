import numbers
from collections import Iterable
from typing import Callable, Type, Any

from piggy.base import NullPointerException, IndexOutOfBoundsException
from piggy.base.util.logging import Logger


class Objects:
    __lg__ = Logger.getLogger(f'{__name__}.{__qualname__}')

    @staticmethod
    def asType(o) -> Type:
        if isinstance(o, type):
            return o
        else:
            return o.__class__

    @staticmethod
    def equals(a: object, b: object) -> bool:
        return a == b or not Objects.isNull(a) and a.equals(b) if hasattr(a, 'equals') else False

    @staticmethod
    def hashCode(o: object) -> int:
        # TypeError: unhashable
        # python avoids to hash mutable types, isn't bad or wrong is just time consuming...
        # python hashes are randomly seeded per execution,
        # conserve the same value but only on the same interpreter instance
        def unhashable(o):
            try:
                return hash(o)
            except TypeError:
                h = 0
                if Objects.isEmpty(o):
                    return 37
                if isinstance(o, dict):
                    for k, v in o.items():
                        h += unhashable(k)
                        h += unhashable(v)
                    return h
                if isinstance(o, Iterable):
                    for i in o:
                        h += unhashable(i)
                return h

        return 0 if Objects.isNull(o) else o.hashCode() if hasattr(o, 'hashCode') else unhashable(o)

    @staticmethod
    def hashCodeOf(*o: object):
        h = 0
        if not Objects.isNull(o):
            for a in o:
                h += Objects.hashCode(a)
        return h

    @staticmethod
    def toString(o: object) -> str:
        return o.toString() if not Objects.isNull(o) and hasattr(o, 'toString') else str(o)

    @staticmethod
    def toStringOrElse(o: object, nullDefault: str) -> str:
        return Objects.toString(o) if not Objects.isNull(o) else nullDefault

    @staticmethod
    def requireNonNull(o: object, message: str = None):
        if not Objects.isNull(o):
            return o
        if message:
            raise NullPointerException(message)
        raise NullPointerException()

    @staticmethod
    def isNull(o: object) -> bool:
        return o is None

    @staticmethod
    def isEmpty(o: object) -> bool:
        if Objects.isNull(o):
            return True
        try:
            v = len(o) == 0
            return v
        except TypeError:
            pass
        if isinstance(o, numbers.Number):
            return False

        if hasattr(o, 'size'):
            return o.size() == 0
        if hasattr(o, 'length'):
            return o.length() == 0
        if isinstance(o, type):
            return False
        if isinstance(o, object):
            return False
        return True

    @staticmethod
    def nonNull(o: object) -> bool:
        return not Objects.isNull(o)

    @staticmethod
    def requireNonEmptyElse(o: object, defaultValue: object) -> object:
        return defaultValue if Objects.isEmpty(o) else o

    @staticmethod
    def requireNonNullElseCall(o: object, supplier: Callable, *args, **kwargs) -> Any:
        return supplier(*args, **kwargs) if Objects.isNull(o) else o

    @staticmethod
    def requireNonNullElseRaise(o: object, raisable: Type['Raisable'], *args, **kwargs) -> object:
        if Objects.isNull(o):
            raise raisable(*args, **kwargs)
        return o

    @staticmethod
    def requireNullElseRaise(o: object, raisable: Type['Raisable'], *args, **kwargs) -> object:
        if not Objects.isNull(o):
            raise raisable(*args, **kwargs)
        return o

    @staticmethod
    def requireNonEmptyElseRaise(o: object, raisable: Type['Raisable'], *args, **kwargs) -> object:
        if Objects.isEmpty(o):
            raise raisable(*args, **kwargs)
        return o

    @staticmethod
    def checkNonFalseElseRaise(value: bool, raisable: Type['Raisable'], *args, **kwargs):
        if not value:
            raise raisable(*args, **kwargs)

    @staticmethod
    def checkFromIndexSize(fromIndex: int, size: int, length: int):
        Objects.__lg__.debug(f"checkFromIndexSize fromIndex: {fromIndex}, size: {size}, length: {length}")
        if (length | fromIndex | size) < 0 or size > length - fromIndex:
            raise IndexOutOfBoundsException(
                f'Range [{fromIndex}, {fromIndex} + {size}] out of bounds for length: {length}')
