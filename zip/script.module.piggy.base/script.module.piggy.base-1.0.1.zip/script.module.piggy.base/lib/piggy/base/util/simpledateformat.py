from datetime import datetime as DateTime

from piggy.base.util.date import Date


class SimpleDateFormat:
    def __init__(self, strFormat: str):
        self.dateFormat = strFormat

    def format(self, date: Date) -> str:
        dt = DateTime.fromtimestamp(float(date.getTime() / 1000)).astimezone()
        return dt.strftime(self.dateFormat)

    def parse(self, date:str):
        dt = DateTime.strptime(date, self.dateFormat)
        return Date(int(dt.timestamp() * 1000))
