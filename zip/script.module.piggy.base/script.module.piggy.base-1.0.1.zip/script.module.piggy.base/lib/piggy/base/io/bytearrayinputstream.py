from piggy.base.io.inputstream import InputStream
from piggy.base.io.outputstream import OutputStream
from piggy.base.util import Objects


class ByteArrayInputStream(InputStream):

    def __init__(self, buffer: bytes, offset: int = None, length: int = None):
        self.buffer = memoryview(buffer)
        self.pos = offset if offset is not None else 0
        length = length if length is not None else len(buffer)
        self.count = min(self.pos + length, len(buffer))
        self._mark_ = self.pos

    def read(self, b: bytearray = None, off: int = None, length: int = None) -> int:
        if b is None and off is None and length is None:
            if self.pos < self.count:
                r = self.buffer[self.pos] & 0xff
                self.pos += 1
                return r
            else:
                return -1
        if off is None and length is None:
            off = 0
            length = len(b)
        Objects.checkFromIndexSize(off, length, len(b))

        if self.pos >= self.count:
            return -1

        avail: int = self.count - self.pos
        if length > avail:
            length = avail

        if length <= 0:
            return 0

        external = memoryview(b)

        external[off:off + length] = self.buffer[self.pos:self.pos + length]
        self.pos += length
        return length

    def readAllBytes(self) -> bytes:
        data = bytes(self.buffer[self.pos:self.count])
        self.pos = self.count
        return data

    def readNBytes(self, b: bytearray, off: int, length: int) -> int:
        n: int = self.read(b, off, length)
        return 0 if n == -1 else n

    def transferTo(self, out: OutputStream) -> int:
        length: int = self.count - self.pos
        out.write(bytes(self.buffer), self.pos, length)
        self.pos = self.count
        return length

    def skip(self, n: int) -> int:
        k = self.count = self.pos
        if n < k:
            k = 0 if n < 0 else n
        self.pos += k
        return k

    def available(self) -> int:
        return self.count - self.pos

    def markSupported(self) -> bool:
        return True

    def mark(self, readAheadLimit: int):
        self._mark_ = self.pos

    def reset(self):
        self.pos = self._mark_

    def close(self):
        pass
